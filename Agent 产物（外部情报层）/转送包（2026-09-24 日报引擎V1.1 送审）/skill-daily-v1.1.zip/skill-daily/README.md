# Skill 日报引擎 V1.1（skill-daily）

把已冻结的四类输入合成一份「每天只看 5～10 条，就知道今天有什么值得装 / 恢复 / 更新 / 观察」
的个性化 Skill 日报。**引擎不自动安装任何 Skill**：所有安装 / 删除 / 升级仍由人在
Skill Manager 里确认执行（`auto_install` 恒为 false，代码里无任何安装/删除调用）。

V1.1（整改文档《重复抑制与展示去重》）：所有用户动作都有「提醒状态 + 冷却」，
同功能重复在展示层去重（PRIMARY + alternatives），能力族配额限制版面，
同日重跑幂等、次日无变化不重复；`unchanged_repeated_items = 0` 为机器硬门。

## 目录（整合在本仓库内，不建平行仓）

```
skill-daily/
├── README.md                     ← 本文件
├── config/daily.json             上限 / 全动作冷却周期 / 族配额 / 开关（全部配置化，不硬编码）
├── data/
│   ├── SKILL_FEEDBACK.json       每技能最新反馈状态（机器读取）
│   ├── SKILL_FEEDBACK_HISTORY.jsonl  一行一事件的历史
│   └── state/daily_snapshot.json 提醒状态：date + action_type + external/matched_project/security
│                                 三个签名（§四；用于冷却与「是否真的变了」判定）
├── scripts/
│   ├── common.py                 输入定位（冻结层只读；自动适配开发仓/转送包布局）
│   ├── build_daily.py            引擎主体（确定性，无 LLM）
│   └── feedback.py               反馈录入 CLI
├── reports/YYYY-MM-DD.md         用户日报（第一层只有中文小白文案，技术词进「技术详情」）
├── reports/repeat-audit-*.txt    真实两日重复审计（§二十）
├── DAILY_REPORT_CONTEXT.json     机器摘要（供以后自动推送只读这一份 + Markdown）
└── tests/test_daily.py           43 项测试（42 PASS + 1 真 SKIP 演示；合成输入在临时目录跑）
```

## 用法

```bash
P=python3   # 需要 3.12+
$P scripts/build_daily.py                 # 生成今天：reports/ + DAILY_REPORT_CONTEXT.json
$P scripts/build_daily.py --date 2026-09-24 --out-dir /tmp/x   # 隔离运行（状态也重定向）
$P scripts/feedback.py <canonical_key> <status> ["备注"]        # status: installed|tried|useful|poor|ignored|removed|deferred
$P scripts/feedback.py --list
$P tests/test_daily.py                    # 43 项测试（SKIP 只允许 unittest.SkipTest，真计数）
```

## 重复抑制（V1.1 核心）

- 冷却周期全部在 `config/daily.json`：
  `install_repeat_days=7`、`update_repeat_days=7`、`restore_repeat_days=3`、
  `watch_repeat_days=7`；risk 只由 SECURITY_CHANGED / SOURCE_CHANGED 等新事件驱动。
- 突破冷却的「实质变化」：动作或版本/commit 签名变化、新项目命中、安全状态变化、
  用户反馈更新、material Delta（各动作事件集见 `MATERIAL_DELTA`）。
- 同日重跑 = 幂等（`shown.date == today` 不自我抑制）；次日无变化 = 冷却生效。
  这是两个独立测试（t20b / t20c）。
- 处理顺序固定：安全硬门 → 反馈硬抑制 → 实质变化 → 冷却 → 功能去重 → 族配额 →
  优先级排序 → 上限 10。先去重再截断，绝不为凑满 10 条回填重复项。

## 展示去重与多样性

- `display_family_key = 规范化 skill_name + matched_gap`：完全重复只展示一个 PRIMARY，
  其余进机器摘要 `alternatives[]` 并在日报「同功能的其它来源」一行带出；
  PRIMARY 判定顺序：动作优先级 → 安全 verdict → 来源 tier → 分数 → canonical_key。
- 能力族配额：`max_install_per_capability_family=2`、`max_watch_per_capability_family=1`；
  restore / update / risk 是已有能力生命周期事件，不受配额限制。
- alternatives 与 PRIMARY 共享提醒状态：次日不会出现「换皮重现」的同一功能项。

## 数据流与边界

- 输入（全部**只读**）：`SKILL_CONTEXT` / `INSTALLED_SKILLS_CONTEXT` / `SKILL_SOURCE_MAP`
  经 `external-intelligence/` v2.11 消化后的 `SKILL_CANDIDATES.json`（version 11）与
  外部快照；Delta 语义只读复用 v2.11 `classify_delta`，绝不回退成「字段 != 就算 UPDATED」。
  机器摘要 `input_provenance` 如实区分 `direct_loaded` 与 `inherited_from_external_v2.11`。
- 五类动作：建议安装 / 建议恢复 / 建议更新 / 继续观察 / 暂不建议；
  优先级 P0~P6 按「用户今天要处理什么」排，不按总分（restore 独立于 Top Score）。
- `report_mode`：首份日报为 `initial_baseline`（当前最值得处理的 Top，明示不是今日新变化）；
  次日起 `daily_delta`（只报新动作 / 状态变化 / 冷却到期 / 反馈重入 / 新命中）。
- 反馈闭环：每条 adjustment 必须给得出 `feedback_reason`，只作用于明确维度；
  用户反馈更新本身是突破冷却的合法事件。不做黑箱画像。
- 项目画像冲突：读 `PROJECT_CONTEXT_HEALTH`，仅新增冲突或影响当日推荐时输出一行
  「数据提醒」；同日重跑提醒不消失（baseline 持久化）。引擎不改项目画像。
- 确定性：全部规则代码化；两个全新相同目录同日期 → items 与 report 逐字节一致（t20a）。
  LLM 仅可选地做「一句话/why_today」润色，模板化生成即可。

## 机器摘要合同（DAILY_REPORT_CONTEXT.json）

- `items[].one_line_explanation` ＝ Markdown「一句话」同源的中文用户文案；
  原始英文描述保存在 `items[].source_description_excerpt`，两者分离。
- `suppressed` 六字段：`repeat_cooldown / functional_duplicate / capability_family_quota /
  unchanged_watch / metadata_only / feedback`。
- `unchanged_repeated_items`：按上一日快照直接复算的硬门指标，冻结要求 = 0；
  冷却到期、明确新 Delta、用户主动持续提醒不计入。

## 扩展位（明确不做）

自动安装 / Web Dashboard / 移动 App / Slack / 邮件推送 / AI 聊天界面 / 云数据库 /
多用户 / 企业权限 / 自动删除 —— 先闭环「输入 → Delta → 动作 → 冷却/去重 →
5~10 条日报 → 反馈」。

## 与中央 Skill 仓库规则的关系

本目录是脚本引擎，不是 Skill 工件（不新增 SKILL.md，故不涉及 `SKILL-REGISTRY.md` 登记；
若以后把「跑日报」封装成 Skill，按 `SKILL-CONTRIBUTION.md` 入库并登记）。
