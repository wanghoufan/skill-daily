#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Skill 日报引擎 V1.1 测试（原 §二十 20 项意图 + V1.1 整改 §十九 21~43 项）。

全部用合成输入在临时目录里跑（不碰真实 data/state 与 reports）；
真实数据的断言只读，或写 reports/repeat-audit-*.txt 审计文件。
V1.1 §十一：SKIP 必须是真 SKIP（unittest.SkipTest），绝不再计成 PASS。
"""
import json
import os
import re
import shutil
import sys
import tempfile
import unittest
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(BASE, "scripts"))
import common as C                                     # noqa: E402
import build_daily as BD                               # noqa: E402

# §十二：真实池路径一律用 C.CANDIDATES_PATH（common 已适配开发仓与转送包两种布局），
# 不再写死 os.path.join(EXTERNAL_ROOT, "data", ...)。
REAL_CANDIDATES = C.CANDIDATES_PATH
TODAY = date(2026, 9, 24)

_COUNTS = {"pass": 0, "skip": 0, "fail": 0}
_FAILURES = []


def _run(fn):
    import contextlib
    import io
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            fn()
    except unittest.SkipTest as e:                 # §十一：真 SKIP 计 skip，不计 pass
        _COUNTS["skip"] += 1
        print(f"SKIP {fn.__name__}：{str(e)[:160]}")
        return
    except AssertionError as e:
        _COUNTS["fail"] += 1
        _FAILURES.append((fn.__name__, str(e)[:220]))
        print(f"FAIL {fn.__name__}：{str(e)[:220]}")
        return
    except Exception as e:
        _COUNTS["fail"] += 1
        _FAILURES.append((fn.__name__, f"{type(e).__name__}: {e}"[:220]))
        print(f"FAIL {fn.__name__}：{type(e).__name__}: {str(e)[:220]}")
        return
    _COUNTS["pass"] += 1
    for line in buf.getvalue().strip().splitlines():
        if line.strip():
            print(line)


CFG = dict(C.load_config())


def cand(key, name=None, *, action="watch", rec="watch", score=60.0,
         verdict="pass", risk="low", desc="Do something useful for the user.",
         owner=None, repo=None, needs=None, gap=None, sat=None, inc=None,
         prj=None, reason=None, rel="new_capability", src=True, path="skills/x"):
    owner = owner or (key.split("/")[0] if "/" in key else "o")
    repo = repo or (key.split("/")[1] if key.count("/") > 1 else "r")
    gm = {"matched_gap": gap, "capability_saturation": sat, "gap_level": sat or "none",
          "matched_needs": needs or [], "scope_unresolved": None,
          "product_internal_unresolved": None, "domain_mismatch_unresolved": [],
          "capability_evidence_context": {}}
    if inc:
        gm["incremental_subcapability"] = inc
        gm["incremental_evidence_level"] = {k: "confirmed_absent" for k in inc}
    c = {"canonical_key": key, "skill_name": name or key.split("/")[-1],
         "owner": owner, "repo": repo, "path": path, "description": desc,
         "recommendation": rec, "score": score, "security": {"verdict": verdict,
                                                             "risk_level": risk},
         "capability_gap_match": gm, "action_type": action,
         "installed_relationship": rel, "update_available": False,
         "source_url": f"https://github.com/{owner}/{repo}/tree/main/{path}",
         "source_tier": 1,
         "personalized_reason": reason or {},
         "project_match": {"matched_needs": [n["need"] for n in (needs or [])],
                           "matched_projects": prj or []}}
    return c


def inp(cands, deltas=None, feedback=None, daily_snap=None, conflicts=None,
        first_external=False):
    return dict(cands=cands, cands_doc={"version": 11, "candidates": cands},
                deltas=deltas or {}, feedback=feedback or {},
                daily_snap=daily_snap or {}, conflicts=conflicts or {"conflict_count": 0},
                first_external=first_external, today=TODAY)


def run_items(inputs, mode="daily_delta"):
    return BD.build_items(inputs, CFG, mode)


def _keys(items):
    return [x["canonical_key"] for x in items]


def _shown_entry(c, when, action, proj_sig=None):
    """§四：构造带三个签名的上一日 shown 条目（默认=与当前完全一致，即“无变化”）。"""
    ext, proj, sec = BD._sigs(c)
    return {c["canonical_key"]: {
        "date": when, "action": action, "bucket": action,
        "action_type": c.get("action_type"), "external_signature": ext,
        "matched_project_signature": proj if proj_sig is None else proj_sig,
        "security_signature": sec}}


def _snap(entries, report_date="2026-09-23"):
    return {"report_date": report_date, "shown": entries}


def _gen(tmp, day, cands=None, deltas=None, feedback=None):
    """合成用例：注入 cands + 空 deltas/feedback，完全隔离真实状态。
    真实用例：不传 cands → generate 走真实 C.CANDIDATES_PATH + 真实 external snapshot 复算。"""
    kw = dict(out_dir=tmp, quiet=True)
    if cands is not None:
        kw["cands_doc"] = {"version": 11, "candidates": cands}
        kw["deltas"] = {} if deltas is None else deltas
        kw["feedback"] = {} if feedback is None else feedback
    else:
        if deltas is not None:
            kw["deltas"] = deltas
        if feedback is not None:
            kw["feedback"] = feedback
    return BD.generate(day, **kw)


def _require_real():
    if not os.path.exists(REAL_CANDIDATES):
        raise unittest.SkipTest(f"真实候选池缺失：{REAL_CANDIDATES}")


# ---------- 1-4：0 变化 / NEW install / restore / update ----------
def test_t1_zero_change_day():
    a = cand("o/r/old-watch", action="watch")
    items, sup, _ic = run_items(inp([a], daily_snap=_snap(_shown_entry(a, "2026-09-23", "watch"))))
    assert not items, items
    assert sup["unchanged_watch"] == 1
    report = BD.render_report(TODAY, items, sup, {}, inp([a]), CFG, "daily_delta")
    assert "今天没有需要你处理的 Skill 变化" in report
    print("PASS 1：今日 0 变化 → 明确“无需要处理变化”，不重复 Top30")


def test_t2_new_install_candidate():
    c = cand("o/r/nice", action="new_install", rec="install_candidate",
             reason={"matched_project": "proj-a（match=40）", "fills_gap": "补 mobile_qa"})
    items, _s, _i = run_items(inp([c]))
    assert items and items[0]["action"] == "install"
    r = BD.render_report(TODAY, items, _s, _i, inp([c]), CFG, "daily_delta")
    assert "## 建议安装" in r and "proj-a" in r
    print("PASS 2：NEW install candidate → 建议安装")


def test_t3_restore_not_new():
    c = cand("stablyai/orca/computer-use", action="restore_candidate", rec="watch",
             score=40.0)
    items, _s, _i = run_items(inp([c]))
    assert items[0]["action"] == "restore", items
    assert "不是新 Skill" in BD._zh_one_line(items[0])
    r = BD.render_report(TODAY, items, _s, _i, inp([c]), CFG, "daily_delta")
    assert "## 建议恢复" in r and "发现一个新的" not in r
    assert "不是新 Skill" in r
    print("PASS 3：restore_candidate → 恢复/修复，低分也进（独立于 Top Score）")


def test_t4_update_lineage():
    c = cand("o/r/updatable", action="update_candidate", rec="watch")
    items, _s, _i = run_items(inp([c]))
    assert items[0]["action"] == "update"
    r = BD.render_report(TODAY, items, _s, _i, inp([c]), CFG, "daily_delta")
    assert "## 建议更新" in r
    print("PASS 4：update_candidate（血缘确认）→ 建议更新")


# ---------- 5-7：安全变化 / METADATA_ENRICHED / SYSTEM_REBASELINE ----------
def test_t5_security_changed_block():
    c = cand("o/r/risky", verdict="block", risk="high", action="watch", rec="reject")
    items, _s, _i = run_items(inp([c], deltas={"o/r/risky": ["SECURITY_CHANGED"]}))
    assert items and items[0]["action"] == "risk"
    assert items[0]["priority"] == BD.PRIORITY["risk"]
    print("PASS 5：SECURITY_CHANGED→block 高优先级提示")


def test_t6_metadata_enriched_not_shown():
    c = cand("o/r/quiet", action="watch")
    items, sup, _i = run_items(
        inp([c], deltas={"o/r/quiet": ["METADATA_ENRICHED"]},
            daily_snap=_snap(_shown_entry(c, "2026-09-23", "watch"))))
    assert not items, items
    assert sup["metadata_only"] == 1
    print("PASS 6：METADATA_ENRICHED 默认不进用户日报")


def test_t7_rebaseline_not_external_news():
    snap = {"shown": {}, "report_date": "2026-09-23",
            "external_snapshot_version": {"candidates_version": 10}}
    c = cand("o/x/restoreme", action="restore_candidate")
    items, _s, ic = run_items(inp([c], daily_snap=snap, first_external=False))
    assert ic["SYSTEM_REBASELINE"] == 1, ic
    r = BD.render_report(TODAY, items, _s, ic, inp([c], daily_snap=snap), CFG, "daily_delta")
    assert "今天不用处理的变化" in r and "系统重新建立基线：1" in r
    assert "## 外部更新" not in r
    print("PASS 7：SYSTEM_REBASELINE 只作内部脚注，不冒充外部变化")


# ---------- 8-9：watch 冷却 / 新项目匹配重新出现 ----------
def test_t8_watch_cooldown():
    c = cand("o/r/w1", action="watch")
    for gap_days in range(1, CFG["watch_repeat_days"]):
        d = (TODAY - timedelta(days=gap_days)).isoformat()
        items, sup, _i = run_items(
            inp([c], daily_snap=_snap(_shown_entry(c, d, "watch"))))
        assert not items, (gap_days, items)
        assert sup["unchanged_watch"] == 1
    snap = _snap(_shown_entry(c, "2026-09-10", "watch"))   # 14 天前
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    # 冷却到期但今天也没有触发事件 → 仍不刷屏（watch 需触发；到期只是允许触发时展示）
    assert not items
    print("PASS 8：watch 无变化 7 天内不重复（§十八周期取 config，未硬编码）")


def test_t9_watch_new_project_match_reappears():
    c = cand("o/r/w2", action="watch",
             prj=[{"project": "proj-new", "match_score": 40,
                   "direct_evidence_kinds": ["positioning"]}])
    snap = _snap(_shown_entry(c, "2026-09-23", "watch"))
    items, sup, _i = run_items(
        inp([c], deltas={"o/r/w2": ["MATCH_CHANGED"]}, daily_snap=snap))
    assert items and items[0]["action"] == "watch"
    assert "与你的匹配度有变化" in items[0]["why_today"]
    assert items[0]["bucket"] == "watch_rising", items[0]["bucket"]
    assert "用上了它的能力" in items[0]["extra_note"]
    print("PASS 9：watch 新项目匹配/变化 → 冷却期内可重新出现，且按高优先观察处理")


# ---------- 10-12：反馈 ignored / poor / useful ----------
def test_t10_feedback_ignored():
    c = cand("o/r/ign", action="watch")
    fb = {"o/r/ign": {"status": "ignored", "updated_at": "2026-09-22", "user_note": ""}}
    items, sup, _i = run_items(inp([c], deltas={"o/r/ign": ["RISING"]}, feedback=fb))
    assert not items and sup["feedback"] == 1
    fb2 = {"o/r/ign": {"status": "ignored", "updated_at": "2026-09-01", "user_note": ""}}
    items2, _s, _i2 = run_items(inp([c], deltas={"o/r/ign": ["RISING"]}, feedback=fb2))
    assert items2
    print("PASS 10：feedback=ignored 冷却期内不立即重复（触发事件也要等过期）")


def test_t11_feedback_poor_family_demote():
    # V1.1：同一能力族 watch 配额=1，故用不同族各放一条，验证 poor 降级仍然生效
    poor_src = cand("poor/repo/p", action="watch", gap="devops")
    fam_need = [{"need": "mobile-qa", "weight": 27, "evidence_level": "primary"}]
    same = cand("poor/repo/kin", action="watch", needs=fam_need, gap="mobile_qa")
    other = cand("fresh/repo/n", action="watch", needs=fam_need, gap="api_design")
    fb = {"poor/repo/p": {"status": "poor", "updated_at": "2026-09-20", "user_note": ""}}
    deltas = {"poor/repo/kin": ["RISING"], "fresh/repo/n": ["RISING"],
              "poor/repo/p": ["RISING"]}
    items, _s, _i = run_items(inp([poor_src, same, other], deltas=deltas, feedback=fb))
    order = _keys(items)
    assert order.index("fresh/repo/n") < order.index("poor/repo/kin"), order
    kin = next(x for x in items if x["canonical_key"] == "poor/repo/kin")
    assert "不好用" in kin["feedback_effect"] and kin["feedback_reason"]
    print("PASS 11：feedback=poor → 同功能族/同来源路线降级，且给得出 feedback_reason")


def test_t12_feedback_useful_boost():
    useful = cand("good/repo/u", action="watch", gap="ui_design")
    kin = cand("good/repo/k", action="watch", gap="ui_design")
    rival = cand("other/repo/k", action="watch", gap="devops")
    fb = {"good/repo/u": {"status": "useful", "updated_at": "2026-09-20", "user_note": ""}}
    deltas = {"good/repo/k": ["RISING"], "other/repo/k": ["RISING"],
              "good/repo/u": ["RISING"]}
    items, _s, _i = run_items(inp([useful, kin, rival], deltas=deltas, feedback=fb))
    order = _keys(items)
    assert order.index("good/repo/k") < order.index("other/repo/k"), order
    assert any("好用" in x["feedback_effect"] for x in items)
    print("PASS 12：feedback=useful → 同来源/同能力路线提升展示优先级")


# ---------- 13-15：冲突画像 / scope 未解除 / strong 无增量 ----------
def test_t13_conflict_suppression():
    conflicts = {"conflict_count": 1, "conflicts": [
        {"project": "proj-x", "reason": "description-tech mismatch",
         "description_tech": ["expo"], "declared_tech": ["nextjs"],
         "suppressed_strong_tech": ["Next.js", "PWA"]}]}
    c = cand("o/r/nextkit", action="new_install", rec="install_candidate",
             prj=[{"project": "proj-x", "match_score": 30,
                   "direct_evidence_kinds": ["positioning"]}])
    inputs = inp([c], conflicts=conflicts)
    items, _s, _i = run_items(inputs)
    assert items and items[0]["affected_by_conflict"]
    r = BD.render_report(TODAY, items, _s, _i, inputs, CFG, "daily_delta")
    assert "数据提醒" in r and "proj-x" in r
    print("PASS 13：project_context_conflict → 不静默；冲突项目单独出数据提醒")


def test_t14_unresolved_scope_not_in_install():
    c = cand("hf/skills/spaces", action="new_install", rec="install_candidate")
    c["capability_gap_match"]["scope_unresolved"] = "huggingface-spaces"
    items, _s, _i = run_items(inp([c]))
    assert not items
    c2 = cand("ms/skills/azdeploy", action="new_install", rec="install_candidate")
    c2["capability_gap_match"]["domain_mismatch_unresolved"] = ["azure"]
    items2, _s2, _i2 = run_items(inp([c2]))
    assert not items2
    print("PASS 14：product/domain 未解除 → 不进建议安装（日报层保险带）")


def test_t15_strong_without_incremental_not_install():
    c = cand("o/r/design-clone", action="new_install", rec="install_candidate",
             sat="strong")
    items, _s, _i = run_items(inp([c]))
    assert not items, items
    c["capability_gap_match"]["incremental_subcapability"] = ["accessibility_audit"]
    c["personalized_reason"] = {"incremental_over_installed": "新子能力 accessibility_audit"}
    items2, _s2, _i2 = run_items(inp([c]))
    assert items2
    print("PASS 15：strong 饱和无增量 → 不进建议安装；带增量说明才放行")


# ---------- 16-18：不凑数 / 超 10 取前 10 / 来源可追溯 ----------
def test_t16_no_padding():
    c = cand("o/r/only1", action="new_install", rec="install_candidate", gap="g1")
    items, _s, _i = run_items(inp([c]))
    r = BD.render_report(TODAY, items[:10], _s, _i, inp([c]), CFG, "daily_delta")
    assert "今天有 1 件值得看" in r
    assert r.count("### ") == 1
    print("PASS 16：Top 不足 10 → 如实 1 条，不凑数")


def test_t17_max_10_priority():
    cands = [cand(f"o/r/i{i}", action="new_install", rec="install_candidate",
                  score=70 - i, gap=f"g{i}",
                  reason={"matched_project": "p（match=40）"} if i == 0 else {})
             for i in range(14)]
    cands.append(cand("stablyai/orca/restore-x", action="restore_candidate", score=30))
    items, _s, _i = run_items(inp(cands))
    shown = items[:10]
    assert len(items) == 15 and len(shown) == 10, (len(items), len(shown))
    assert shown[0]["canonical_key"] == "stablyai/orca/restore-x"      # P0 恢复压过高分安装
    assert all(x["bucket"].startswith("install") or x["bucket"] == "restore"
               for x in shown)
    print("PASS 17：超过 10 → 按优先级取最高 10 条（restore 不被高分安装挤掉）")


def test_t18_source_traceable():
    c = cand("vercel-labs/agent-skills/react-native-skills", action="new_install",
             rec="install_candidate", gap="g1")
    items, _s, _i = run_items(inp([c]))
    it = items[0]
    assert it["source_url"].startswith("https://github.com/vercel-labs/agent-skills")
    assert it["repo"] and it["skill_path"]
    r = BD.render_report(TODAY, items, _s, _i, inp([c]), CFG, "daily_delta")
    assert "来源：https://github.com/" in r and "来源：GitHub\n" not in r
    print("PASS 18：每条推荐都有可点回原处的来源（repo+path/source_url）")


# ---------- 19：无自动安装 ----------
def test_t19_no_auto_install():
    src = open(os.path.join(BASE, "scripts", "build_daily.py"), encoding="utf-8").read()
    fb = open(os.path.join(BASE, "scripts", "feedback.py"), encoding="utf-8").read()
    cm = open(os.path.join(BASE, "scripts", "common.py"), encoding="utf-8").read()
    for blob in (src, fb, cm):
        for token in ("subprocess", "os.system", "pip install", "npm install",
                      "skill-manager install", "shutil.rmtree"):
            assert token not in blob, token
    cfg = C.load_config()
    assert cfg["auto_install"] is False
    print("PASS 19：引擎无任何安装/删除/升级调用；auto_install 恒为 false")


# ---------- §十三 20A/20B/20C：确定性拆成三个独立测试 ----------
def test_t20a_deterministic_same_initial_state():
    """A. 两个全新目录、同一初始状态、同一日期 → 逐字节一致。"""
    _require_real()
    t1, t2 = tempfile.mkdtemp(prefix="daily-detA1-"), tempfile.mkdtemp(prefix="daily-detA2-")
    try:
        m1, r1, _s1 = _gen(t1, TODAY)
        m2, r2, _s2 = _gen(t2, TODAY)
        assert m1["report_mode"] == m2["report_mode"] == "initial_baseline"
        assert json.dumps(m1["items"], sort_keys=True) == \
            json.dumps(m2["items"], sort_keys=True)
        assert r1 == r2
        assert m1["summary"]["total_items"] > 0
        print(f"PASS 20A：两个全新相同目录同日期 → 真实池 Top {m1['summary']['total_items']} "
              "条 items 与 report 逐字节一致")
    finally:
        shutil.rmtree(t1, ignore_errors=True)
        shutil.rmtree(t2, ignore_errors=True)


def test_t20b_same_day_idempotence():
    """B. 同一目录、同一天重跑 → 日报不变，不得被自己冷却抑制成空。"""
    _require_real()
    tmp = tempfile.mkdtemp(prefix="daily-detB-")
    try:
        m1, r1, _s1 = _gen(tmp, TODAY)
        m2, r2, _s2 = _gen(tmp, TODAY)
        assert m1["summary"]["total_items"] > 0
        assert m2["summary"]["total_items"] == m1["summary"]["total_items"], \
            "同一天重跑内容被自我抑制（§三违例）"
        assert json.dumps(m1["items"], sort_keys=True) == \
            json.dumps(m2["items"], sort_keys=True)
        assert r1 == r2
        assert m1["suppressed"]["repeat_cooldown"] == 0
        print("PASS 20B：同目录同日重跑 = 幂等（same-day rerun ≠ next-day cooldown）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t20c_next_day_no_repeat():
    """C. 同目录连跑两天、外部无变化 → 无变化的 install/update/restore/watch 全部不重复。"""
    tmp = tempfile.mkdtemp(prefix="daily-detC-")
    try:
        cands = [cand("o/r/ins1", action="new_install", rec="install_candidate", gap="ga"),
                 cand("o/r/ins2", action="new_install", rec="install_candidate", gap="gb"),
                 cand("o/r/upd", action="update_candidate", rec="watch", gap="gc"),
                 cand("stablyai/orca/computer-use", action="restore_candidate", gap="gd"),
                 cand("o/r/wtch", action="watch", gap="ge")]
        m1, _r1, _s1 = _gen(tmp, TODAY, cands)
        m2, r2, _s2 = _gen(tmp, TODAY + timedelta(days=1), cands)
        assert m1["report_mode"] == "initial_baseline" and m1["summary"]["total_items"] == 5
        assert m2["report_mode"] == "daily_delta"
        assert m2["summary"]["total_items"] == 0, _keys(m2["items"])
        assert "今天没有需要你处理的 Skill 变化" in r2
        assert m2["suppressed"]["repeat_cooldown"] == 4          # 2 install + 1 update + 1 restore
        assert m2["suppressed"]["unchanged_watch"] == 1
        print("PASS 20C：下一天无变化 → 0 条重复（cooldown 全接管，restore/watch 各按周期）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------- §十九 21-28：重复抑制 ----------
def test_t21_first_day_install_shown():
    c = cand("o/r/n1", action="new_install", rec="install_candidate", gap="g1")
    items, sup, _i = run_items(inp([c]), mode="initial_baseline")
    assert items and sup["repeat_cooldown"] == 0
    print("PASS 21：首日 new_install 显示")


def test_t22_install_no_repeat_next_day():
    c = cand("o/r/n2", action="new_install", rec="install_candidate", gap="g1")
    snap = _snap(_shown_entry(c, "2026-09-23", "install"))
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    assert not items, items
    assert sup["repeat_cooldown"] == 1
    print("PASS 22：第二天无变化 → 同一 install 不重复（install_repeat_days=7）")


def test_t23_install_repeat_days_expiry():
    c = cand("o/r/n3", action="new_install", rec="install_candidate", gap="g1")
    within = _snap(_shown_entry(c, (TODAY - timedelta(days=6)).isoformat(), "install"))
    items, sup, _i = run_items(inp([c], daily_snap=within))
    assert not items and sup["repeat_cooldown"] == 1
    past = _snap(_shown_entry(c, (TODAY - timedelta(days=7)).isoformat(), "install"))
    items2, sup2, _i2 = run_items(inp([c], daily_snap=past))
    assert items2 and sup2["repeat_cooldown"] == 0
    print("PASS 23：install_repeat_days 到期 → 可以再次提醒")


def test_t24_update_no_repeat():
    c = cand("o/r/u1", action="update_candidate", rec="watch", gap="g1")
    snap = _snap(_shown_entry(c, "2026-09-23", "update"))
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    assert not items and sup["repeat_cooldown"] == 1
    print("PASS 24：update 第二天无变化不重复")


def test_t25_restore_within_repeat_days():
    c = cand("stablyai/orca/computer-use", action="restore_candidate", gap="g1")
    snap = _snap(_shown_entry(c, "2026-09-22", "restore"))       # 2 天前，< 3
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    assert not items and sup["repeat_cooldown"] == 1
    print("PASS 25：restore 在 restore_repeat_days=3 内不重复")


def test_t26_restore_expiry_realerts():
    c = cand("stablyai/orca/computer-use", action="restore_candidate", gap="g1")
    snap = _snap(_shown_entry(c, "2026-09-21", "restore"))       # 3 天前 = 到期
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    assert items and sup["repeat_cooldown"] == 0
    print("PASS 26：restore 到期重新提醒")


def test_t27_security_changed_breaks_cooldown():
    c = cand("o/r/u2", action="update_candidate", rec="watch", gap="g1")
    snap = _snap(_shown_entry(c, "2026-09-23", "update"))
    items, sup, _i = run_items(
        inp([c], deltas={"o/r/u2": ["SECURITY_CHANGED"]}, daily_snap=snap))
    assert items and items[0]["action"] == "update"
    assert sup["repeat_cooldown"] == 0
    # 持续存在的同一事件不算「今天新发生」：无外部基线时 NEW/SECURITY_CHANGED 天天在，
    # 突破冷却只认相对上次展示新增的事件（复审 §一 根因的另一半）。
    tmp = tempfile.mkdtemp(prefix="daily-persist-")
    try:
        m1, _r1, _s1 = _gen(tmp, TODAY, [c], deltas={c["canonical_key"]: ["NEW"]})
        m2, _r2, _s2 = _gen(tmp, TODAY + timedelta(days=1), [c],
                            deltas={c["canonical_key"]: ["NEW"]})
        assert m1["summary"]["total_items"] == 1
        assert m2["summary"]["total_items"] == 0, _keys(m2["items"])
        assert m2["suppressed"]["repeat_cooldown"] == 1
        # 旧风险同理：reject+NEW 首日报一次，事件不再新增就不得天天冒充「今天发生」（§二.4）
        rz = cand("o/r/rz", action="reject", rec="reject", verdict="block", risk="high")
        t2 = tempfile.mkdtemp(prefix="daily-persist-rz-")
        try:
            n1, _q1, _w1 = _gen(t2, TODAY, [rz], deltas={rz["canonical_key"]: ["NEW"]})
            n2, _q2, _w2 = _gen(t2, TODAY + timedelta(days=1), [rz],
                                deltas={rz["canonical_key"]: ["NEW"]})
            assert n1["summary"]["risk"] == 1
            assert n2["summary"]["risk"] == 0, _keys(n2["items"])
        finally:
            shutil.rmtree(t2, ignore_errors=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("PASS 27：SECURITY_CHANGED 突破冷却；持续存在的同一事件（含旧风险）不天天突破")


def test_t28_new_matched_project_breaks_cooldown():
    c = cand("o/r/n4", action="new_install", rec="install_candidate", gap="g1",
             prj=[{"project": "proj-new", "match_score": 35,
                   "direct_evidence_kinds": ["positioning"]}])
    snap = _snap(_shown_entry(c, "2026-09-23", "install", proj_sig="proj-old"))
    items, sup, _i = run_items(inp([c], daily_snap=snap))
    assert items, (items, sup)
    assert sup["repeat_cooldown"] == 0
    print("PASS 28：新 matched_project（签名变化）突破冷却")


# ---------- §十九 32-35：展示去重与族配额 ----------
def test_t32_exact_functional_duplicate_primary_plus_alternatives():
    a = cand("github/awesome-copilot/webapp-testing", name="webapp-testing",
             action="new_install", rec="install_candidate", gap="testing_qa", score=75.0)
    b = cand("anthropics/skills/webapp-testing", name="webapp-testing",
             action="new_install", rec="install_candidate", gap="testing_qa", score=71.3,
             verdict="review_required")
    items, sup, _i = run_items(inp([a, b]))
    assert len(items) == 1, items
    prim = items[0]
    assert prim["canonical_key"] == "github/awesome-copilot/webapp-testing"   # score 决胜
    assert [x["canonical_key"] for x in prim["alternatives"]] == \
        ["anthropics/skills/webapp-testing"]
    assert sup["functional_duplicate"] == 1
    r = BD.render_report(TODAY, items, sup, _i, inp([a, b]), CFG, "daily_delta")
    assert "同功能的其它来源" in r and "anthropics/skills/webapp-testing" in r
    # 次日：PRIMARY 冷却后 alternatives 也不得「换皮重现」（共享提醒状态）
    tmp = tempfile.mkdtemp(prefix="daily-alt-cd-")
    try:
        m1, _r1, _s1 = _gen(tmp, TODAY, [a, b])
        m2, _r2, _s2 = _gen(tmp, TODAY + timedelta(days=1), [a, b])
        assert m1["summary"]["total_items"] == 1 and m1["items"][0]["alternatives"]
        assert m2["summary"]["total_items"] == 0, _keys(m2["items"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("PASS 32：两个不同 repo 的 webapp-testing → 1 个 PRIMARY + 1 个 alternatives，"
          "次日 alternative 不换皮重现")


def test_t33_capability_family_quota():
    cands = [cand(f"r{i}/skills/webapp-check{i}", action="new_install",
                  rec="install_candidate", gap="testing_qa", score=80 - i)
             for i in range(3)]
    items, sup, _i = run_items(inp(cands))
    assert len(items) == CFG["max_install_per_capability_family"] == 2, items
    assert sup["capability_family_quota"] == 1
    print("PASS 33：testing_qa 3 条 install → family 配额 2，第 3 条记 suppressed 不删除")


def test_t34_restore_update_exempt_from_quota():
    fam = "testing_qa"
    cands = [cand("stablyai/orca/computer-use", action="restore_candidate", gap=fam),
             cand("o/r/upd", action="update_candidate", rec="watch", gap=fam),
             cand("r1/s/e2e-a", action="new_install", rec="install_candidate",
                  gap=fam, score=80),
             cand("r2/s/e2e-b", action="new_install", rec="install_candidate",
                  gap=fam, score=70),
             cand("r3/s/e2e-c", action="new_install", rec="install_candidate",
                  gap=fam, score=60)]
    items, sup, _i = run_items(inp(cands))
    acts = sorted(x["action"] for x in items)
    assert acts == ["install", "install", "restore", "update"], acts
    assert sup["capability_family_quota"] == 1
    print("PASS 34：restore/update 不受 capability family quota 限制")


def test_t35_no_backfill_after_dedupe():
    a = cand("github/awesome-copilot/webapp-testing", name="webapp-testing",
             action="new_install", rec="install_candidate", gap="testing_qa", score=75.0)
    b = cand("anthropics/skills/webapp-testing", name="webapp-testing",
             action="new_install", rec="install_candidate", gap="testing_qa", score=71.0)
    d = cand("wshobson/agents/e2e-testing-patterns", action="new_install",
             rec="install_candidate", gap="testing_qa", score=65.0)
    items, sup, _i = run_items(inp([a, b, d]))
    assert len(items) == 2, _keys(items)               # 去重后只剩 2，不回填
    assert "anthropics/skills/webapp-testing" not in _keys(items)
    assert sup["functional_duplicate"] == 1 and sup["capability_family_quota"] == 0
    print("PASS 35：去重后不足 10 → 就发 2 条，绝不把重复项补回来")


# ---------- §十九 36-37：测试合同 ----------
def test_t36_real_candidates_path_flat_layout():
    """§十二：转送包平铺布局下必须用 C.CANDIDATES_PATH 找到真实池，不得假 SKIP。"""
    if not os.path.exists(REAL_CANDIDATES):
        raise unittest.SkipTest(f"真实候选池缺失：{REAL_CANDIDATES}")
    doc = json.load(open(REAL_CANDIDATES, encoding="utf-8"))
    assert doc.get("version") == 11 and doc.get("candidates")
    print(f"PASS 36：C.CANDIDATES_PATH → {REAL_CANDIDATES}"
          f"（version={doc['version']}, candidates={len(doc['candidates'])}）")


def test_t37_true_skip_counted_as_skip():
    before = dict(_COUNTS)
    def _synthetic_skip():
        raise unittest.SkipTest("合成：真实数据缺失场景")
    _run(_synthetic_skip)
    assert _COUNTS["skip"] == before["skip"] + 1, _COUNTS
    assert _COUNTS["pass"] == before["pass"], "SKIP 被计成 PASS（§十违例）"
    assert _COUNTS["fail"] == before["fail"]
    print("PASS 37：真 SKIP 计入 skip，不再计入 pass（测试合同）")


# ---------- §十九 38-43：机器合同 + 真实两日审计 ----------
def _machine_from_synthetic(tmp):
    c = cand("o/r/mc", action="new_install", rec="install_candidate", gap="mobile_qa",
             desc="Toolkit for interacting with and testing local web applications.")
    m, r, _s = _gen(tmp, TODAY, [c])
    return m, r


def test_t38_machine_one_line_is_chinese():
    tmp = tempfile.mkdtemp(prefix="daily-m38-")
    try:
        m, r = _machine_from_synthetic(tmp)
        it = m["items"][0]
        assert re.search(r"[\u4e00-\u9fff]", it["one_line_explanation"]), it
        assert it["one_line_explanation"] == \
            BD._zh_one_line(dict(it, action="install",
                                 skill_name=it["skill_name"],
                                 fills_gap=it["fills_gap"]))
        assert f"一句话：{it['one_line_explanation']}" in r      # Markdown 与 machine 同源
        print(f"PASS 38：machine one_line_explanation 是中文用户文案且与 Markdown 同源（{it['one_line_explanation'][:30]}…）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t39_source_description_excerpt_kept():
    tmp = tempfile.mkdtemp(prefix="daily-m39-")
    try:
        m, _r = _machine_from_synthetic(tmp)
        it = m["items"][0]
        assert it["source_description_excerpt"].startswith("Toolkit for interacting")
        print("PASS 39：source_description_excerpt 保存原始英文摘录，与中文文案分离")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t40_input_provenance_honest():
    tmp = tempfile.mkdtemp(prefix="daily-m40-")
    try:
        m, _r = _machine_from_synthetic(tmp)
        p = m["input_provenance"]
        assert p["project_context"]["status"] == "inherited_from_external_v2.11"
        assert p["installed_context"]["status"] == "inherited_from_external_v2.11"
        assert p["external_candidates"]["status"] == "direct_loaded" \
            and p["external_candidates"]["path"] == C.CANDIDATES_PATH
        assert p["feedback"]["status"] == "direct_loaded"
        assert p["external_delta_semantics"]["status"] == "reused_readonly_v2.11"
        print("PASS 40：input_provenance 如实区分 direct_loaded / inherited_from_external_v2.11")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t41_unchanged_repeated_items_zero():
    _require_real()
    tmp = tempfile.mkdtemp(prefix="daily-m41-")
    try:
        _gen(tmp, TODAY)
        m2, _r2, _s2 = _gen(tmp, TODAY + timedelta(days=1))
        assert m2["report_mode"] == "daily_delta"
        assert m2["unchanged_repeated_items"] == 0, m2["unchanged_repeated_items"]
        print(f"PASS 41：真实池次日 unchanged_repeated_items = 0（day2 shown={m2['summary']['total_items']}）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t42_suppressed_fields_and_report_mode():
    tmp = tempfile.mkdtemp(prefix="daily-m42-")
    try:
        m, _r = _machine_from_synthetic(tmp)
        for k in ("repeat_cooldown", "functional_duplicate", "capability_family_quota",
                  "unchanged_watch", "metadata_only", "feedback"):
            assert k in m["suppressed"], k
        assert m["report_mode"] == "initial_baseline"
        assert "report_mode" in json.dumps(m)
        print("PASS 42：suppressed 六字段齐全 + report_mode（initial_baseline|daily_delta）入机器摘要")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_t43_real_two_day_simulation_audit():
    """§二十：对真实 v2.11 外部池连跑 2026-09-24 / 2026-09-25，输出审计文件。"""
    _require_real()
    tmp = tempfile.mkdtemp(prefix="daily-audit-")
    try:
        m1, _r1, _s1 = _gen(tmp, TODAY)
        m2, _r2, _s2 = _gen(tmp, TODAY + timedelta(days=1))
        k1 = _keys(m1["items"])
        k2 = _keys(m2["items"])
        repeats = sorted(set(k1) & set(k2))
        L = ["Skill 日报引擎 V1.1：真实两日重复审计（§二十）",
             "=" * 60,
             "DAY1: 2026-09-24",
             f"report_mode: {m1['report_mode']}",
             f"shown: {m1['summary']['total_items']}  "
             f"(install={m1['summary']['install']} restore={m1['summary']['restore']} "
             f"update={m1['summary']['update']} watch={m1['summary']['watch']} "
             f"risk={m1['summary']['risk']})",
             "keys:"] + [f"  {k}" for k in k1] + ["",
             "DAY2: 2026-09-25",
             f"report_mode: {m2['report_mode']}",
             f"shown: {m2['summary']['total_items']}  "
             f"(install={m2['summary']['install']} restore={m2['summary']['restore']} "
             f"update={m2['summary']['update']} watch={m2['summary']['watch']} "
             f"risk={m2['summary']['risk']})",
             "keys:"] + [f"  {k}" for k in k2] + ["",
             "REPEAT_AUDIT:",
             f"day1_day2_key_intersection: {len(repeats)}  {repeats}",
             f"unchanged_repeated_items: {m2['unchanged_repeated_items']}",
             f"cooldown_suppressed: {m2['suppressed']['repeat_cooldown']}",
             f"functional_duplicates_suppressed(day2): {m2['suppressed']['functional_duplicate']}",
             f"family_quota_suppressed(day2): {m2['suppressed']['capability_family_quota']}",
             f"unchanged_watch_suppressed(day2): {m2['suppressed']['unchanged_watch']}",
             ""]
        out = os.path.join(C.REPORTS_DIR, "repeat-audit-2026-09-24_25.txt")
        os.makedirs(C.REPORTS_DIR, exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            f.write("\n".join(L))
        assert m2["unchanged_repeated_items"] == 0, m2["unchanged_repeated_items"]
        assert len(k1) > 0
        print(f"PASS 43：真实两日模拟 → DAY1 {len(k1)} 条 / DAY2 {len(k2)} 条，"
              f"unchanged_repeated_items=0，审计写入 reports/{os.path.basename(out)}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    tests = [
        test_t1_zero_change_day, test_t2_new_install_candidate,
        test_t3_restore_not_new, test_t4_update_lineage,
        test_t5_security_changed_block, test_t6_metadata_enriched_not_shown,
        test_t7_rebaseline_not_external_news, test_t8_watch_cooldown,
        test_t9_watch_new_project_match_reappears, test_t10_feedback_ignored,
        test_t11_feedback_poor_family_demote, test_t12_feedback_useful_boost,
        test_t13_conflict_suppression, test_t14_unresolved_scope_not_in_install,
        test_t15_strong_without_incremental_not_install, test_t16_no_padding,
        test_t17_max_10_priority, test_t18_source_traceable,
        test_t19_no_auto_install,
        test_t20a_deterministic_same_initial_state, test_t20b_same_day_idempotence,
        test_t20c_next_day_no_repeat,
        test_t21_first_day_install_shown, test_t22_install_no_repeat_next_day,
        test_t23_install_repeat_days_expiry, test_t24_update_no_repeat,
        test_t25_restore_within_repeat_days, test_t26_restore_expiry_realerts,
        test_t27_security_changed_breaks_cooldown,
        test_t28_new_matched_project_breaks_cooldown,
        test_t32_exact_functional_duplicate_primary_plus_alternatives,
        test_t33_capability_family_quota, test_t34_restore_update_exempt_from_quota,
        test_t35_no_backfill_after_dedupe,
        test_t36_real_candidates_path_flat_layout, test_t37_true_skip_counted_as_skip,
        test_t38_machine_one_line_is_chinese, test_t39_source_description_excerpt_kept,
        test_t40_input_provenance_honest, test_t41_unchanged_repeated_items_zero,
        test_t42_suppressed_fields_and_report_mode,
        test_t43_real_two_day_simulation_audit,
    ]
    for t in tests:
        _run(t)
    total = sum(_COUNTS.values())
    print()
    print("=" * 64)
    print(f"TEST SUMMARY: pass={_COUNTS['pass']} skip={_COUNTS['skip']} "
          f"fail={_COUNTS['fail']} (total {total})")
    if _FAILURES:
        print("FAILURES:")
        for n, m in _FAILURES:
            print(f"  - {n}: {m}")
    print("=" * 64)
    return 0 if _COUNTS["fail"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
