#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Skill 日报引擎 V1.1（build_daily.py）——确定性，不调用 LLM，不执行任何安装（§十四/§二十二）。

V1.1 整改（审查文档《Skill日报引擎V1.1重复抑制与展示去重整改》）：
* §二 所有动作都有「提醒状态 + 冷却」（install/update/restore/watch 周期全部 config 化），
  只有实质变化（material delta / 新项目命中 / 反馈更新 / 动作变化）才突破冷却；
* §三 同日重跑幂等：shown.date == today 不自我抑制；
* §四 快照 shown 扩展 action_type + external/matched_project/security 三个签名 + delta_cats
  （突破冷却只认「相对上次展示新增的事件」，持续存在的 NEW/SECURITY_CHANGED 不天天有效）；
* §五 report_mode = initial_baseline | daily_delta（机器摘要可见）；
* §六~§九 展示层去重：display_family_key（规范化 skill_name + matched_gap）完全重复
  只留 PRIMARY + alternatives；能力族配额 install/watch 分档；restore/update/risk 免配额；
  去重后不足 10 就少发，不为凑数回填；
* §十六 suppressed 扩展 repeat_cooldown / functional_duplicate / capability_family_quota；
* §十七 硬门 unchanged_repeated_items = 0（按上一日快照直接复算，不再手工声明）；
* §十八 处理顺序：硬门 → 反馈 → 实质变化 → 冷却 → 功能去重 → 族配额 → 优先级 → 上限；
* §十四 机器摘要 one_line_explanation=中文用户文案，source_description_excerpt=原文；
* §十五 INPUT_PROVENANCE 如实区分 direct_loaded 与 inherited_from_external_v2.11。
"""
import argparse
import os
import re
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C                                   # noqa: E402
from common import (load_json, save_json, parse_date)  # noqa: E402


def _load_external_build_context():
    """只读复用 v2.11 冻结语义（classify_delta / snap_key）。

    两个包都有名为 `common` 的模块，这里临时换出本引擎的 `common`，
    让 external-intelligence 的 build_context 按它自己的口径导入；
    完成后原样换回——不写 external 层任何文件。
    """
    ext_scripts = C.EXTERNAL_SCRIPTS_DIR
    saved = sys.modules.pop("common", None)
    try:
        sys.path.insert(0, ext_scripts)
        import build_context as bc_mod
    finally:
        if ext_scripts in sys.path:
            sys.path.remove(ext_scripts)
        for m in ("build_context", "match_rules", "security_gate", "common"):
            sys.modules.pop(m, None)
        if saved is not None:
            sys.modules["common"] = saved
    return bc_mod


bc = _load_external_build_context()

# ---- 用户语言（§三 简单中文；技术词只进「技术详情」，§二十二 模板不加工程术语） ----
ACTION_LABEL = {"install": "建议安装", "restore": "建议恢复", "update": "建议更新",
                "watch": "继续观察", "risk": "暂不建议"}
PRIORITY = {"restore": 0, "risk": 1, "update": 2, "install_project": 3,
            "install_gap": 4, "watch_rising": 5, "watch_normal": 6}
VERDICT_RANK = {"pass": 0, "review_required": 1, "unscanned": 2, "block": 3}
REL_LABEL = {"new_capability": "没装过同类的", "complement": "和已装能力互补",
             "replacement_candidate": "可以替换现有的某个",
             "overlap": "和已装能力有重叠", "near_duplicate": "和已装能力几乎重复",
             "same_name_unverified": "名字和已装的某个相同，但还没确认是同一个",
             "same_name_different_source": "名字相同但来源不同",
             "possible_fork": "可能是已装某个的分叉", "already_installed": "已经装过"}
SEC_LABEL = {"pass": "静态检查通过（仍需人工看一眼）",
             "review_required": "有需注意项，安装前请人工复核",
             "block": "高风险，已拒绝", "unscanned": "未完成扫描，最多只能观察"}
DELTA_LABEL = {"NEW": "今天新出现", "UPDATED": "上游有真实更新", "RISING": "热度/评分明显上升",
               "FALLING": "明显下降", "SECURITY_CHANGED": "安全状态有变化",
               "SOURCE_CHANGED": "来源核验状态有变化", "MATCH_CHANGED": "与你的匹配度有变化",
               "NO_LONGER_RELEVANT": "已不在候选池",
               "METADATA_ENRICHED": "（系统内部）补全了元数据",
               "RECALCULATED": "（系统内部）重新计算",
               "SYSTEM_REBASELINE": "（系统内部）重建基线"}
# §二：能突破各动作冷却的「实质变化」事件集
MATERIAL_DELTA = {
    "install": {"NEW", "UPDATED", "RISING", "SECURITY_CHANGED", "SOURCE_CHANGED",
                "MATCH_CHANGED"},
    "update": {"UPDATED", "SOURCE_CHANGED", "SECURITY_CHANGED"},
    "restore": {"SECURITY_CHANGED", "SOURCE_CHANGED", "UPDATED", "NEW"},
    "watch": {"NEW", "UPDATED", "RISING", "SECURITY_CHANGED", "SOURCE_CHANGED",
              "MATCH_CHANGED"},
}
WATCH_TRIGGERS = MATERIAL_DELTA["watch"]
INTERNAL_ONLY = {"METADATA_ENRICHED", "RECALCULATED"}
REPEAT_CFG_KEY = {"install": "install_repeat_days", "update": "update_repeat_days",
                  "restore": "restore_repeat_days", "watch": "watch_repeat_days"}


# ==========================================================================
# 输入
# ==========================================================================
def load_inputs(today, snapshot_path=None, cands_doc=None, feedback=None,
                deltas=None):
    doc = cands_doc or load_json(C.CANDIDATES_PATH)
    if not doc:
        raise SystemExit(f"缺少冻结输入：{C.CANDIDATES_PATH}（日报引擎不重建候选池）")
    snap_doc = load_json(C.EXTERNAL_SNAPSHOT_PATH, {}) or {}
    ext_snap = snap_doc.get("candidates") if snap_doc.get("candidates") else snap_doc
    first_external = not ext_snap
    if deltas is None:
        deltas = {}
        for c in doc["candidates"]:
            cats = sorted(bc.classify_delta(ext_snap.get(c["canonical_key"]),
                                            bc.snap_key(c)))
            if cats:
                deltas[c["canonical_key"]] = cats
    snap_path = snapshot_path or C.DAILY_SNAPSHOT_PATH
    return dict(cands=doc["candidates"], cands_doc=doc, deltas=deltas,
                feedback=feedback if feedback is not None else C.load_feedback(),
                daily_snap=load_json(snap_path, {}) or {},
                conflicts=doc.get("project_context_health") or {},
                first_external=first_external, today=today)


def _g(c, path, default=None):
    cur = c
    for seg in path:
        cur = (cur or {}).get(seg)
        if cur is None:
            return default
    return cur


def _norm_name(n):
    return re.sub(r"[-_\s]+", "-", (n or "").lower()).strip("-")


def _sigs(c):
    """§四：不需要复杂 hash，能判断「今天是否真的变了」即可。"""
    ext = "{}|{}|{}|{}".format(c.get("action_type"), c.get("recommendation"),
                               c.get("latest_version") or "", c.get("latest_commit") or "")
    proj = ",".join(sorted({m.get("project") or "" for m in
                            _g(c, ("project_match", "matched_projects"), []) or []}))
    sec = "{}|{}".format(_g(c, ("security", "verdict")), _g(c, ("security", "risk_level")))
    return ext, proj, sec


def _display_family_key(c):
    """§七：完全重复 = 规范化 skill_name + matched_gap 相同。"""
    return f"{_norm_name(c.get('skill_name'))}#{_g(c, ('capability_gap_match', 'matched_gap')) or '—'}"


def _family(c):
    return _g(c, ("capability_gap_match", "matched_gap")) or "—"


def _install_gate_ok(c):
    """§二十 14/15 保险带：未解除 scope/错配、strong 饱和无增量 → 不得进建议安装。"""
    gm = c.get("capability_gap_match") or {}
    if gm.get("scope_unresolved") or gm.get("product_internal_unresolved"):
        return False
    if gm.get("domain_mismatch_unresolved"):
        return False
    if _g(c, ("security", "verdict")) == "block":
        return False
    sat = gm.get("capability_saturation") or ""
    if sat.startswith("strong") and sat != "strong_degraded":
        if not (c.get("personalized_reason") or {}).get("incremental_over_installed") \
                and not c.get("update_available") \
                and c.get("installed_relationship") != "replacement_candidate":
            return False
    return True


def _has_strong_project(c):
    pr = c.get("personalized_reason") or {}
    if pr.get("matched_project"):
        return True
    for m in _g(c, ("project_match", "matched_projects"), []) or []:
        if set(m.get("direct_evidence_kinds") or []) & {"strong_tech", "positioning"}:
            return True
    return False


def feedback_of(inp, key):
    return (inp.get("feedback") or {}).get(key)


def _conflict_projects(conflicts_doc):
    return {x.get("project") for x in (conflicts_doc.get("conflicts") or [])}


def _zh_one_line(it):
    """§十四：机器与 Markdown 的 one_line_explanation 同一个中文模板。"""
    n = it["skill_name"]
    if it["action"] == "restore":
        return f"这是你已装能力「{n}」的官方同来源版本；本机正本缺失，可以恢复，不是新 Skill。"
    if it["action"] == "update":
        return f"你已装的「{n}」上游出了新版本（同血缘已确认），可以更新。"
    if it["action"] == "risk":
        return f"「{n}」今天安全/来源状态变差，暂时不要装。"
    if it["action"] == "install":
        gap = (it["fills_gap"] or "").replace("能力族 ", "")
        return f"「{n}」能补你的能力缺口：{gap or '见下方项目匹配'}。"
    return f"「{n}」今天出现了值得注意的变化，先观察，不用动手。"


# ==========================================================================
# §十八 处理顺序：硬门 → 反馈 → 实质变化 → 冷却 → 去重 → 配额 → 排序 → 上限
# ==========================================================================
def build_items(inp, cfg, report_mode):
    cands, deltas, feedback = inp["cands"], inp["deltas"], inp["feedback"]
    daily_snap, today = inp["daily_snap"], inp["today"]
    shown = daily_snap.get("shown") or {}
    conflict_names = _conflict_projects(inp["conflicts"])
    by_key = {c["canonical_key"]: c for c in cands}

    def _fam_repo(c):
        return (_g(c, ("capability_gap_match", "matched_gap")) or "—",
                f"{c.get('owner')}/{c.get('repo')}")

    poor_gaps, poor_repos, useful_gaps, useful_repos = set(), set(), set(), set()
    for k, fb in feedback.items():
        c = by_key.get(k)
        if not c:
            continue
        gap, repo = _fam_repo(c)
        if fb.get("status") == "poor":
            (poor_gaps.add(gap) if gap != "—" else None)
            poor_repos.add(repo)
        elif fb.get("status") == "useful":
            (useful_gaps.add(gap) if gap != "—" else None)
            useful_repos.add(repo)

    items = []
    suppressed = {"repeat_cooldown": 0, "functional_duplicate": 0,
                  "capability_family_quota": 0, "unchanged_watch": 0,
                  "metadata_only": 0, "feedback": 0}
    internal_counts = {"METADATA_ENRICHED": 0, "RECALCULATED": 0, "SYSTEM_REBASELINE": 0}

    def _fb_suppressed(key, c):
        fb = feedback.get(key)
        if not fb:
            return None
        st, when = fb.get("status"), parse_date(fb.get("updated_at"))
        gap_d = C.days_between(when, today)
        if st == "installed":
            return "已按你的反馈标记为已安装，等底座更新后以 Canonical 为准"
        if st == "ignored" and gap_d is not None and gap_d < cfg["ignored_repeat_days"]:
            return f"你之前标记为「忽略」，{cfg['ignored_repeat_days']} 天内不再重复"
        if st == "deferred" and gap_d is not None and gap_d < cfg["deferred_repeat_days"]:
            return f"你之前标记为「暂缓」，{cfg['deferred_repeat_days']} 天内不再重复"
        if st == "removed" and gap_d is not None and gap_d < cfg["removed_cooldown_days"]:
            return (f"你之前移除过同类 Skill，{cfg['removed_cooldown_days']} 天内"
                    "不重新推荐同一个")
        return None

    def _cooldown_hit(key, action, c, cats):
        """§二/§三：冷却判定。返回 (是否抑制, 说明)。同日重跑幂等；实质变化突破。"""
        prev = shown.get(key)
        if not prev or not prev.get("date"):
            return False
        pd = parse_date(prev.get("date"))
        if pd == today:                       # §三：same-day rerun = idempotent
            return False
        if prev.get("action") != action:      # 动作变了 → 重新提醒
            return False
        ext, proj, sec = _sigs(c)
        if prev.get("external_signature") and prev["external_signature"] != ext:
            return False                        # 恢复路径/动作状态/版本变了
        if prev.get("security_signature") and prev["security_signature"] != sec:
            return False
        if proj and prev.get("matched_project_signature") is not None \
                and prev["matched_project_signature"] != proj:
            return False                        # 项目命中变化（含新命中）
        fb = feedback.get(key)
        if fb and parse_date(fb.get("updated_at")) and \
                parse_date(fb["updated_at"]) > pd:
            return False                        # §五：用户反馈导致重新进入
        # 「实质变化」必须是相对上次展示时新增的事件：无外部基线时 NEW 会天天在，
        # 若不过滤就会出现「连续两天 10 条全同」的复审违例（§一）。
        prev_cats = set(prev.get("delta_cats") or [])
        if (cats - prev_cats) & MATERIAL_DELTA.get(action, set()):
            return False                        # 新增实质 Delta 突破
        if action == "risk":
            # risk 不叠加 repeat_days：今天有新事件立刻提醒；
            # 但事件无变化的旧风险不得每天冒充「今天发生」（§二.4）。
            return not (cats - prev_cats)
        days = cfg.get(REPEAT_CFG_KEY.get(action, "watch_repeat_days"), 7)
        gap_d = C.days_between(pd, today)
        if gap_d is not None and gap_d < days:
            return True
        return False

    def _add(key, bucket, c, why_today, extra_note=""):
        action = ("restore" if bucket == "restore" else
                  "install" if bucket.startswith("install") else
                  "update" if bucket == "update" else
                  "risk" if bucket == "risk" else "watch")
        cats = sorted(set(deltas.get(key) or []))
        if _cooldown_hit(key, action, c, set(cats)):
            suppressed["repeat_cooldown"] += 1
            return
        pr = dict(c.get("personalized_reason") or {})
        pm = c.get("project_match") or {}
        if not pr.get("matched_project") and (pm.get("matched_projects") or []):
            m0 = pm["matched_projects"][0]
            pr["matched_project"] = f"{m0['project']}（match={m0['match_score']}）"
        if not pr.get("fills_gap"):
            needs = pm.get("matched_needs") or []
            gap = _g(c, ("capability_gap_match", "matched_gap"))
            pr["fills_gap"] = (("命中需求：" + "/".join(needs[:3])) if needs else "") \
                + (f"；能力缺口：{gap}" if gap else "")
        gap_f, repo_f = _fam_repo(c)
        prio = PRIORITY[bucket]
        fb_effect = ""
        if (gap_f != "—" and gap_f in poor_gaps) or repo_f in poor_repos:
            prio += 2
            fb_effect = ("你之前把同类 Skill 标记为「不好用」（同能力族 "
                         f"{gap_f if gap_f in poor_gaps else '—'}/同来源 {repo_f}），"
                         "因此本次降低展示优先级。")
        elif (gap_f != "—" and gap_f in useful_gaps) or repo_f in useful_repos:
            prio = max(0, prio - 1)
            fb_effect = f"你之前把同类 Skill 标记为「好用」（同来源 {repo_f} 等），本次提升展示优先级。"
        it = {
            "canonical_key": key, "skill_name": c.get("skill_name"),
            "bucket": bucket, "action": action, "priority": prio,
            "one_line_explanation": "", "source_description_excerpt": C.clean_desc(c.get("description")),
            "why_today": why_today, "matched_project": pr.get("matched_project") or "",
            "fills_gap": pr.get("fills_gap") or "",
            "installed_overlap": REL_LABEL.get(c.get("installed_relationship"),
                                               c.get("installed_relationship") or ""),
            "security_status": SEC_LABEL.get(_g(c, ("security", "verdict")), "未扫描"),
            "source": f"{c.get('owner')}/{c.get('repo')}",
            "repo": f"https://github.com/{c.get('owner')}/{c.get('repo')}",
            "skill_path": c.get("path") or "",
            "source_url": c.get("source_url") or "",
            "source_tier": c.get("source_tier"),
            "personalized_score": c.get("score"),
            "action_type": c.get("action_type"),
            "delta_cats": cats, "feedback_effect": fb_effect, "feedback_reason": fb_effect,
            "extra_note": extra_note,
            "family": _family(c), "display_family_key": _display_family_key(c),
            "verdict_rank": VERDICT_RANK.get(_g(c, ("security", "verdict")), 9),
            "affected_by_conflict": bool(conflict_names & {m.get("project") for m in
                                                           (_g(c, ("project_match",
                                                                   "matched_projects"),
                                                             []) or [])}),
            "alternatives": [],
        }
        it["one_line_explanation"] = _zh_one_line(it)
        items.append(it)

    for c in cands:
        key = c["canonical_key"]
        at = c.get("action_type") or "watch"
        cats = set(deltas.get(key) or [])
        if cats and cats <= INTERNAL_ONLY:
            suppressed["metadata_only"] += 1
        # —— 暂不建议（§三.5 + §二.4：只由今天的新事件触发，旧风险不天天重发）——
        if ("SECURITY_CHANGED" in cats or "SOURCE_CHANGED" in cats) and \
                (_g(c, ("security", "verdict")) == "block"
                 or _g(c, ("security", "risk_level")) == "high"):
            note = _fb_suppressed(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _add(key, "risk", c, "安全/来源状态今天有变化，且判定为高风险",
                 "原因：高风险（静态审查发现真要求执行的危险行为）")
            continue
        if at == "reject" and ("NEW" in cats or "SECURITY_CHANGED" in cats):
            _add(key, "risk", c, "今天被安全 Gate 拒绝",
                 f"原因：{(c.get('recommendation_reason') or '')[:80]}")
            continue
        # —— 恢复（§五：独立于 Top Score；§二.3：默认 3 天冷却，可配置）——
        if at == "restore_candidate":
            note = _fb_suppressed(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _add(key, "restore", c,
                 "已装能力的正本缺失，官方同血缘版本可以恢复"
                 + ("；今天上游有新动态" if cats & MATERIAL_DELTA["restore"] else ""),
                 "这是已有能力的恢复，不是发现新 Skill")
            continue
        # —— 建议更新 ——
        if at == "update_candidate":
            note = _fb_suppressed(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _add(key, "update", c, "已装 Skill 的上游发布了确认同血缘的新版本")
            continue
        # —— 建议安装 ——
        if at == "new_install":
            note = _fb_suppressed(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            if not _install_gate_ok(c):
                continue
            bucket = "install_project" if _has_strong_project(c) else "install_gap"
            _add(key, bucket, c,
                 "今天进入安装候选：" + ("命中你当前项目的真实需求"
                                   if bucket == "install_project"
                                   else "补你现在没有/很弱的能力"))
            continue
        # —— 继续观察（§三.4：只有变化事件值得占用日报）——
        if at == "watch" and c.get("recommendation") not in ("watch", "install_candidate"):
            continue
        if at == "watch":
            trigger = cats & WATCH_TRIGGERS
            first_daily = report_mode == "initial_baseline"
            if not trigger and not first_daily:
                suppressed["unchanged_watch"] += 1
                continue
            note = _fb_suppressed(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            bucket = ("watch_rising" if trigger & {"RISING", "NEW", "UPDATED"}
                      or _has_strong_project(c) else "watch_normal")
            why = "、".join(DELTA_LABEL[t] for t in sorted(trigger)) \
                or "首份基线：先给你看一眼（之后只在有变化时提醒）"
            extra = ""
            if trigger and _has_strong_project(c):
                extra = "你当前的项目今天用上了它的能力（值得重看）"
            _add(key, bucket, c, why, extra)

    # —— 内部事件计数 + 引擎换代检测（§六：不作外部新闻） ——
    for key, cats in deltas.items():
        for k in internal_counts:
            if k in cats:
                internal_counts[k] += 1
    prev_ver = ((daily_snap.get("external_snapshot_version") or {})
                .get("candidates_version"))
    cur_ver = inp["cands_doc"].get("version")
    if (prev_ver and str(prev_ver) != str(cur_ver)) or inp.get("first_external"):
        internal_counts["SYSTEM_REBASELINE"] = max(1, internal_counts["SYSTEM_REBASELINE"])

    # —— §十八 7：确定性排序（优先级 → 安全 verdict → 来源 tier → 分数 → key）——
    items.sort(key=lambda x: (x["priority"], x["verdict_rank"],
                               x["source_tier"] if x["source_tier"] is not None else 9,
                               -(x["personalized_score"] or 0), x["canonical_key"]))
    # —— §七 功能完全重复：PRIMARY + alternatives ——
    kept, by_fam = [], {}
    for it in items:
        dup = by_fam.get(it["display_family_key"])
        if dup is not None:
            dup["alternatives"].append({
                "canonical_key": it["canonical_key"], "source": it["source"],
                "score": it["personalized_score"], "security": it["security_status"]
                .split("（")[0], "source_tier": it["source_tier"]})
            suppressed["functional_duplicate"] += 1
            continue
        by_fam[it["display_family_key"]] = it
        kept.append(it)
    # —— §八 能力族配额（只作用于 install / watch；restore/update/risk 豁免）——
    fam_cnt, final = {}, []
    for it in kept:
        if it["action"] == "install":
            cap = cfg["max_install_per_capability_family"]
        elif it["action"] == "watch":
            cap = cfg["max_watch_per_capability_family"]
        else:
            final.append(it)
            continue
        used = fam_cnt.get(it["family"], 0)
        if used >= cap:
            suppressed["capability_family_quota"] += 1
            continue
        fam_cnt[it["family"]] = used + 1
        final.append(it)
    return final, suppressed, internal_counts


# ==========================================================================
# 渲染（§十/§十一/§十二/§十三/§二十二：第一层只有用户语言）
# ==========================================================================
def _card(it):
    L = [f"### {it['skill_name']}", ""]
    L.append(f"一句话：{it['one_line_explanation']}")
    L.append("")
    L.append(f"为什么今天出现：{it['why_today']}")
    L.append("")
    if it["action"] in ("install", "watch"):
        L.append(f"对你有什么用：{it['fills_gap'] or '（见下方项目匹配）'}")
    if it["action"] == "restore":
        L.append("对你有什么用：把之前缺的那块能力补回来，不影响你现有配置。")
    if it["action"] == "update":
        L.append("对你有什么用：拿到上游的修复和新功能。")
    if it["action"] == "risk":
        L.append(f"为什么暂不建议：{it['extra_note']}")
    L.append("")
    L.append(f"对哪个项目有用：{it['matched_project'] or '没对上具体项目，属于通用能力'}")
    L.append("")
    L.append(f"和已装 Skill 是否重复：{it['installed_overlap']}")
    L.append("")
    L.append(f"安全：{it['security_status']}")
    L.append("")
    if it["action"] != "risk":
        L.append(f"动作：{ACTION_LABEL[it['action']]}"
                 "（V1 只给建议；请你在 Skill Manager 里人工确认后执行）")
    else:
        L.append("动作：暂不建议")
    L.append("")
    if it["alternatives"]:
        alts = "；".join(f"`{a['canonical_key']}`（T{a['source_tier']}，"
                         f"score={a['score']}，安全={a['security']}）"
                         for a in it["alternatives"])
        L.append(f"同功能的其它来源（不重复占版面，只推一个）：{alts}")
        L.append("")
    src = it["source_url"] or f"{it['repo']}/tree/main/{it['skill_path']}"
    L.append(f"来源：{src}")
    L.append("")
    if it["feedback_effect"]:
        L.append(f"你的反馈影响：{it['feedback_effect']}")
        L.append("")
    L.append("<details><summary>技术详情（可选）</summary>")
    L.append("")
    L.append(f"- canonical_key: `{it['canonical_key']}`｜source_tier=T{it['source_tier']}"
             f"｜score={it['personalized_score']}｜delta={','.join(it['delta_cats']) or '—'}")
    L.append(f"- repo={it['source']}｜skill_path={it['skill_path'] or '—'}"
             f"｜action_type={it['action_type']}")
    if it.get("source_description_excerpt"):
        L.append(f"- 原文描述：{it['source_description_excerpt']}")
    L.append("</details>")
    L.append("")
    return L


def render_report(today, items, suppressed, internal_counts, inp, cfg, report_mode):
    L = [f"# Skill 日报｜{today.isoformat()}", ""]
    if report_mode == "initial_baseline":
        L.append("> 首份基线日报：这是「当前最值得处理的几条」，不是今天新发生的变化；"
                 "从明天起只报变化和到期提醒。")
        L.append("")
    if not items:
        L.append("今天没有需要你处理的 Skill 变化。")
        L.append("")
    else:
        L.append(f"今天有 {len(items)} 件值得看。")
        L.append("")
        order = {"restore": "建议恢复", "risk": "暂不建议", "update": "建议更新",
                 "install_project": "建议安装", "install_gap": "建议安装",
                 "watch_rising": "继续观察", "watch_normal": "继续观察"}
        groups, seen = [], set()
        for it in items:
            g = order[it["bucket"]]
            if g not in seen:
                seen.add(g)
                groups.append(g)
        for g in groups:
            L.append(f"## {g}")
            L.append("")
            for it in [x for x in items if order[x["bucket"]] == g]:
                L += _card(it)
                L.append("---")
                L.append("")
        if L and L[-1] == "":
            L.pop()
    conflict_names = _conflict_projects(inp["conflicts"])
    # §三：同日重跑幂等——「新增冲突」必须对比昨天（或更早）的已提醒集合，
    # 不能对比今天上午那次运行刚写的快照，否则提醒会在第二次运行时消失。
    prev_conflicts = set(inp.get("conflicts_notified")
                         if inp.get("conflicts_notified") is not None
                         else (inp["daily_snap"].get("conflicts") or []))
    new_conflicts = conflict_names - prev_conflicts
    affecting = any(it["affected_by_conflict"] for it in items)
    if conflict_names and (new_conflicts or affecting):
        who = "、".join(sorted(new_conflicts or conflict_names))
        L.append("数据提醒：")
        L.append(f"{who} 项目的描述和技术栈不一致，因此今天没有用冲突技术作为推荐依据。"
                 "（引擎不修改项目画像，只标记；请上游 Profile 修正）")
        L.append("")
    internal_total = sum(internal_counts.values())
    if cfg.get("show_internal_system_events") or (internal_total and items):
        L.append("## 今天不用处理的变化")
        L.append("")
        _foot = {"SYSTEM_REBASELINE": "系统重新建立基线", "METADATA_ENRICHED": "元数据补全",
                 "RECALCULATED": "引擎重算（系统内部）"}
        for k in ("SYSTEM_REBASELINE", "METADATA_ENRICHED", "RECALCULATED"):
            if internal_counts.get(k):
                L.append(f"- {_foot[k]}：{internal_counts[k]}")
        L.append("")
    sp = suppressed
    L.append(f"> 重复与去重：{sp['repeat_cooldown']} 条动作项在冷却期内不重复；"
             f"{sp['unchanged_watch']} 条无变化的观察项未重复；"
             f"{sp['functional_duplicate']} 条同功能重复来源并入 PRIMARY 的 alternatives；"
             f"{sp['capability_family_quota']} 条被能力族配额挡住（候选未删，仅不占版面）；"
             f"{sp['feedback']} 条被你的反馈规则压住。")
    L.append("")
    L.append("> V1 引擎不安装 / 不删除 / 不升级任何 Skill；"
             "所有动作由你在 Skill Manager 人工确认。")
    L.append("")
    return "\n".join(L)


# ==========================================================================
# 主入口
# ==========================================================================
def generate(today=None, out_dir=None, quiet=False, snapshot_path=None,
             cands_doc=None, feedback=None, deltas=None):
    cfg = C.load_config()
    today = today or date.today()
    redirected = bool(out_dir and os.path.abspath(out_dir) != os.path.abspath(C.REPORTS_DIR))
    snap_path = snapshot_path or (
        os.path.join(out_dir, "state", "daily_snapshot.json")
        if redirected and out_dir else C.DAILY_SNAPSHOT_PATH)
    inp = load_inputs(today, snapshot_path=snap_path, cands_doc=cands_doc,
                      feedback=feedback, deltas=deltas)
    # §三 same-day rerun = idempotent：当天重跑沿用已存的 report_mode，
    # 不能因为上午自己写过快照就在下午把同一份日报抑制成 daily_delta。
    prev_rd = (inp["daily_snap"] or {}).get("report_date")
    if not prev_rd:
        report_mode = "initial_baseline"
    elif prev_rd == today.isoformat():
        report_mode = (inp["daily_snap"] or {}).get("report_mode") or "daily_delta"
    else:
        report_mode = "daily_delta"
    # §三：同一天重跑沿用当天写入的 conflicts_baseline（上午的提醒不会下午消失）
    ds = inp["daily_snap"] or {}
    if prev_rd == today.isoformat() and "conflicts_baseline" in ds:
        inp["conflicts_notified"] = ds["conflicts_baseline"]
    else:
        inp["conflicts_notified"] = ds.get("conflicts") or []
    items, suppressed, internal_counts = build_items(inp, cfg, report_mode)
    shown = items[: int(cfg["max_daily_items"])]      # 先去重/配额，再截断（§九/§十八）

    # §十七：unchanged_repeated_items 直接按上一日快照复算（硬门 = 0）
    prev_shown = inp["daily_snap"].get("shown") or {}
    prev_date = parse_date(inp["daily_snap"].get("report_date"))
    unchanged_repeated = 0
    if report_mode == "daily_delta" and prev_date and prev_date < today:
        byk = {c["canonical_key"]: c for c in inp["cands"]}
        for it in shown:
            pv = prev_shown.get(it["canonical_key"])
            if not pv or pv.get("date") == today.isoformat():
                continue
            src = byk.get(it["canonical_key"])
            if src is None or pv.get("action") != it["action"]:
                continue
            ext, proj, sec = _sigs(src)
            if (set(it["delta_cats"]) - set(pv.get("delta_cats") or [])) \
                    & MATERIAL_DELTA.get(it["action"], set()):
                continue                       # 明确新 Delta：允许的再提醒
            if (pv.get("external_signature") not in (None, "", ext)
                    or pv.get("matched_project_signature") not in (None, proj)
                    or pv.get("security_signature") not in (None, sec)):
                continue                       # 签名变化（含新项目命中 / 安全变化）
            fb = feedback_of(inp, it["canonical_key"])
            if fb and parse_date(fb.get("updated_at")) and \
                    parse_date(fb["updated_at"]) > prev_date:
                continue                       # 用户反馈导致的重新进入
            gap_d = C.days_between(parse_date(pv.get("date")), today)
            days_cfg = cfg.get(REPEAT_CFG_KEY.get(it["action"], "watch_repeat_days"), 7)
            if gap_d is not None and gap_d < days_cfg:
                unchanged_repeated += 1        # 冷却窗口内的无变化重复 = 违规

    report = render_report(today, shown, suppressed, internal_counts, inp, cfg,
                           report_mode)
    out_dir = out_dir or C.REPORTS_DIR
    os.makedirs(out_dir, exist_ok=True)
    report_path = os.path.join(out_dir, f"{today.isoformat()}.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    def _cnt(b):
        return sum(1 for x in shown if x["bucket"].startswith(b))
    machine = {
        "generated": today.isoformat(),
        "report_mode": report_mode,
        "summary": {"total_items": len(shown), "install": _cnt("install"),
                    "restore": _cnt("restore"), "update": _cnt("update"),
                    "watch": _cnt("watch"), "risk": _cnt("risk")},
        "items": [{k: v for k, v in x.items()
                   if k not in ("affected_by_conflict", "display_family_key",
                                "verdict_rank", "family")} for x in shown],
        "suppressed": dict(suppressed),
        "unchanged_repeated_items": unchanged_repeated,
        "internal_events": internal_counts,
        "quota": {"max_daily_items": cfg["max_daily_items"],
                  "candidates_total": len(inp["cands"]),
                  "delta_items": len(inp["deltas"]),
                  "actionable_pool": len(items)},
        "input_provenance": {
            "project_context": {
                "status": "inherited_from_external_v2.11",
                "evidence": "SKILL_CANDIDATES.json 的 local_projects/project_context_health"
                            "（引擎也直接从该文件读取）"},
            "installed_context": {
                "status": "inherited_from_external_v2.11",
                "evidence": "candidate.capability_gap_match / action_type / "
                            "personalized_reason（由 external 层读取冻结底座后嵌入）"},
            "external_candidates": {"status": "direct_loaded",
                                    "path": C.CANDIDATES_PATH},
            "external_delta_semantics": {"status": "reused_readonly_v2.11",
                                         "path": os.path.join(C.EXTERNAL_SCRIPTS_DIR,
                                                              "build_context.py")},
            "feedback": {"status": "direct_loaded", "path": C.FEEDBACK_PATH},
        },
        "engine": {"auto_install": False, "language": cfg.get("language"),
                   "external_candidates_version": inp["cands_doc"].get("version")},
    }
    ctx_path = (os.path.join(out_dir, "DAILY_REPORT_CONTEXT.json")
                if out_dir != C.REPORTS_DIR else C.CONTEXT_OUT_PATH)
    save_json(machine, ctx_path)

    snap_shown = dict(prev_shown)
    byk = {c["canonical_key"]: c for c in inp["cands"]}
    for x in shown:
        src = byk[x["canonical_key"]]
        ext, proj, sec = _sigs(src)
        snap_shown[x["canonical_key"]] = {
            "date": today.isoformat(), "action": x["action"], "bucket": x["bucket"],
            "action_type": x.get("action_type"), "external_signature": ext,
            "matched_project_signature": proj, "security_signature": sec,
            "delta_cats": x["delta_cats"]}
        # §六/§七：alternatives 与 PRIMARY 共享同一个版面位，提醒状态也必须一致，
        # 否则次日 PRIMARY 冷却后 duplicate 会「换皮重现」。
        for alt in x["alternatives"]:
            ac = byk.get(alt["canonical_key"])
            if not ac:
                continue
            aext, aproj, asec = _sigs(ac)
            snap_shown[alt["canonical_key"]] = {
                "date": today.isoformat(), "action": x["action"], "bucket": x["bucket"],
                "action_type": ac.get("action_type"), "external_signature": aext,
                "matched_project_signature": aproj, "security_signature": asec,
                "delta_cats": sorted(set(inp["deltas"].get(alt["canonical_key"]) or [])),
                "shown_as_alternative_of": x["canonical_key"]}
    snap = {
        "report_date": today.isoformat(),
        "report_mode": report_mode,
        "shown_candidate_keys": [x["canonical_key"] for x in shown],
        "shown": snap_shown,
        "action_types": machine["summary"],
        "last_feedback_state": {k: v.get("status") for k, v in inp["feedback"].items()},
        "external_snapshot_version": {
            "candidates_version": inp["cands_doc"].get("version"),
            "external_generated": inp["cands_doc"].get("generated")},
        "conflicts": sorted(_conflict_projects(inp["conflicts"])),
        "conflicts_baseline": sorted(set(inp.get("conflicts_notified") or [])),
    }
    save_json(snap, snap_path)
    if not quiet:
        print(f"daily report written: {report_path}")
        print(f"machine context written: {ctx_path}")
        print(f"[{report_mode}] shown {len(shown)} / pool {len(inp['cands'])} | "
              f"install={machine['summary']['install']} "
              f"restore={machine['summary']['restore']} "
              f"update={machine['summary']['update']} watch={machine['summary']['watch']} "
              f"risk={machine['summary']['risk']} | suppressed={machine['suppressed']} | "
              f"unchanged_repeated_items={unchanged_repeated}")
    return machine, report, snap


def main():
    ap = argparse.ArgumentParser(description="Skill 日报引擎 V1.1（只读冻结输入，不安装）")
    ap.add_argument("--date", default=None, help="报告日期 YYYY-MM-DD（默认今天）")
    ap.add_argument("--out-dir", default=None, help="报告输出目录（默认 skill-daily/reports）")
    a = ap.parse_args()
    generate(date.fromisoformat(a.date) if a.date else None, a.out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
