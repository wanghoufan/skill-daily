#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Skill 日报引擎 V1（build_daily.py）——确定性，不调用 LLM，不执行任何安装（§十四/§二十二）。

流程：冻结输入（只读）→ v2.11 Delta 复用 → 5 类动作分类（§三）→ P0~P6 优先级（§四）
→ 恢复候选独立于 Top Score（§五）→ watch 冷却 / 去重（§二/§十八）→ 反馈闭环（§八/§九）
→ 项目冲突数据提醒（§七）→ 用户日报 reports/YYYY-MM-DD.md + 机器摘要
DAILY_REPORT_CONTEXT.json（§十/§二十一）。

用法：
    python3 scripts/build_daily.py [--date YYYY-MM-DD] [--out-dir DIR]
"""
import argparse
import os
import re
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C                                   # noqa: E402
from common import (load_json, save_json, parse_date)  # noqa: E402


def _load_external_build_context():
    """只读复用 v2.11 冻结语义（classify_delta / snap_key）。

    两个包都有名为 `common` 的模块，这里临时换出本引擎的 `common`，
    让 external-intelligence 的 build_context 按它自己的口径导入；
    完成后原样换回——不写 external 层任何文件。
    """
    ext_scripts = C.EXTERNAL_SCRIPTS_DIR
    saved = sys.modules.pop("common", None)
    try:
        sys.path.insert(0, ext_scripts)
        import build_context as bc_mod
    finally:
        if ext_scripts in sys.path:
            sys.path.remove(ext_scripts)
        sys.modules.pop("build_context", None)
        sys.modules.pop("match_rules", None)
        sys.modules.pop("security_gate", None)
        sys.modules.pop("common", None)
        if saved is not None:
            sys.modules["common"] = saved
    return bc_mod


bc = _load_external_build_context()
EXTERNAL_SNAPSHOT_VERSION_KEYS = ("snapshot_schema_version", "analysis_engine_version")

# ---- 用户语言（§三：简单中文；技术词只进「技术详情」层） ----
ACTION_LABEL = {"install": "建议安装", "restore": "建议恢复", "update": "建议更新",
                "watch": "继续观察", "risk": "暂不建议"}
# §四 优先级（数值越小越先展示）
PRIORITY = {"restore": 0, "risk": 1, "update": 2, "install_project": 3,
            "install_gap": 4, "watch_rising": 5, "watch_normal": 6}
REL_LABEL = {"new_capability": "没装过同类的", "complement": "和已装能力互补",
             "replacement_candidate": "可以替换现有的某个",
             "overlap": "和已装能力有重叠", "near_duplicate": "和已装能力几乎重复",
             "same_name_unverified": "名字和已装的某个相同，但还没确认是同一个",
             "same_name_different_source": "名字相同但来源不同",
             "possible_fork": "可能是已装某个的分叉", "already_installed": "已经装过"}
SEC_LABEL = {"pass": "静态检查通过（仍需人工看一眼）",
             "review_required": "有需注意项，安装前请人工复核",
             "block": "高风险，已拒绝", "unscanned": "未完成扫描，最多只能观察"}
DELTA_LABEL = {"NEW": "今天新出现", "UPDATED": "上游有真实更新", "RISING": "热度/评分明显上升",
               "FALLING": "明显下降", "SECURITY_CHANGED": "安全状态有变化",
               "SOURCE_CHANGED": "来源核验状态有变化", "MATCH_CHANGED": "与你的匹配度有变化",
               "NO_LONGER_RELEVANT": "已不在候选池",
               "METADATA_ENRICHED": "（系统内部）补全了元数据",
               "RECALCULATED": "（系统内部）重新计算", "SYSTEM_REBASELINE": "（系统内部）重建基线"}
WATCH_TRIGGERS = {"NEW", "UPDATED", "RISING", "SECURITY_CHANGED", "SOURCE_CHANGED",
                  "MATCH_CHANGED"}
INTERNAL_ONLY = {"METADATA_ENRICHED", "RECALCULATED"}


# ==========================================================================
# 输入
# ==========================================================================
def load_inputs(today):
    cands_doc = load_json(C.CANDIDATES_PATH)
    if not cands_doc:
        raise SystemExit(f"缺少冻结输入：{C.CANDIDATES_PATH}（日报引擎不重建候选池）")
    snap_doc = load_json(C.EXTERNAL_SNAPSHOT_PATH, {}) or {}
    ext_snap = snap_doc.get("candidates") if snap_doc.get("candidates") else snap_doc
    deltas = {}
    first_external = not ext_snap
    if not first_external:
        for c in cands_doc["candidates"]:
            cats = sorted(bc.classify_delta(ext_snap.get(c["canonical_key"]), bc.snap_key(c)))
            if cats:
                deltas[c["canonical_key"]] = cats
    feedback = C.load_feedback()
    daily_snap = load_json(C.DAILY_SNAPSHOT_PATH, {}) or {}
    conflicts_doc = (cands_doc.get("project_context_health") or {})
    return dict(cands=cands_doc["candidates"], cands_doc=cands_doc, deltas=deltas,
                feedback=feedback, daily_snap=daily_snap, conflicts=conflicts_doc,
                first_external=first_external, today=today)


# ==========================================================================
# 分类与过滤
# ==========================================================================
def _g(c, path, default=None):
    cur = c
    for seg in path:
        cur = (cur or {}).get(seg)
        if cur is None:
            return default
    return cur


def _install_gate_ok(c):
    """§二十 14/15 的保险带：未解除 scope/错配、strong 饱和无增量 → 不得进建议安装。"""
    gm = c.get("capability_gap_match") or {}
    if gm.get("scope_unresolved") or gm.get("product_internal_unresolved"):
        return False
    if gm.get("domain_mismatch_unresolved"):
        return False
    if (gm.get("security") or c.get("security") or {}).get("verdict") == "block":
        return False
    sat = gm.get("capability_saturation") or ""
    if sat.startswith("strong") and not sat == "strong_degraded":
        if not (c.get("personalized_reason") or {}).get("incremental_over_installed") \
                and not c.get("update_available") \
                and c.get("installed_relationship") != "replacement_candidate":
            return False
    return True


def _has_strong_project(c):
    pr = c.get("personalized_reason") or {}
    if pr.get("matched_project"):
        return True
    for m in _g(c, ("project_match", "matched_projects"), []) or []:
        if set(m.get("direct_evidence_kinds") or []) & {"strong_tech", "positioning"}:
            return True
    return False


def _conflict_projects(conflicts_doc):
    return {x.get("project") for x in (conflicts_doc.get("conflicts") or [])}


def _family_key(c):
    """poor/useful 反馈影响的可解释维度：能力族 + 同一来源仓库（§九：只影响明确维度）。"""
    return (_g(c, ("capability_gap_match", "matched_gap")) or "—",
            f"{c.get('owner')}/{c.get('repo')}")


def build_items(inp, cfg):
    """返回 (items, suppressed, internal_counts)。items 已含优先级与反馈调整，未截断。"""
    cands, deltas, feedback = inp["cands"], inp["deltas"], inp["feedback"]
    daily_snap, today = inp["daily_snap"], inp["today"]
    shown = daily_snap.get("shown") or {}
    first_daily = not daily_snap
    conflict_names = _conflict_projects(inp["conflicts"])
    poor_gaps, poor_repos = set(), set()
    useful_gaps, useful_repos = set(), set()
    by_key = {c["canonical_key"]: c for c in cands}
    for k, fb in feedback.items():
        c = by_key.get(k)
        if not c:
            continue
        gap, repo = _family_key(c)
        if fb.get("status") == "poor":
            poor_gaps.add(gap) if gap != "—" else None
            poor_repos.add(repo)
        elif fb.get("status") == "useful":
            useful_gaps.add(gap) if gap != "—" else None
            useful_repos.add(repo)

    items, suppressed = [], {"unchanged_watch": 0, "metadata_only": 0, "feedback": 0}
    internal_counts = {"METADATA_ENRICHED": 0, "RECALCULATED": 0, "SYSTEM_REBASELINE": 0}

    def _suppressed_by_feedback(key, c):
        fb = feedback.get(key)
        if not fb:
            return None
        st, when = fb.get("status"), parse_date(fb.get("updated_at"))
        gap = C.days_between(when, today)
        if st == "installed":
            return "已按你的反馈标记为已安装，等底座更新后以 Canonical 为准"
        if st in ("ignored", "deferred"):
            days = cfg["ignored_repeat_days"] if st == "ignored" else cfg["deferred_repeat_days"]
            if gap is not None and gap < days:
                label = "忽略" if st == "ignored" else "暂缓"
                return f"你之前标记为「{label}」，{days} 天内不再重复"
        if st == "removed" and gap is not None and gap < cfg["removed_cooldown_days"]:
            return (f"你之前移除过同类 Skill，{cfg['removed_cooldown_days']} 天内"
                    "不重新推荐同一个")
        return None

    def _mk(key, bucket, c, why_today, extra_note=""):
        cats = deltas.get(key) or []
        gap_f, repo_f = _family_key(c)
        prio = PRIORITY[bucket]
        fb_effect = ""
        if (gap_f != "—" and gap_f in poor_gaps) or repo_f in poor_repos:
            prio += 2
            fb_effect = ("你之前把同类 Skill 标记为「不好用」（同能力族 "
                         f"{gap_f if gap_f in poor_gaps else '—'}/同来源 {repo_f}），"
                         "因此本次降低展示优先级。")
        elif (gap_f != "—" and gap_f in useful_gaps) or repo_f in useful_repos:
            prio = max(0, prio - 1)
            fb_effect = (f"你之前把同类 Skill 标记为「好用」（同来源 {repo_f} 或同能力族），"
                         "因此本次提升展示优先级。")
        pr = c.get("personalized_reason") or {}
        pm = c.get("project_match") or {}
        if not pr.get("matched_project") and (pm.get("matched_projects") or []):
            m0 = pm["matched_projects"][0]
            pr = dict(pr, matched_project=f"{m0['project']}（match={m0['match_score']}）")
        if not pr.get("fills_gap"):
            needs = pm.get("matched_needs") or []
            gap = _g(c, ("capability_gap_match", "matched_gap"))
            pr = dict(pr, fills_gap=("命中需求：" + "/".join(needs[:3]) if needs else "")
                      + (f"；能力缺口：{gap}" if gap else ""))
        items.append({
            "canonical_key": key,
            "skill_name": c.get("skill_name"),
            "bucket": bucket,
            "action": ("restore" if bucket == "restore" else
                       "install" if bucket.startswith("install") else
                       "update" if bucket == "update" else
                       "risk" if bucket == "risk" else "watch"),
            "priority": prio,
            "one_line_explanation": C.clean_desc(c.get("description")),
            "why_today": why_today,
            "matched_project": pr.get("matched_project") or "",
            "fills_gap": pr.get("fills_gap") or "",
            "installed_overlap": REL_LABEL.get(c.get("installed_relationship"),
                                               c.get("installed_relationship") or ""),
            "security_status": SEC_LABEL.get(_g(c, ("security", "verdict")), "未扫描"),
            "source": f"{c.get('owner')}/{c.get('repo')}",
            "repo": f"https://github.com/{c.get('owner')}/{c.get('repo')}",
            "skill_path": c.get("path") or "",
            "source_url": c.get("source_url") or "",
            "source_tier": c.get("source_tier"),
            "personalized_score": c.get("score"),
            "delta_cats": cats,
            "feedback_effect": fb_effect,
            "feedback_reason": fb_effect,
            "extra_note": extra_note,
            "affected_by_conflict": bool(conflict_names &
                                         {m.get("project") for m in
                                          (_g(c, ("project_match", "matched_projects"), []) or [])}),
        })

    for c in cands:
        key = c["canonical_key"]
        at = c.get("action_type") or "watch"
        cats = set(deltas.get(key) or [])
        # §六：纯系统内部事件不算外部新闻
        if cats and cats <= INTERNAL_ONLY:
            suppressed["metadata_only"] += 1
        # 风险 / 暂不建议（§三.5：只有今天状态新变化才进）
        if ("SECURITY_CHANGED" in cats and
                (_g(c, ("security", "verdict")) == "block"
                 or _g(c, ("security", "risk_level")) == "high")):
            note = _suppressed_by_feedback(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _mk(key, "risk", c, "安全状态今天有变化，且判定为高风险",
                "原因：高风险（静态审查发现真要求执行的危险行为）")
            continue
        if at == "reject" and ("NEW" in cats or "SECURITY_CHANGED" in cats):
            _mk(key, "risk", c, "今天被安全 Gate 拒绝",
                f"原因：{(c.get('recommendation_reason') or '')[:80]}")
            continue
        # 恢复 / 修复（§五：独立于 Top Score，不看 min_score）
        if at == "restore_candidate":
            note = _suppressed_by_feedback(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _mk(key, "restore", c,
                "已装能力的正本缺失，官方同血缘版本可以恢复"
                + ("；今天上游有新动态" if cats & WATCH_TRIGGERS else ""),
                "这是已有能力的恢复，不是发现新 Skill")
            continue
        # 建议更新（血缘确认由 action_type 的产生逻辑保证）
        if at == "update_candidate":
            note = _suppressed_by_feedback(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            _mk(key, "update", c, "已装 Skill 的上游发布了确认同血缘的新版本")
            continue
        # 建议安装
        if at == "new_install":
            note = _suppressed_by_feedback(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            if not _install_gate_ok(c):
                continue                     # §二十 14/15：门在日报层再核一遍
            bucket = "install_project" if _has_strong_project(c) else "install_gap"
            why = ("命中你当前项目的真实需求" if bucket == "install_project"
                   else "补你现在没有/很弱的能力")
            _mk(key, bucket, c, "今天进入安装候选：" + why)
            continue
        # 继续观察（§三.4：只有变化事件才值得占用日报）
        if at == "watch" and c.get("recommendation") not in ("watch", "install_candidate"):
            continue
        if at == "watch":
            trigger = cats & WATCH_TRIGGERS
            if not trigger and not first_daily:
                suppressed["unchanged_watch"] += 1
                continue
            prev = shown.get(key)
            if prev and not trigger:
                gap = C.days_between(parse_date(prev.get("date")), today)
                if gap is not None and gap < cfg["watch_repeat_days"]:
                    suppressed["unchanged_watch"] += 1
                    continue
            note = _suppressed_by_feedback(key, c)
            if note:
                suppressed["feedback"] += 1
                continue
            bucket = ("watch_rising" if trigger & {"RISING", "NEW", "UPDATED"}
                      or _has_strong_project(c) else "watch_normal")
            why = "、".join(DELTA_LABEL[t] for t in sorted(trigger)) or "首轮建基线：先给你看一眼"
            extra = ""
            if trigger and _has_strong_project(c) and not trigger & {"NEW"}:
                extra = "你当前的项目今天用上了它的能力（§三.4：项目刚命中值得看）"
            _mk(key, bucket, c, why, extra)

    # 内部事件计数（§六/§十：只作「今天不用处理的变化」脚注，不占日报位）
    for key, cats in deltas.items():
        for k in internal_counts:
            if k in cats:
                internal_counts[k] += 1
    # 引擎换代检测：外部数据版本变化 = SYSTEM_REBASELINE（按 v2.11 语义不作外部新闻）
    prev_ver = ((inp["daily_snap"].get("external_snapshot_version") or {})
                .get("candidates_version"))
    cur_ver = inp["cands_doc"].get("version")
    if (prev_ver and str(prev_ver) != str(cur_ver)) or inp.get("first_external"):
        internal_counts["SYSTEM_REBASELINE"] = max(1, internal_counts["SYSTEM_REBASELINE"])
    items.sort(key=lambda x: (x["priority"], -(x["personalized_score"] or 0),
                              x["canonical_key"]))
    return items, suppressed, internal_counts


# ==========================================================================
# 渲染（§十/§十一/§十二/§十三）
# ==========================================================================
def _zh_one_line(it):
    """§十一：第一层必须是普通用户能一眼看懂的中文；原文只进技术详情。"""
    n = it["skill_name"]
    if it["action"] == "restore":
        return f"这是你已装能力「{n}」的官方同来源版本；本机正本缺失，可以恢复，不是新 Skill。"
    if it["action"] == "update":
        return f"你已装的「{n}」上游出了新版本（同血缘已确认），可以更新。"
    if it["action"] == "risk":
        return f"「{n}」今天安全/来源状态变差，暂时不要装。"
    if it["action"] == "install":
        gap = (it["fills_gap"] or "").replace("能力族 ", "")
        return f"「{n}」能补你的能力缺口：{gap or '见下方项目匹配'}。"
    return f"「{n}」今天出现了值得注意的变化，先观察，不用动手。"


def _card(it):
    L = [f"### {it['skill_name']}", ""]
    L.append(f"一句话：{_zh_one_line(it)}")
    L.append("")
    L.append(f"为什么今天出现：{it['why_today']}")
    L.append("")
    if it["action"] in ("install", "watch"):
        L.append(f"对你有什么用：{it['fills_gap'] or '（见技术详情里的命中需求）'}")
    if it["action"] == "restore":
        L.append("对你有什么用：把之前缺的那块能力补回来，不影响你现有配置。")
    if it["action"] == "update":
        L.append("对你有什么用：拿到上游的修复和新功能。")
    if it["action"] == "risk":
        L.append(f"为什么暂不建议：{it['extra_note']}")
    L.append("")
    L.append(f"对哪个项目有用：{it['matched_project'] or '没对上具体项目，属于通用能力'}")
    L.append("")
    L.append(f"和已装 Skill 是否重复：{it['installed_overlap']}")
    L.append("")
    L.append(f"安全：{it['security_status']}")
    L.append("")
    if it["action"] != "risk":
        L.append(f"动作：{ACTION_LABEL[it['action']]}（V1 只给建议；请你在 Skill Manager 里人工确认后执行）")
    else:
        L.append("动作：暂不建议")
    L.append("")
    src = it["source_url"] or f"{it['repo']}/tree/main/{it['skill_path']}"
    L.append(f"来源：{src}")
    L.append("")
    if it["feedback_effect"]:
        L.append(f"你的反馈影响：{it['feedback_effect']}")
        L.append("")
    L.append("<details><summary>技术详情（可选）</summary>")
    L.append("")
    L.append(f"- canonical_key: `{it['canonical_key']}`｜source_tier=T{it['source_tier']}"
             f"｜score={it['personalized_score']}｜delta={','.join(it['delta_cats']) or '—'}")
    L.append(f"- repo={it['source']}｜skill_path={it['skill_path'] or '—'}")
    if it.get("one_line_explanation"):
        L.append(f"- 原文描述：{it['one_line_explanation']}")
    L.append("</details>")
    L.append("")
    return L


def render_report(today, items, suppressed, internal_counts, inp, cfg):
    L = [f"# Skill 日报｜{today.isoformat()}", ""]
    if not items:
        L.append("今天没有需要你处理的 Skill 变化。")
        L.append("")
    else:
        L.append(f"今天有 {len(items)} 件值得看。")
        L.append("")
        order = {"restore": "建议恢复", "risk": "暂不建议", "update": "建议更新",
                 "install_project": "建议安装", "install_gap": "建议安装",
                 "watch_rising": "继续观察", "watch_normal": "继续观察"}
        groups, seen = [], set()
        for it in items:
            gkey = order[it["bucket"]]
            if gkey not in seen:
                seen.add(gkey)
                groups.append(gkey)
        for g in groups:
            L.append(f"## {g}")
            L.append("")
            for it in [x for x in items if order[x["bucket"]] == g]:
                L += _card(it)
                L.append("---")
                L.append("")
        L.pop() if L and L[-1] == "" else None
    # §七：冲突不静默、也不天天刷屏
    conflict_names = _conflict_projects(inp["conflicts"])
    prev_conflicts = set(inp["daily_snap"].get("conflicts") or [])
    new_conflicts = conflict_names - prev_conflicts
    affecting = any(it["affected_by_conflict"] for it in items)
    if conflict_names and (new_conflicts or affecting):
        who = "、".join(sorted(new_conflicts or conflict_names))
        L.append("数据提醒：")
        L.append(f"{who} 项目的描述和技术栈不一致，因此今天没有用冲突技术作为推荐依据。"
                 "（引擎不修改项目画像，只标记；请上游 Profile 修正）")
        L.append("")
    # §六/§十：内部维护信息只在需要解释系统行为时给一行
    internal_total = sum(internal_counts.values())
    if cfg.get("show_internal_system_events") or (internal_total and items):
        L.append("## 今天不用处理的变化")
        L.append("")
        _foot = {"SYSTEM_REBASELINE": "系统重新建立基线", "METADATA_ENRICHED": "元数据补全",
                 "RECALCULATED": "引擎重算（系统内部）"}
        for k in ("SYSTEM_REBASELINE", "METADATA_ENRICHED", "RECALCULATED"):
            if internal_counts.get(k):
                L.append(f"- {_foot[k]}：{internal_counts[k]}")
        L.append("")
    L.append(f"> 冷却与去重：{suppressed['unchanged_watch']} 条无变化的观察项按 "
             f"{cfg['watch_repeat_days']} 天规则未重复；"
             f"{suppressed['feedback']} 条被你的反馈规则压住；"
             f"{suppressed['metadata_only']} 条只是系统内部元数据补全。")
    L.append("")
    L.append("> V1 引擎不安装 / 不删除 / 不升级任何 Skill；所有动作由你在 Skill Manager 人工确认。")
    L.append("")
    return "\n".join(L)


# ==========================================================================
# 主入口
# ==========================================================================
def generate(today=None, out_dir=None, quiet=False, snapshot_path=None):
    cfg = C.load_config()
    today = today or date.today()
    # 测试/隔离运行：out_dir 重定向时，快照状态与机器摘要都落在该目录内，
    # 绝不写真实 data/state（真实运行才用默认路径）。
    redirected = bool(out_dir and os.path.abspath(out_dir) != os.path.abspath(C.REPORTS_DIR))
    snap_path = snapshot_path or (
        os.path.join(out_dir, "state", "daily_snapshot.json")
        if redirected and out_dir else C.DAILY_SNAPSHOT_PATH)
    inp = load_inputs(today)
    items, suppressed, internal_counts = build_items(inp, cfg)
    shown = items[: int(cfg["max_daily_items"])]           # §二十 17：超 10 取最高优先级
    report = render_report(today, shown, suppressed, internal_counts, inp, cfg)

    out_dir = out_dir or C.REPORTS_DIR
    os.makedirs(out_dir, exist_ok=True)
    report_path = os.path.join(out_dir, f"{today.isoformat()}.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    def _cnt(b):
        return sum(1 for x in shown if x["bucket"].startswith(b))
    machine = {
        "generated": today.isoformat(),
        "summary": {
            "total_items": len(shown),
            "install": _cnt("install"),
            "restore": _cnt("restore"),
            "update": _cnt("update"),
            "watch": _cnt("watch"),
            "risk": _cnt("risk"),
        },
        "items": [{k: v for k, v in x.items() if k != "affected_by_conflict"}
                  for x in shown],
        "suppressed": {
            "unchanged_watch": suppressed["unchanged_watch"],
            "metadata_only": suppressed["metadata_only"],
            "feedback": suppressed["feedback"],
        },
        "internal_events": internal_counts,
        "quota": {"max_daily_items": cfg["max_daily_items"],
                  "candidates_total": len(inp["cands"]),
                  "delta_items": len(inp["deltas"]),
                  "actionable_pool": len(items)},
        "engine": {"auto_install": False, "language": cfg.get("language"),
                   "external_candidates_version": inp["cands_doc"].get("version")},
    }
    ctx_path = (os.path.join(out_dir, "DAILY_REPORT_CONTEXT.json")
                if out_dir != C.REPORTS_DIR else C.CONTEXT_OUT_PATH)
    save_json(machine, ctx_path)

    # §十七：日报状态（冷却用），合并历史 shown，不重造 External Delta
    snap_shown = dict(inp["daily_snap"].get("shown") or {})
    for x in shown:
        snap_shown[x["canonical_key"]] = {"date": today.isoformat(),
                                          "action": x["action"], "bucket": x["bucket"]}
    snap = {
        "report_date": today.isoformat(),
        "shown_candidate_keys": [x["canonical_key"] for x in shown],
        "shown": snap_shown,
        "action_types": machine["summary"],
        "last_feedback_state": {k: v.get("status") for k, v in inp["feedback"].items()},
        "external_snapshot_version": {
            "candidates_version": inp["cands_doc"].get("version"),
            "external_generated": inp["cands_doc"].get("generated")},
        "conflicts": sorted(_conflict_projects(inp["conflicts"])),
    }
    save_json(snap, snap_path)
    if not quiet:
        print(f"daily report written: {report_path}")
        print(f"machine context written: {ctx_path}")
        print(f"shown {len(shown)} / pool {len(inp['cands'])} | "
              f"install={machine['summary']['install']} restore={machine['summary']['restore']} "
              f"update={machine['summary']['update']} watch={machine['summary']['watch']} "
              f"risk={machine['summary']['risk']} | "
              f"suppressed={machine['suppressed']}")
    return machine, report, snap


def main():
    ap = argparse.ArgumentParser(description="Skill 日报引擎 V1（只读冻结输入，不安装）")
    ap.add_argument("--date", default=None, help="报告日期 YYYY-MM-DD（默认今天）")
    ap.add_argument("--out-dir", default=None, help="报告输出目录（默认 skill-daily/reports）")
    a = ap.parse_args()
    generate(date.fromisoformat(a.date) if a.date else None, a.out_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
