# Skill 日报引擎 V1（skill-daily）

把已冻结的四类输入合成一份「每天只看 5～10 条，就知道今天有什么值得装 / 恢复 / 更新 / 观察」
的个性化 Skill 日报。**V1 不自动安装任何 Skill**：所有安装 / 删除 / 升级仍由人在
Skill Manager 里确认执行（§十四：`auto_install` 恒为 false，代码里无任何安装/删除调用）。

## 目录（§十六，整合在本仓库内，不建平行仓）

```
skill-daily/
├── README.md                     ← 本文件
├── config/daily.json             上限 / 各类冷却周期 / 开关（§十八/§十九，全部配置化）
├── data/
│   ├── SKILL_FEEDBACK.json       每技能最新反馈状态（机器读取）
│   ├── SKILL_FEEDBACK_HISTORY.jsonl  一行一事件的历史（§一 D）
│   └── state/daily_snapshot.json 已展示记录（去重刷屏用，§十七；不重造 External Delta）
├── scripts/
│   ├── common.py                 输入定位（冻结层只读）+ 反馈存储 + 日期工具
│   ├── build_daily.py            引擎主体（确定性，无 LLM）
│   └── feedback.py               反馈录入 CLI
├── reports/YYYY-MM-DD.md         用户日报（§十模板：一句话中文在第一层，技术词只进「技术详情」）
├── DAILY_REPORT_CONTEXT.json     机器摘要（§二十一；供以后自动推送只读这一份 + Markdown）
└── tests/test_daily.py           §二十 20 项测试（合成输入，在临时目录跑，不碰真实状态）
```

## 用法

```bash
P=python3   # 需要 3.12+
$P scripts/build_daily.py                 # 生成今天：reports/ + DAILY_REPORT_CONTEXT.json
$P scripts/build_daily.py --date 2026-09-24 --out-dir /tmp/x   # 隔离运行（状态也重定向）
$P scripts/feedback.py <canonical_key> <status> ["备注"]        # status: installed|tried|useful|poor|ignored|removed|deferred
$P scripts/feedback.py --list
$P tests/test_daily.py                    # 20 项测试
```

## 数据流与边界

- 输入（全部**只读**）：`SKILL_CONTEXT` / `INSTALLED_SKILLS_CONTEXT` / `SKILL_SOURCE_MAP`
  经 `external-intelligence/` 已消化后的 `SKILL_CANDIDATES.json`（version 11）、
  `EXTERNAL_SKILLS_CONTEXT.md` 机器块；Delta 直接复用 v2.11 的 `classify_delta`
  语义（NEW/UPDATED/…/METADATA_ENRICHED/SYSTEM_REBASELINE，§六），绝不回退成
  「字段 != 就算 UPDATED」。
- 五类动作（§三）：建议安装 / 建议恢复 / 建议更新 / 继续观察 / 暂不建议；
  优先级 P0~P6 按「用户今天要处理什么」排，不按总分（§四/§五：restore 独立于 Top Score）。
- 去重（§二/§十八）：日报正文只放变化与可操作项，不重发 Top30；无变化的 watch 按
  `watch_repeat_days`（默认 7）冷却；security 变化 / update / restore / 项目新命中可突破冷却。
- 反馈闭环（§八/§九）：每条 adjustment 必须给得出 `feedback_reason`，只作用于
  明确维度（同能力族 / 同来源仓 / 同 canonical_key 冷却）；不做黑箱画像。
- 项目画像冲突（§七）：读 `PROJECT_CONTEXT_HEALTH`，仅新增冲突或影响当日推荐时
  输出一行「数据提醒」；引擎不改项目画像。
- 成本（§十五）：先读 Context 层与动作字段，shortlist 才回查 `SKILL_CANDIDATES.json`
  完整记录；不每天让 LLM 读 1,100 条。
- 确定性（§二十二）：全部规则代码化；相同输入 → 逐字节相同的 shortlist 与日报
  （`tests/test_daily.py::test_t20` 断言）。LLM 仅可选地做「一句话/why_today」润色，
  V1 模板化生成即可。

## 扩展位（本轮明确不做，§二十四）

自动安装 / Web Dashboard / 移动 App / Slack / 邮件推送 / AI 聊天界面 / 云数据库 /
多用户 / 企业权限 / 自动删除 —— 先闭环「输入 → Delta → 动作 → 个性化过滤 →
5~10 条日报 → 反馈」。

## 与中央 Skill 仓库规则的关系

本目录是脚本引擎，不是 Skill 工件（不新增 SKILL.md，故不涉及 `SKILL-REGISTRY.md` 登记；
若以后把「跑日报」封装成 Skill，按 `SKILL-CONTRIBUTION.md` 入库并登记）。
