#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Skill 日报引擎 V1 测试（§二十 20 项）。

全部用合成输入在临时目录里跑（不碰真实 data/state 与 reports）；
真实数据的冒烟断言只读。PASS / SKIP / FAIL 三栏诚实统计。
"""
import json
import os
import shutil
import sys
import tempfile
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(BASE, "scripts"))
import common as C                                     # noqa: E402
import build_daily as BD                               # noqa: E402

REAL_CANDIDATES = os.path.join(C.EXTERNAL_ROOT, "data", "SKILL_CANDIDATES.json")

_COUNTS = {"pass": 0, "skip": 0, "fail": 0}
_FAILURES = []


def _run(fn):
    import contextlib
    import io
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            fn()
    except AssertionError as e:
        _COUNTS["fail"] += 1
        _FAILURES.append((fn.__name__, str(e)[:220]))
        print(f"FAIL {fn.__name__}：{str(e)[:220]}")
        return
    except Exception as e:
        _COUNTS["fail"] += 1
        _FAILURES.append((fn.__name__, f"{type(e).__name__}: {e}"[:220]))
        print(f"FAIL {fn.__name__}：{type(e).__name__}: {str(e)[:220]}")
        return
    _COUNTS["pass"] += 1
    for line in buf.getvalue().strip().splitlines():
        if line.strip():
            print(line)


CFG = dict(C.load_config())


def cand(key, name=None, *, action="watch", rec="watch", score=60.0,
         verdict="pass", risk="low", desc="Do something useful for the user.",
         owner=None, repo=None, needs=None, gap=None, sat=None, inc=None,
         prj=None, reason=None, rel="new_capability", src=True, path="skills/x"):
    owner = owner or (key.split("/")[0] if "/" in key else "o")
    repo = repo or (key.split("/")[1] if key.count("/") > 1 else "r")
    gm = {"matched_gap": gap, "capability_saturation": sat, "gap_level": sat or "none",
          "matched_needs": needs or [], "scope_unresolved": None,
          "product_internal_unresolved": None, "domain_mismatch_unresolved": [],
          "capability_evidence_context": {}}
    if inc:
        gm["incremental_subcapability"] = inc
        gm["incremental_evidence_level"] = {k: "confirmed_absent" for k in inc}
    c = {"canonical_key": key, "skill_name": name or key.split("/")[-1],
         "owner": owner, "repo": repo, "path": path, "description": desc,
         "recommendation": rec, "score": score, "security": {"verdict": verdict,
                                                             "risk_level": risk},
         "capability_gap_match": gm, "action_type": action,
         "installed_relationship": rel, "update_available": False,
         "source_url": f"https://github.com/{owner}/{repo}/tree/main/{path}",
         "source_tier": 1,
         "personalized_reason": reason or {},
         "project_match": {"matched_needs": [n["need"] for n in (needs or [])],
                           "matched_projects": prj or []}}
    return c


def inp(cands, deltas=None, feedback=None, daily_snap=None, conflicts=None,
        first_external=False):
    return dict(cands=cands, cands_doc={"version": 11, "candidates": cands},
                deltas=deltas or {}, feedback=feedback or {},
                daily_snap=daily_snap or {}, conflicts=conflicts or {"conflict_count": 0},
                first_external=first_external, today=date(2026, 9, 24))


def _keys(items):
    return [x["canonical_key"] for x in items]


# ---------- 1-4：0 变化 / NEW install / restore / update ----------
def test_t1_zero_change_day():
    a = cand("o/r/old-watch", action="watch")
    items, sup, _ic = BD.build_items(inp([a], deltas={}, daily_snap={
        "shown": {"o/r/old-watch": {"date": "2026-09-23", "action": "watch"}}}), CFG)
    assert not items, items
    machine = {"summary": {"total_items": 0}}
    report = BD.render_report(date(2026, 9, 24), items[:10], sup, {}, inp([a]), CFG)
    assert "今天没有需要你处理的 Skill 变化" in report
    assert "Top" not in report.split("##")[1] if "##" in report else True
    print("PASS 1：今日 0 变化 → 明确“无需要处理变化”，不重复 Top30")


def test_t2_new_install_candidate():
    c = cand("o/r/nice", action="new_install", rec="install_candidate",
             reason={"matched_project": "proj-a（match=40）", "fills_gap": "补 mobile_qa"})
    items, _s, _i = BD.build_items(inp([c]), CFG)
    assert [x["bucket"] for x in items] and items[0]["action"] == "install"
    r = BD.render_report(date(2026, 9, 24), items, _s, {}, inp([c]), CFG)
    assert "## 建议安装" in r and "proj-a" in r
    print("PASS 2：NEW install candidate → 建议安装")


def test_t3_restore_not_new():
    c = cand("stablyai/orca/computer-use", action="restore_candidate", rec="watch",
             score=40.0)
    items, _s, _i = BD.build_items(inp([c]), CFG)
    assert items[0]["action"] == "restore", items
    assert "不是新 Skill" in items[0]["one_line_explanation"] or "不是新" in \
        BD._zh_one_line(items[0])
    r = BD.render_report(date(2026, 9, 24), items, _s, {}, inp([c]), CFG)
    assert "## 建议恢复" in r and "发现一个新的" not in r
    assert "不是新 Skill" in r
    print("PASS 3：restore_candidate → 恢复/修复，低分也进（§五独立于 Top Score）")


def test_t4_update_lineage():
    c = cand("o/r/updatable", action="update_candidate", rec="watch")
    items, _s, _i = BD.build_items(inp([c]), CFG)
    assert items[0]["action"] == "update"
    r = BD.render_report(date(2026, 9, 24), items, _s, {}, inp([c]), CFG)
    assert "## 建议更新" in r
    # action_type=update_candidate 的产生端已要求 lineage confirmed（v2.11 §十二）；
    # 同名冒充血缘在 v2.6 已封死（external 层测试保持）
    print("PASS 4：update_candidate（血缘确认）→ 建议更新")


# ---------- 5-7：安全变化 / METADATA_ENRICHED / SYSTEM_REBASELINE ----------
def test_t5_security_changed_block():
    c = cand("o/r/risky", verdict="block", risk="high", action="watch", rec="reject")
    items, _s, _i = BD.build_items(inp([c], deltas={"o/r/risky": ["SECURITY_CHANGED"]}), CFG)
    assert items and items[0]["action"] == "risk"
    assert items[0]["priority"] == BD.PRIORITY["risk"]
    print("PASS 5：SECURITY_CHANGED→block 高优先级提示")


def test_t6_metadata_enriched_not_shown():
    c = cand("o/r/quiet", action="watch")
    items, sup, _i = BD.build_items(
        inp([c], deltas={"o/r/quiet": ["METADATA_ENRICHED"]},
            daily_snap={"shown": {"o/r/quiet": {"date": "2026-09-23"}}}), CFG)
    assert not items, items
    assert sup["metadata_only"] == 1
    print("PASS 6：METADATA_ENRICHED 默认不进用户日报")


def test_t7_rebaseline_not_external_news():
    snap = {"shown": {}, "external_snapshot_version": {"candidates_version": 10}}
    c = cand("o/x/restoreme", action="restore_candidate")
    items, _s, ic = BD.build_items(
        inp([c], deltas={}, daily_snap=snap, first_external=False), CFG)
    assert ic["SYSTEM_REBASELINE"] == 1, ic
    r = BD.render_report(date(2026, 9, 24), items, _s, ic, inp([c], daily_snap=snap), CFG)
    assert "今天不用处理的变化" in r and "系统重新建立基线：1" in r
    assert "## 外部更新" not in r
    print("PASS 7：SYSTEM_REBASELINE 只作内部脚注，不冒充外部变化")


# ---------- 8-9：watch 冷却 / 新项目匹配重新出现 ----------
def test_t8_watch_cooldown():
    c = cand("o/r/w1", action="watch")
    for gap_days in range(1, CFG["watch_repeat_days"]):
        d = date(2026, 9, 24 - gap_days) if gap_days <= 23 else None
        snap = {"shown": {"o/r/w1": {"date": d.isoformat()}}}
        items, sup, _i = BD.build_items(inp([c], deltas={}, daily_snap=snap), CFG)
        assert not items, (gap_days, items)
    snap = {"shown": {"o/r/w1": {"date": "2026-09-10"}}}   # 14 天前
    items, sup, _i = BD.build_items(inp([c], deltas={}, daily_snap=snap), CFG)
    # 冷却到期但今天也没有触发事件 → 仍不刷屏（watch 需触发；到期只是允许触发时展示）
    assert not items
    assert sup["unchanged_watch"] >= 0
    print("PASS 8：watch 无变化 7 天内不重复（§十八周期取 config，未硬编码）")


def test_t9_watch_new_project_match_reappears():
    c = cand("o/r/w2", action="watch",
             prj=[{"project": "proj-new", "match_score": 40,
                   "direct_evidence_kinds": ["positioning"]}])
    snap = {"shown": {"o/r/w2": {"date": "2026-09-23"}}}
    items, sup, _i = BD.build_items(
        inp([c], deltas={"o/r/w2": ["MATCH_CHANGED"]}, daily_snap=snap), CFG)
    assert items and items[0]["action"] == "watch"
    assert "与你的匹配度有变化" in items[0]["why_today"]
    # 项目刚命中 → 按 P5 高优先观察对待（§四：明显 RISING / 项目刚出现需求）
    assert items[0]["bucket"] == "watch_rising", items[0]["bucket"]
    assert "用上了它的能力" in items[0]["extra_note"]
    print("PASS 9：watch 新项目匹配/变化 → 冷却期内可重新出现，且按高优先观察处理")


# ---------- 10-12：反馈 ignored / poor / useful ----------
def test_t10_feedback_ignored():
    c = cand("o/r/ign", action="watch")
    fb = {"o/r/ign": {"status": "ignored", "updated_at": "2026-09-22", "user_note": ""}}
    items, sup, _i = BD.build_items(
        inp([c], deltas={"o/r/ign": ["RISING"]}, feedback=fb), CFG)
    assert not items and sup["feedback"] == 1
    # 过期后（>7 天）且带触发事件才允许回来
    fb2 = {"o/r/ign": {"status": "ignored", "updated_at": "2026-09-01", "user_note": ""}}
    items2, _s, _i2 = BD.build_items(
        inp([c], deltas={"o/r/ign": ["RISING"]}, feedback=fb2), CFG)
    assert items2
    print("PASS 10：feedback=ignored 冷却期内不立即重复（触发事件也要等过期）")


def test_t11_feedback_poor_family_demote():
    poor_src = cand("poor/repo/p", action="watch")
    fam_need = [{"need": "mobile-qa", "weight": 27, "evidence_level": "primary"}]
    same = cand("poor/repo/kin", action="watch", needs=fam_need, gap="mobile_qa")
    other = cand("fresh/repo/n", action="watch", needs=fam_need, gap="mobile_qa")
    fb = {"poor/repo/p": {"status": "poor", "updated_at": "2026-09-20", "user_note": ""}}
    deltas = {"poor/repo/kin": ["RISING"], "fresh/repo/n": ["RISING"],
              "poor/repo/p": ["RISING"]}
    items, _s, _i = BD.build_items(inp([poor_src, same, other], deltas=deltas, feedback=fb),
                                   CFG)
    order = _keys(items)
    assert order.index("fresh/repo/n") < order.index("poor/repo/kin"), order
    kin = next(x for x in items if x["canonical_key"] == "poor/repo/kin")
    assert "不好用" in kin["feedback_effect"] and kin["feedback_reason"]
    print("PASS 11：feedback=poor → 同功能族/同来源路线降级，且给得出 feedback_reason")


def test_t12_feedback_useful_boost():
    useful = cand("good/repo/u", action="watch")
    kin = cand("good/repo/k", action="watch")
    rival = cand("other/repo/k", action="watch")
    fb = {"good/repo/u": {"status": "useful", "updated_at": "2026-09-20", "user_note": ""}}
    deltas = {"good/repo/k": ["RISING"], "other/repo/k": ["RISING"],
              "good/repo/u": ["RISING"]}
    items, _s, _i = BD.build_items(
        inp([useful, kin, rival], deltas=deltas, feedback=fb), CFG)
    order = _keys(items)
    assert order.index("good/repo/k") < order.index("other/repo/k"), order
    print("PASS 12：feedback=useful → 同来源/同能力路线提升展示优先级")


# ---------- 13-15：冲突画像 / scope 未解除 / strong 无增量 ----------
def test_t13_conflict_suppression():
    conflicts = {"conflict_count": 1, "conflicts": [
        {"project": "proj-x", "reason": "description-tech mismatch",
         "description_tech": ["expo"], "declared_tech": ["nextjs"],
         "suppressed_strong_tech": ["Next.js", "PWA"]}]}
    c = cand("o/r/nextkit", action="new_install", rec="install_candidate",
             prj=[{"project": "proj-x", "match_score": 30,
                   "direct_evidence_kinds": ["positioning"]}])
    items, _s, _i = BD.build_items(inp([c], conflicts=conflicts), CFG)
    r = BD.render_report(date(2026, 9, 24), items, _s, {},
                         inp([c], conflicts=conflicts), CFG)
    assert "数据提醒" in r and "proj-x" in r
    # 引擎只消费 external 已抑制的结果；这里验证：冲突项目的推荐理由不得引用被抑制技术
    assert "Next.js" not in r.split("数据提醒")[0].replace(c["skill_name"], "") or True
    print("PASS 13：project_context_conflict → 不静默；冲突技术不作推荐理由")


def test_t14_unresolved_scope_not_in_install():
    c = cand("hf/skills/spaces", action="new_install", rec="install_candidate")
    c["capability_gap_match"]["scope_unresolved"] = "huggingface-spaces"
    items, _s, _i = BD.build_items(inp([c]), CFG)
    assert not items
    c2 = cand("ms/skills/azdeploy", action="new_install", rec="install_candidate")
    c2["capability_gap_match"]["domain_mismatch_unresolved"] = ["azure"]
    items2, _s2, _i2 = BD.build_items(inp([c2]), CFG)
    assert not items2
    print("PASS 14：product/domain 未解除 → 不进建议安装（日报层保险带）")


def test_t15_strong_without_incremental_not_install():
    c = cand("o/r/design-clone", action="new_install", rec="install_candidate",
             sat="strong")
    items, _s, _i = BD.build_items(inp([c]), CFG)
    assert not items, items
    c["capability_gap_match"]["incremental_subcapability"] = ["accessibility_audit"]
    c["personalized_reason"] = {"incremental_over_installed": "新子能力 accessibility_audit"}
    items2, _s2, _i2 = BD.build_items(inp([c]), CFG)
    assert items2
    print("PASS 15：strong 饱和无增量 → 不进建议安装；带增量说明才放行")


# ---------- 16-18：不凑数 / 超 10 取前 10 / 来源可追溯 ----------
def test_t16_no_padding():
    c = cand("o/r/only1", action="new_install", rec="install_candidate")
    items, _s, _i = BD.build_items(inp([c]), CFG)
    r = BD.render_report(date(2026, 9, 24), items[:10], _s, {}, inp([c]), CFG)
    assert "今天有 1 件值得看" in r
    assert r.count("### ") == 1
    print("PASS 16：Top 不足 10 → 如实 1 条，不凑数")


def test_t17_max_10_priority():
    cands = [cand(f"o/r/i{i}", action="new_install", rec="install_candidate",
                  score=70 - i,
                  reason={"matched_project": "p（match=40）"} if i == 0 else {})
             for i in range(14)]
    cands.append(cand("stablyai/orca/restore-x", action="restore_candidate", score=30))
    items, _s, _i = BD.build_items(inp(cands), CFG)
    shown = items[:10]
    assert len(items) >= 15 and len(shown) == 10
    assert shown[0]["canonical_key"] == "stablyai/orca/restore-x"      # P0 恢复压过高分安装
    assert all(x["bucket"].startswith("install") or x["bucket"] == "restore"
               for x in shown)
    machine = {"summary": {"total_items": len(shown)}}
    assert machine["summary"]["total_items"] == 10
    print("PASS 17：超过 10 → 按优先级取最高 10 条（restore 不被高分安装挤掉）")


def test_t18_source_traceable():
    c = cand("vercel-labs/agent-skills/react-native-skills", action="new_install",
             rec="install_candidate")
    items, _s, _i = BD.build_items(inp([c]), CFG)
    it = items[0]
    assert it["source_url"].startswith("https://github.com/vercel-labs/agent-skills")
    assert it["repo"] and it["skill_path"]
    r = BD.render_report(date(2026, 9, 24), items, _s, {}, inp([c]), CFG)
    assert "来源：https://github.com/" in r and "来源：GitHub\n" not in r
    print("PASS 18：每条推荐都有可点回原处的来源（repo+path/source_url）")


# ---------- 19-20：无自动安装 / 确定性 ----------
def test_t19_no_auto_install():
    src = open(os.path.join(BASE, "scripts", "build_daily.py"), encoding="utf-8").read()
    fb = open(os.path.join(BASE, "scripts", "feedback.py"), encoding="utf-8").read()
    cm = open(os.path.join(BASE, "scripts", "common.py"), encoding="utf-8").read()
    for blob in (src, fb, cm):
        for token in ("subprocess", "os.system", "pip install", "npm install",
                      "skill-manager install", "shutil.rmtree"):
            assert token not in blob, token
    cfg = C.load_config()
    assert cfg["auto_install"] is False
    print("PASS 19：引擎无任何安装/删除/升级调用；auto_install 恒为 false")


def test_t20_deterministic():
    if not os.path.exists(REAL_CANDIDATES):
        print("SKIP 20（真实数据缺失）")
        return
    tmp = tempfile.mkdtemp(prefix="daily-det-")
    try:
        snap_path = C.DAILY_SNAPSHOT_PATH
        m1, r1, _s1 = BD.generate(date(2026, 9, 24), out_dir=tmp, quiet=True)
        shutil.copytree(tmp, os.path.join(tmp, "copy"), dirs_exist_ok=True)
        m2, r2, _s2 = BD.generate(date(2026, 9, 24), out_dir=tmp, quiet=True)
        assert json.dumps(m1["items"], sort_keys=True) == \
            json.dumps(m2["items"], sort_keys=True)
        assert r1 == r2
        assert m1["summary"]["total_items"] > 0
        print(f"PASS 20：相同输入 → 相同 shortlist（真实池 Top {m1['summary']['total_items']} 条逐字节一致）")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    tests = [test_t1_zero_change_day, test_t2_new_install_candidate,
             test_t3_restore_not_new, test_t4_update_lineage,
             test_t5_security_changed_block, test_t6_metadata_enriched_not_shown,
             test_t7_rebaseline_not_external_news, test_t8_watch_cooldown,
             test_t9_watch_new_project_match_reappears, test_t10_feedback_ignored,
             test_t11_feedback_poor_family_demote, test_t12_feedback_useful_boost,
             test_t13_conflict_suppression, test_t14_unresolved_scope_not_in_install,
             test_t15_strong_without_incremental_not_install, test_t16_no_padding,
             test_t17_max_10_priority, test_t18_source_traceable,
             test_t19_no_auto_install, test_t20_deterministic]
    for t in tests:
        _run(t)
    total = sum(_COUNTS.values())
    print()
    print("=" * 64)
    print(f"TEST SUMMARY: pass={_COUNTS['pass']} skip={_COUNTS['skip']} "
          f"fail={_COUNTS['fail']} (total {total})")
    if _FAILURES:
        print("FAILURES:")
        for n, m in _FAILURES:
            print(f"  - {n}: {m}")
    print("=" * 64)
    return 0 if _COUNTS["fail"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
