# External Skills Context（外部 Skill 情报 · 日报底座）

> 生成日期：2026-09-23｜来源注册表 v2：T0 2 / T1 9 / T2 3 / T3 3
> 本层只做「发现 → 标准化 → 去重 → 匹配 → 安全审查 → 个性化排序」。**不安装、不删除、不升级任何 Skill**；安装一律在 Skill Manager 人工执行。
> 排名/安装量只是 adoption signal，绝不等于质量或推荐依据。完整数据：`data/SKILL_CANDIDATES.json`

```
SOURCE_HEALTH:
  - T0 agentskills.io: reachable (trust=spec_only)
  - T0 agentskills/agentskills: reachable (trust=spec_only)
  - T1 anthropics/skills: verified (trust=high)
  - T1 github/awesome-copilot: verified (trust=medium)
  - T1 vercel-labs/agent-skills: verified (trust=high)
  - T1 vercel-labs/skills: verified (trust=high)
  - T1 microsoft/skills: verified (trust=high)
  - T1 huggingface/skills: verified (trust=high)
  - T1 stablyai/orca: verified (trust=high)
  - T1 google/skills: verified (trust=high)
  - T1 browseros-ai/BrowserOS: verified (trust=high)
  - T2 KKKKhazix/khazix-skills: verified (trust=medium)
  - T2 obra/superpowers: verified (trust=medium)
  - T2 wshobson/agents: verified (trust=medium)
  - T3 skills.sh: reachable (trust=discovery_only)
  - T3 clawhub.ai: reachable (trust=discovery_only)
  - T3 skillsmp.com: reachable (trust=discovery_only)
  - skills.sh entries_today: 50 (healthy=True)
  - clawhub entries_today: 2 (healthy=True)

CANDIDATE_POOL_SUMMARY:
  raw: 1170
  canonical: 1106
  invalid_artifacts_removed: 67   # 构建产物/静态资源（§一.1）
  invalid_names_removed: 1   # 非法 skill slug
  bottom_up_total: 41
  bottom_up_verified: 17   # 过 SKILL.md 硬门
  bottom_up_quarantined: 23   # 已隔离，不入正式池
  already_installed: 8
  same_name_unverified: 4
  same_name_different_source: 2
  near_duplicate: 0
  overlap: 9
  complement: 2
  new_capability: 1078
  replacement_candidate: 3
  gap_none: 29
  gap_weak: 94
  gap_medium: 0
  gap_strong: 983

NEW_DISCOVERIES: 0
HIGH_MATCH_CANDIDATES: 12
CAPABILITY_GAP_CANDIDATES: 123   # gap_level ∈ {none, weak}
TRENDING_RELEVANT: 9
UPDATE_CANDIDATES: 35   # delta 变化 + 已装但版本落后（update_available）
SECURITY_REJECTED: 9
WATCHLIST: 253

UPDATE_LINEAGE: 3   # 更新项来源=Installed Source Map，不绑同名外部仓
  - installed_canonical_id: aihot
    installed_upstream: Virxact / AI HOT（aihot.virxact.com）
    update_upstream: Virxact / AI HOT（aihot.virxact.com）
    lineage_evidence: SKILL.md frontmatter 直接署名：metadata.author=Virxact、version=1.2.0（文件内作者证据，非『调用其 API』推断）；官方渠道当前版本 v1.7.1 同署名，版本谱系
    lineage_verified: true
  - installed_canonical_id: browseros-neo
    installed_upstream: github.com/browseros-ai/BrowserOS
    update_upstream: browseros-ai/BrowserOS
    lineage_evidence: upstream_repo:browseros-ai/browseros
    lineage_verified: true
  - installed_canonical_id: computer-use-2
    installed_upstream: github.com/stablyai/orca
    update_upstream: github.com/stablyai/orca
    lineage_evidence: 本地目录名为改名副本，但内容未改动：SKILL.md（991f5dcdb2e5）与 stablyai/orca commit b44ef1e5（2026-08-31）中 skills/computer-use/SKILL
    lineage_verified: true

PROJECT_MATCH_QUALITY:
  matched_candidates: 76   # 至少有一个 matched_project 的候选数
  matched_project_entries: 147   # matched_project 总条数（候选×项目）
  strong_tech_evidence: 121   # 专用技术栈直接命中（Expo/RN/Android/Supabase/Next.js/PWA/Vercel/.NET…）
  positioning_evidence: 16   # 项目定位/功能语义命中
  shared_need_evidence: 18   # 项目自身需求与候选能力命中
  lexical_evidence: 4   # 词面证据（v2.5：独立成立仅限领域短语；词级重叠只作次要加分）
  secondary_tech_only_rejected: 157   # 只靠泛用技术栈（TS/React/Python/Docker…）硬凑、已被拒的候选数
  negated_evidence_rejected: 48   # 被否定窗口/排除语境压制掉的命中次数
  lexical_single_rejected: 1436   # 词面重叠只因单个低区分度词（manager/service…）而不足以成立的次数
  lexical_alone_rejected: 4   # v2.5 §三：词面 boost（≥2 词）想**独立**造匹配、被拒的次数（词面只作次要加分）
  lexical_phrase_direct_evidence: 4   # v2.5 §五：靠人工整理的领域短语独立成立的词面证据条数
  bare_prompt_direct_evidence: 0   # v2.5 §四：裸 prompt 被当直接证据的次数（**必须为 0**）
  tech_words_used_as_lexical_direct_evidence: 0   # v2.5 §四：泛用技术词充当词面直接证据的次数（**必须为 0**）
  unresolved_mismatch_candidates: 400   # 存在未解除平台错配的候选数（只作观察）
  redirect_evidence_rejected: 357   # v2.6 §五：跨 Skill 重定向小句被剪掉的次数
  same_name_only_already_installed: 0   # v2.6 §二：只凭同名判已安装的条数（**必须为 0**）
  wrong_update_lineage: 0   # v2.6 §三：血缘未验证的 update_available（**必须为 0**）
  same_name_unverified_candidates: 6   # 同名但血缘未确认（最高 watch，等人工确认）
  gcp_alias_missed: 0   # v2.6 §四：描述含 GCP 产品别名却未标 gcp 域的条数（**必须为 0**）
  product_internal_unresolved_candidates: 2   # v2.6 §十：未解除的产品自研 Skill 数
  product_specific_scope_unresolved: 47   # v2.7 §七：未解除的产品专项 platform_operation 数（GA Admin / SecOps / anthropic-brand…）
  determinism: hashseed_matrix（0/1/2/3/42/123）已由 tests/test_pipeline.py::test_v27_determinism_hashseed 作为硬门   # v2.7 §二
  note: 四个 *_evidence 是「候选×项目」条数，同一条可同时具备多种证据；
        所有 projected 条目都必须至少带 1 类直接证据（direct_evidence 非空率 100%，仅作完整性自检，不作 KPI）

PERSONALIZED_TOP30:
  target_limit: 30
  actual_count: 15   # 不足 target 时输出实际数量，不塞 ignore/reject 补数量
  min_score: 55
  functional_duplicates: 1   # 跨仓同功能族被折叠进 alternatives 的条目数（§三）
  t3_uncorroborated: 23   # T3/discovery_only 无 T1·T2·官方交叉佐证，挡在 Top 外（只留 WATCHLIST）
  alternative_families: 1
  contains_ignore: no
  contains_reject: no
  generated: yes
  high_match_count: 12
  matched_projects_coverage: 22/103   # 高匹配候选中答出具体项目名的比例（准确率优先，不再要求 90%+）
  top_candidates_with_unresolved_mismatch: 0   # §九：必须为 0
  mismatch_blocked_from_top: 6   # 因未解除平台错配被挡在 Top 外（仍留 WATCHLIST）
  top_candidates_with_unresolved_product_scope: 0   # v2.6 §十：必须为 0（第五道门）
  scope_blocked_from_top: 27   # 因未解除 product_internal 被挡在 Top 外（可解除，非黑名单）
  top_candidates_supporting_only: 0   # v2.8 §十四：Top 内仅有 supporting/mention 级核心证据的条数（**必须为 0**）
  core_evidence_blocked_from_top: 111   # 因缺核心需求证据被挡在 Top 外（仍留 WATCHLIST）
  security_scanned: 1075
  security_unscanned: 31
  security_verdict_pass: 701
  security_verdict_review_required: 365
  security_verdict_block: 9
  deep_scan_complete: 12   # 真正做了深度静态审查的（= install 候选）
  deep_scan_failed: 0
  deep_scan_pending: 0   # 超预算未扫，fail-closed
  deep_scan_not_required: 1063   # 未进安装候选，未触发
  deep_scan_skipped: 31   # 无目录/未扫描
  top10:
    - stablyai/orca/orca-emulator-android | score=79.4 | gap=none | rel=new_capability | risk=low | verdict=pass | rec=install_candidate
    - github/awesome-copilot/latchshot-page-capture | score=70.3 | gap=none | rel=new_capability | risk=medium | verdict=review_required | rec=install_candidate
    - microsoft/skills/frontend-design-review | score=79 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - github/awesome-copilot/web-design-reviewer | score=71.8 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - wshobson/agents/tailwind-design-system | score=65.8 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - wshobson/agents/responsive-design | score=65.8 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - github/awesome-copilot/penpot-uiux-design | score=63.5 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - microsoft/skills/frontend-ui-dark-ts | score=61.4 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - vercel-labs/agent-skills/react-native-skills | score=58.8 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - wshobson/agents/mobile-android-design | score=56.5 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch

DAILY_DELTA:   # 与昨日快照相比；Top30 无变化时不要重复输出同样内容
  first_run: no
  changed_total: 51
  NEW: 0
  RISING: 4
  FALLING: 35
  UPDATED: 7
  SECURITY_CHANGED: 7
  SOURCE_CHANGED: 0
  MATCH_CHANGED: 28
  ALREADY_INSTALLED: 0
  NO_LONGER_RELEVANT: 0
```

## 0. 今日 Delta（51 项变化 · 按变化数排序）

- `github/awesome-copilot/generate-image`：FALLING, MATCH_CHANGED, SECURITY_CHANGED
- `github/awesome-copilot/playwright-automation-fill-in-form`：FALLING, MATCH_CHANGED, SECURITY_CHANGED
- `github/awesome-copilot/scoutqa-test`：MATCH_CHANGED, RISING, SECURITY_CHANGED
- `wshobson/agents/screen-reader-testing`：MATCH_CHANGED, RISING, SECURITY_CHANGED
- `github/awesome-copilot/latchshot-page-capture`：MATCH_CHANGED, RISING, SECURITY_CHANGED
- `google/skills/bigquery-bigframes`：FALLING, MATCH_CHANGED, UPDATED
- `microsoft/skills/applicationinsights-web-ts`：FALLING, MATCH_CHANGED, SECURITY_CHANGED
- `microsoft/skills/ui-widget-developer`：FALLING, MATCH_CHANGED, SECURITY_CHANGED
- `wshobson/agents/javascript-testing-patterns`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/acreadiness-assess`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/comment-code-generate-a-tutorial`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/flowstudio-power-automate-mcp`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/mvvm-toolkit-di`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/phoenix-cli`：FALLING, MATCH_CHANGED
- `github/awesome-copilot/pr-dashboard`：FALLING, MATCH_CHANGED

## 1. 今日重点（5 个 · 回答七问）

### 1. latchshot-page-capture（github/awesome-copilot）
1. **它是什么**：Use this skill when a user needs a screenshot, website thumbnail, full-page capture, or PDF of a public HTTP(S) webpage saved as a local artifact through Latchs
2. **对我哪个项目有用**：`a-share-index-valuation-report`（匹配度 36｜依据：项目定位/功能语义直接命中：报告生成）
3. **我现在有没有类似能力**：new_capability
4. **为什么今天值得看**：MATCH_CHANGED, RISING, SECURITY_CHANGED；能力缺口=none；上游活跃度=active
5. **来源是谁**：TIER1｜github/awesome-copilot｜https://github.com/github/awesome-copilot/tree/main/skills/latchshot-page-capture（origin=community）
6. **安全状态**：scanned / verdict=review_required / risk=medium｜行为：secret_access｜规则命中：credential_files[low/mention]; bundled_scripts[low/mention]; credential_files[low/warning]; network_generic[low/instruction]｜深度审查：complete（已静态读取 0 个脚本；未执行）
7. **推荐**：**INSTALL_CANDIDATE** — 高分 70.3：命中需求 browser-qa（能力缺口 image_creative），安全 verdict=review_required，深度审查 complete（已静态读取 0 个脚本；未执行），另有人工复核项（语境性提及）：credential_files, bundled_scripts（score=70.3）

### 2. screen-reader-testing（wshobson/agents）
1. **它是什么**：Test web applications with screen readers including VoiceOver, NVDA, and JAWS. Use when validating screen reader compatibility, debugging accessibility issues, 
2. **对我哪个项目有用**：未匹配到具体项目；能力标签命中：browser-qa
3. **我现在有没有类似能力**：new_capability
4. **为什么今天值得看**：MATCH_CHANGED, RISING, SECURITY_CHANGED；能力缺口=weak；上游活跃度=unknown
5. **来源是谁**：TIER2｜wshobson/agents｜https://github.com/wshobson/agents/tree/main/plugins/accessibility-compliance/skills/screen-reader-testing（origin=community）
6. **安全状态**：scanned / verdict=pass / risk=low｜深度审查：complete（已静态读取 0 个脚本；未执行）
7. **推荐**：**INSTALL_CANDIDATE** — 高分 66.3：命中需求 browser-qa（能力缺口 testing_qa），安全 verdict=pass，深度审查 complete（已静态读取 0 个脚本；未执行）（score=66.3）

### 3. scoutqa-test（github/awesome-copilot）
1. **它是什么**：This skill should be used when the user asks to "test this website", "run exploratory testing", "check for accessibility issues", "verify the login flow works",
2. **对我哪个项目有用**：未匹配到具体项目；能力标签命中：browser-qa
3. **我现在有没有类似能力**：new_capability
4. **为什么今天值得看**：MATCH_CHANGED, RISING, SECURITY_CHANGED；能力缺口=weak；上游活跃度=active
5. **来源是谁**：TIER1｜github/awesome-copilot｜https://github.com/github/awesome-copilot/tree/main/skills/scoutqa-test（origin=community）
6. **安全状态**：scanned / verdict=review_required / risk=medium｜行为：network_access｜规则命中：network_generic[low/mention]｜深度审查：complete（已静态读取 0 个脚本；未执行）
7. **推荐**：**INSTALL_CANDIDATE** — 高分 64.3：命中需求 browser-qa（能力缺口 testing_qa），安全 verdict=review_required，深度审查 complete（已静态读取 0 个脚本；未执行），另有人工复核项（语境性提及）：network_generic（score=64.3）

### 4. penpot-uiux-design（github/awesome-copilot）
1. **它是什么**：Comprehensive guide for creating professional UI/UX designs in Penpot using MCP tools. Use this skill when: (1) Creating new UI/UX designs for web, mobile, or d
2. **对我哪个项目有用**：`landedazi-android`（匹配度 50｜依据：项目技术栈直接命中（专用技术栈）：Android）；`family-insurance-dashboard`（匹配度 38｜依据：项目定位/功能语义直接命中：看板）
3. **我现在有没有类似能力**：new_capability
4. **为什么今天值得看**：FALLING；能力缺口=strong；上游活跃度=active
5. **来源是谁**：TIER1｜github/awesome-copilot｜https://github.com/github/awesome-copilot/tree/main/skills/penpot-uiux-design（origin=community）
6. **安全状态**：scanned / verdict=pass / risk=low｜深度审查：not_required（未进入安装候选，未触发深度审查）
7. **推荐**：**WATCH** — 中分 63.5：值得关注，需人工判断（score=63.5）

### 5. frontend-ui-dark-ts（microsoft/skills）
1. **它是什么**：Build dark-themed React applications using Tailwind CSS with custom theming, glassmorphism effects, and Framer Motion animations. Use when creating dashboards, 
2. **对我哪个项目有用**：`family-insurance-dashboard`（匹配度 32｜依据：项目自身需求与候选能力直接命中：dashboard-viz）
3. **我现在有没有类似能力**：new_capability
4. **为什么今天值得看**：RISING；能力缺口=strong；上游活跃度=active
5. **来源是谁**：TIER1｜microsoft/skills｜https://github.com/microsoft/skills/tree/main/.github/plugins/azure-sdk-typescript/skills/frontend-ui-dark-ts（origin=official）
6. **安全状态**：scanned / verdict=pass / risk=low｜深度审查：not_required（未进入安装候选，未触发深度审查）
7. **推荐**：**WATCH** — 中分 61.4：值得关注，需人工判断（score=61.4）

## 2. Personalized Top（target_limit 30 · 实际 15）

> 定义 = **值得用户看的候选**：只含 `install_candidate` / `watch`，**不含 ignore / reject**；且必须同时过五道门（§五 + §九 + §十）：① score ≥ 55（配置化最低阈值）② 有真实个性化证据（命中需求 / 能力缺口 / 更新 / 恢复）③ T3·discovery_only 来源需有 T1·T2·官方交叉佐证④ **无未解除的平台错配**（Azure / AWS / GCP / .NET / Microsoft Store 等：项目档案里没有项目用该平台 → 只留 WATCHLIST，不占个人 Top）⑤ **无未解除的 product_internal**（v2.6 §十：产品自研/维护 Skill —— 如 BrowserOS test-ui —— 只有用户项目真的在做这个产品才进 Top）。符合标准的不足 30 个时就输出实际数量，**不为凑数塞低质量 watch**。

> 跨仓库**同功能族**只展示一条 PRIMARY（§三）：如 `github/awesome-copilot/webapp-testing` 与 `anthropics/skills/webapp-testing` 只出一条，其余进下方 ALTERNATIVES。

| # | Skill | owner/repo | 分 | 缺口 | 关系 | verdict | 最匹配项目 | 推荐 |
|---|---|---|---|---|---|---|---|---|
| 1 | orca-emulator-android | stablyai/orca | 79.4 | none | new_capability | pass | landedazi-android（50） | install_candidate |
| 2 | latchshot-page-capture | github/awesome-copilot | 70.3 | none | new_capability | review_required | a-share-index-valuation-report（36） | install_candidate |
| 3 | frontend-design-review | microsoft/skills | 79 | strong | new_capability | pass | a-share-index-valuation-report（32） | watch |
| 4 | web-design-reviewer | github/awesome-copilot | 71.8 | strong | new_capability | pass | a-share-index-valuation-report（32） | watch |
| 5 | tailwind-design-system | wshobson/agents | 65.8 | strong | new_capability | pass | a-share-index-valuation-report（32） | watch |
| 6 | responsive-design | wshobson/agents | 65.8 | strong | new_capability | pass | a-share-index-valuation-report（32） | watch |
| 7 | penpot-uiux-design | github/awesome-copilot | 63.5 | strong | new_capability | pass | landedazi-android（50） | watch |
| 8 | frontend-ui-dark-ts | microsoft/skills | 61.4 | strong | new_capability | pass | family-insurance-dashboard（32） | watch |
| 9 | react-native-skills | vercel-labs/agent-skills | 58.8 | strong | new_capability | pass | protein-calculator（52） | watch |
| 10 | mobile-android-design | wshobson/agents | 56.5 | strong | new_capability | pass | landedazi-android（74） | watch |
| 11 | webapp-testing | anthropics/skills | 71.3 | weak | new_capability | review_required | — | install_candidate |
| 12 | claude-api | anthropics/skills | 67 | strong | new_capability | review_required | — | watch |
| 13 | vercel-cli-with-tokens | vercel-labs/agent-skills | 60.6 | strong | new_capability | review_required | — | watch |
| 14 | web-design-guidelines | vercel-labs/agent-skills | 60.5 | strong | new_capability | review_required | — | watch |
| 15 | wiki-llms-txt | microsoft/skills | 56.2 | strong | new_capability | pass | — | watch |

> 安装候选 ≠ 自动安装；任何 Skill 的安装都需用户在 Skill Manager 中人工执行，并另行安全复核。

### 2.1 ALTERNATIVES（同功能族的其他上游 · 不重复推荐）

> 候选池按 `owner/repo/skill` 各自独立记账；这里只做**展示层折叠**（§八）：同一功能族选一条 PRIMARY，其余列在此处备查。

| PRIMARY | 同功能来源 | 折叠依据 |
|---|---|---|
| `anthropics/skills/webapp-testing` | `github/awesome-copilot/webapp-testing`（github/awesome-copilot，score=72.3） | 同名同功能 |

- Top 内跨仓同功能族折叠：**1** 条；T3 无交叉佐证被挡在 Top 外：**23** 条（仍留在 WATCHLIST）。

## 3. 安全拒绝清单（SECURITY_REJECTED，Gate 优先于分数）

> v2.2 起只有 **block 级**（真要求执行的高危行为）才 reject；文档讨论 `.env`/`sudo`、示例引用 token 等属 `review_required`，不再误伤。

| Skill | owner/repo | verdict | 阻断规则 |
|---|---|---|---|
| aspire | github/awesome-copilot | block | pipe_to_shell |
| azure-container-registry-cli | github/awesome-copilot | block | pipe_to_shell |
| azure-devops-cli | github/awesome-copilot | block | pipe_to_shell |
| developing-genkit-dart | google/skills | block | pipe_to_shell |
| developing-genkit-go | google/skills | block | pipe_to_shell |
| hf-cli | huggingface/skills | block | pipe_to_shell |
| linkerd-patterns | wshobson/agents | block | pipe_to_shell |
| gitops-workflow | wshobson/agents | block | pipe_to_shell |
| uv-package-manager | wshobson/agents | block | pipe_to_shell |

## 4. 能力缺口候选（按缺口优先级）

当前焦点能力（读取已装侧 CAPABILITY_SUPPRESSION + CAPABILITY_AVAILABILITY 动态派生）：

| 能力 | 覆盖 | 可用性 | 优先级 |
|---|---|---|---|
| computer_use | strong | degraded | recovery |
| orca_integration | strong | degraded | recovery |
| docx_xlsx | weak | ok | medium |
| macos | weak | ok | medium |
| mcp_dev | weak | ok | medium |
| security_audit | weak | ok | medium |
| supabase_db | weak | ok | medium |
| testing_qa | weak | ok | medium |
| windows | weak | ok | medium |
| data_analytics | none | ok | high |
| image_creative | none | ok | high |
| mobile_qa | none | ok | high |

- 命中 none/weak 缺口的候选：**123** 个（完整清单见 SKILL_CANDIDATES.json）

## 5. 更新候选与恢复候选

**已装但版本落后（v2.6 §三：更新项由 Installed Source Map 的血缘驱动，不再从候选池找同名对象冒充上游）**

| installed_canonical_id | installed_upstream | update_upstream | 血缘已验证 | 依据 |
|---|---|---|---|---|
| `aihot` | Virxact / AI HOT（aihot.virxact.com） | Virxact / AI HOT（aihot.virxact.com） | 是 | SKILL.md frontmatter 直接署名：metadata.author=Virxact、version=1.2.0（文件内作者证据，非『调用其 AP |
| `browseros-neo` | github.com/browseros-ai/BrowserOS | browseros-ai/BrowserOS | 是 | upstream_repo:browseros-ai/browseros |
| `computer-use-2` | github.com/stablyai/orca | github.com/stablyai/orca | 是 | 本地目录名为改名副本，但内容未改动：SKILL.md（991f5dcdb2e5）与 stablyai/orca commit b44ef1e5（2026-08- |

**恢复/替换候选（replacement_candidate）**

| Skill | owner/repo | 对应已装/已知 | 分数 | 上游 | 依据 |
|---|---|---|---|---|---|
| computer-use | stablyai/orca | computer-use | 52.0 | active | 对应 canonical `computer-use` 当前不在本机安装集（known_missing）且血缘确认（upstream_repo:stablyai/orca，来源档案在案：github.com/stably |
| orca-cli | stablyai/orca | orca-cli | 48 | active | 对应 canonical `orca-cli` 当前不在本机安装集（known_missing）且血缘确认（upstream_repo:stablyai/orca，来源档案在案：github.com/stablyai/o |
| orchestration | stablyai/orca | orchestration | 48 | active | 对应 canonical `orchestration` 当前不在本机安装集（known_missing）且血缘确认（upstream_repo:stablyai/orca，来源档案在案：github.com/stabl |

