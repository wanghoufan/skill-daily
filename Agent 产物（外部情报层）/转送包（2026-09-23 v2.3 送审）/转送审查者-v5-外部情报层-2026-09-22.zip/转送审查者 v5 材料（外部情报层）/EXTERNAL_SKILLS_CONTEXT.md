# External Skills Context（外部 Skill 情报 · 日报底座）

> 生成日期：2026-09-23｜来源注册表 v2：T0 2 / T1 9 / T2 3 / T3 3
> 本层只做「发现 → 标准化 → 去重 → 匹配 → 安全审查 → 个性化排序」。**不安装、不删除、不升级任何 Skill**；安装一律在 Skill Manager 人工执行。
> 排名/安装量只是 adoption signal，绝不等于质量或推荐依据。完整数据：`data/SKILL_CANDIDATES.json`

```
SOURCE_HEALTH:
  - T0 agentskills.io: reachable (trust=spec_only)
  - T0 agentskills/agentskills: reachable (trust=spec_only)
  - T1 anthropics/skills: verified (trust=high)
  - T1 github/awesome-copilot: verified (trust=medium)
  - T1 vercel-labs/agent-skills: verified (trust=high)
  - T1 vercel-labs/skills: verified (trust=high)
  - T1 microsoft/skills: verified (trust=high)
  - T1 huggingface/skills: verified (trust=high)
  - T1 stablyai/orca: verified (trust=high)
  - T1 google/skills: verified (trust=high)
  - T1 browseros-ai/BrowserOS: verified (trust=high)
  - T2 KKKKhazix/khazix-skills: verified (trust=medium)
  - T2 obra/superpowers: verified (trust=medium)
  - T2 wshobson/agents: verified (trust=medium)
  - T3 skills.sh: reachable (trust=discovery_only)
  - T3 clawhub.ai: reachable (trust=discovery_only)
  - T3 skillsmp.com: reachable (trust=discovery_only)
  - skills.sh entries_today: 50 (healthy=True)
  - clawhub entries_today: 2 (healthy=True)

CANDIDATE_POOL_SUMMARY:
  raw: 1170
  canonical: 1105
  invalid_artifacts_removed: 67   # 构建产物/静态资源（§一.1）
  invalid_names_removed: 1   # 非法 skill slug
  bottom_up_total: 41
  bottom_up_verified: 17   # 过 SKILL.md 硬门
  bottom_up_quarantined: 23   # 已隔离，不入正式池
  already_installed: 14
  near_duplicate: 0
  overlap: 20
  complement: 45
  new_capability: 1023
  replacement_candidate: 3
  gap_none: 7
  gap_weak: 150
  gap_medium: 0
  gap_strong: 948

NEW_DISCOVERIES: 0
HIGH_MATCH_CANDIDATES: 24
CAPABILITY_GAP_CANDIDATES: 157   # gap_level ∈ {none, weak}
TRENDING_RELEVANT: 7
UPDATE_CANDIDATES: 2   # delta 变化 + 已装但版本落后（update_available）
SECURITY_REJECTED: 3
WATCHLIST: 753

PERSONALIZED_TOP30:
  target_limit: 30
  actual_count: 22   # 不足 target 时输出实际数量，不塞 ignore/reject 补数量
  min_score: 55
  functional_duplicates: 1   # 跨仓同功能族被折叠进 alternatives 的条目数（§三）
  t3_uncorroborated: 23   # T3/discovery_only 无 T1·T2·官方交叉佐证，挡在 Top 外（只留 WATCHLIST）
  alternative_families: 1
  contains_ignore: no
  contains_reject: no
  generated: yes
  high_match_count: 24
  matched_projects_coverage: 86/173   # 高匹配候选中答出具体项目名的比例（准确率优先，不再要求 90%+）
  project_match_direct_evidence_rate: 351/351   # 每条 matched_project 都必须有直接证据（§一）
  security_scanned: 600
  security_unscanned: 505
  security_verdict_pass: 395
  security_verdict_review_required: 202
  security_verdict_block: 3
  deep_scan_complete: 24   # 真正做了深度静态审查的（= install 候选）
  deep_scan_failed: 0
  deep_scan_pending: 0   # 超预算未扫，fail-closed
  deep_scan_not_required: 576   # 未进安装候选，未触发
  deep_scan_skipped: 505   # 无目录/未扫描
  top10:
    - github/awesome-copilot/ai-prompt-engineering-safety-review | score=80.6 | gap=weak | rel=new_capability | risk=low | verdict=pass | rec=install_candidate
    - stablyai/orca/orca-emulator-android | score=79.4 | gap=none | rel=new_capability | risk=low | verdict=pass | rec=install_candidate
    - github/awesome-copilot/publish-to-pages | score=72.2 | gap=weak | rel=new_capability | risk=medium | verdict=review_required | rec=install_candidate
    - github/awesome-copilot/secret-scanning | score=68.8 | gap=weak | rel=new_capability | risk=medium | verdict=review_required | rec=install_candidate
    - anthropics/skills/claude-api | score=68.3 | gap=weak | rel=new_capability | risk=medium | verdict=review_required | rec=install_candidate
    - wshobson/agents/github-actions-templates | score=66.2 | gap=weak | rel=new_capability | risk=medium | verdict=review_required | rec=install_candidate
    - microsoft/skills/frontend-ui-dark-ts | score=71.5 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - vercel-labs/agent-skills/react-view-transitions | score=71.5 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - wshobson/agents/responsive-design | score=66 | gap=strong | rel=new_capability | risk=low | verdict=pass | rec=watch
    - anthropics/skills/web-artifacts-builder | score=63.5 | gap=strong | rel=new_capability | risk=medium | verdict=review_required | rec=watch

DAILY_DELTA:   # 与昨日快照相比；Top30 无变化时不要重复输出同样内容
  first_run: no
  changed_total: 0
  NEW: 0
  RISING: 0
  FALLING: 0
  UPDATED: 0
  SECURITY_CHANGED: 0
  SOURCE_CHANGED: 0
  MATCH_CHANGED: 0
  ALREADY_INSTALLED: 0
  NO_LONGER_RELEVANT: 0
```

## 0. 今日 Delta（0 项变化 · 按变化数排序）

- 今日无变化：候选池与昨日一致 —— **日报不要重复输出同样内容**。

## 1. 今日重点：**无**（Top30 与昨日一致，不重复输出）

> 日报请只报告下方 `DAILY_DELTA` 的变化；候选池无变化时不要重复罗列同样的 Skill。

> 需要完整清单时看第 2 节 Top30 表或 `data/SKILL_CANDIDATES.json`。

## 2. Personalized Top（target_limit 30 · 实际 22）

> 定义 = **值得用户看的候选**：只含 `install_candidate` / `watch`，**不含 ignore / reject**；且必须同时过三道质量门（§五）：① score ≥ 55（配置化最低阈值）② 有真实个性化证据（命中需求 / 能力缺口 / 更新 / 恢复）③ T3·discovery_only 来源需有 T1·T2·官方交叉佐证。符合标准的不足 30 个时就输出实际数量，**不为凑数塞低质量 watch**。

> 跨仓库**同功能族**只展示一条 PRIMARY（§三）：如 `github/awesome-copilot/webapp-testing` 与 `anthropics/skills/webapp-testing` 只出一条，其余进下方 ALTERNATIVES。

| # | Skill | owner/repo | 分 | 缺口 | 关系 | verdict | 最匹配项目 | 推荐 |
|---|---|---|---|---|---|---|---|---|
| 1 | ai-prompt-engineering-safety-review | github/awesome-copilot | 80.6 | weak | new_capability | pass | prompt-manager（36） | install_candidate |
| 2 | orca-emulator-android | stablyai/orca | 79.4 | none | new_capability | pass | landedazi-android（50） | install_candidate |
| 3 | publish-to-pages | github/awesome-copilot | 72.2 | weak | new_capability | review_required | github-projects-profile（48） | install_candidate |
| 4 | secret-scanning | github/awesome-copilot | 68.8 | weak | new_capability | review_required | github-projects-profile（28） | install_candidate |
| 5 | claude-api | anthropics/skills | 68.3 | weak | new_capability | review_required | prompt-manager（36） | install_candidate |
| 6 | github-actions-templates | wshobson/agents | 66.2 | weak | new_capability | review_required | github-projects-profile（28） | install_candidate |
| 7 | frontend-ui-dark-ts | microsoft/skills | 71.5 | strong | new_capability | pass | yejian-buguangdeng（66） | watch |
| 8 | react-view-transitions | vercel-labs/agent-skills | 71.5 | strong | new_capability | pass | yejian-buguangdeng（58） | watch |
| 9 | responsive-design | wshobson/agents | 66 | strong | new_capability | pass | personal-rss（44） | watch |
| 10 | web-artifacts-builder | anthropics/skills | 63.5 | strong | new_capability | review_required | yejian-buguangdeng（54） | watch |
| 11 | python-packaging | wshobson/agents | 62 | strong | new_capability | pass | github-projects-profile（36） | watch |
| 12 | google-mobile-ads-get-started | google/skills | 61.4 | strong | new_capability | pass | landedazi-android（50） | watch |
| 13 | react-native-skills | vercel-labs/agent-skills | 58.8 | strong | new_capability | pass | stretch-side-timer-project（96） | watch |
| 14 | github-issue-creator | microsoft/skills | 55.6 | strong | new_capability | pass | github-projects-profile（32） | watch |
| 15 | azure-microsoft-playwright-testing-ts | microsoft/skills | 75.8 | weak | new_capability | pass | party-night-v1-2（32） | watch |
| 16 | bigquery-bigframes | google/skills | 73.5 | none | new_capability | pass | github-projects-profile（36） | watch |
| 17 | cloud-monitoring-chart-generation | google/skills | 64.0 | none | new_capability | review_required | family-insurance-dashboard（32） | watch |
| 18 | webapp-testing | anthropics/skills | 84 | weak | new_capability | review_required | — | install_candidate |
| 19 | vercel-cli-with-tokens | vercel-labs/agent-skills | 71 | strong | new_capability | review_required | — | watch |
| 20 | sg-ship | bacoco/ShipGuard | 61.3 | weak | new_capability | pass | — | watch |
| 21 | hf-cloud-sagemaker-deployment-planner | huggingface/skills | 59.1 | strong | new_capability | pass | — | watch |
| 22 | orca-per-workspace-env | stablyai/orca | 56.0 | weak | new_capability | pass | personal-rss（44） | watch |

> 安装候选 ≠ 自动安装；任何 Skill 的安装都需用户在 Skill Manager 中人工执行，并另行安全复核。

### 2.1 ALTERNATIVES（同功能族的其他上游 · 不重复推荐）

> 候选池按 `owner/repo/skill` 各自独立记账；这里只做**展示层折叠**（§八）：同一功能族选一条 PRIMARY，其余列在此处备查。

| PRIMARY | 同功能来源 | 折叠依据 |
|---|---|---|
| `anthropics/skills/webapp-testing` | `github/awesome-copilot/webapp-testing`（github/awesome-copilot，score=85） | 同名同功能 |

- Top 内跨仓同功能族折叠：**1** 条；T3 无交叉佐证被挡在 Top 外：**23** 条（仍留在 WATCHLIST）。

## 3. 安全拒绝清单（SECURITY_REJECTED，Gate 优先于分数）

> v2.2 起只有 **block 级**（真要求执行的高危行为）才 reject；文档讨论 `.env`/`sudo`、示例引用 token 等属 `review_required`，不再误伤。

| Skill | owner/repo | verdict | 阻断规则 |
|---|---|---|---|
| aspire | github/awesome-copilot | block | pipe_to_shell |
| azure-container-registry-cli | github/awesome-copilot | block | pipe_to_shell |
| azure-devops-cli | github/awesome-copilot | block | pipe_to_shell |

## 4. 能力缺口候选（按缺口优先级）

当前焦点能力（读取已装侧 CAPABILITY_SUPPRESSION + CAPABILITY_AVAILABILITY 动态派生）：

| 能力 | 覆盖 | 可用性 | 优先级 |
|---|---|---|---|
| computer_use | strong | degraded | recovery |
| orca_integration | strong | degraded | recovery |
| docx_xlsx | weak | ok | medium |
| macos | weak | ok | medium |
| mcp_dev | weak | ok | medium |
| security_audit | weak | ok | medium |
| supabase_db | weak | ok | medium |
| testing_qa | weak | ok | medium |
| windows | weak | ok | medium |
| data_analytics | none | ok | high |
| image_creative | none | ok | high |
| mobile_qa | none | ok | high |

- 命中 none/weak 缺口的候选：**157** 个（完整清单见 SKILL_CANDIDATES.json）

## 5. 更新候选与恢复候选

**已装但版本落后（update_available，不重复推荐安装，仅提示更新）**

| Skill | owner/repo | 已装版本状态 | 上游 | 说明 |
|---|---|---|---|---|
| browseros-neo | browseros-ai/BrowserOS | browseros-neo | active | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDATE_CANDIDATES 提示 |
| aihot | KKKKhazix/khazix-skills | aihot | unknown | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDATE_CANDIDATES 提示 |

**恢复/替换候选（replacement_candidate）**

| Skill | owner/repo | 对应已装/已知 | 分数 | 上游 | 依据 |
|---|---|---|---|---|---|
| computer-use | stablyai/orca | computer-use | 51 | active | 对应 canonical `computer-use` 当前不在本机安装集（known_missing）（来源档案在案：github.com/stablyai/orca）→ 该候选可用于恢复 |
| orca-cli | stablyai/orca | orca-cli | 48 | active | 对应 canonical `orca-cli` 当前不在本机安装集（known_missing）（来源档案在案：github.com/stablyai/orca）→ 该候选可用于恢复 |
| orchestration | stablyai/orca | orchestration | 48 | active | 对应 canonical `orchestration` 当前不在本机安装集（known_missing）（来源档案在案：github.com/stablyai/orca）→ 该候选可用于恢复 |

