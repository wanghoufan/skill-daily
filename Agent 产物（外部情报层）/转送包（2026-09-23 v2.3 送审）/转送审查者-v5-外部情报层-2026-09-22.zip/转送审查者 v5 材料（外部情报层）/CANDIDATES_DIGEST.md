# 候选池精简对照件（External Skill Intelligence v2.3）

> 数据基线：2026-09-23｜源文件 `SKILL_CANDIDATES.json`（1105 条）
> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。
> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；排名/安装量只是 adoption signal，不等于推荐。

## 一、总览

| 项目 | 数值 |
|---|---|
| 来源注册表 | 17 源（T0 2 / T1 9 / T2 3 / T3 3）|
| 候选（raw → 合法池） | 1170 → 1105 |
| 数据质量 Gate | 剔除构建产物 67 条 / 非法 skill 名 1 条 |
| bottom-up 硬门 | 共 41 条搜索结果 → 过 SKILL.md 硬门 17 / 隔离 23 |
| 推荐分布 | ignore 325 / install_candidate 24 / reject 3 / watch 753 |
| 与已装关系 | already_installed 14 / complement 45 / new_capability 1023 / overlap 20 / replacement_candidate 3 |
| 安全风险 | high 3 / low 395 / medium 202 / unknown 505（已静态审查 600）|
| 安全 verdict | pass 395 / review_required 202 / block 3 / unscanned 505 |
| 深度静态审查 | complete 24（= install 候选） / failed 0 / pending 0 / not_required 576 / skipped 505 |
| 能力缺口 | none 7 / strong 948 / weak 150 |
| 命中项目需求 / 平台错配 | 209 / 312 |
| matched_projects 覆盖（高匹配候选） | 86/173 (50%) —— **v2.3 起不再是 KPI**，只作参考 |
| matched_project 直接证据率 | 351/351 —— 每条匹配都必须有 direct_evidence（§一）|
| update_available / replacement_candidate | 2 / 3 |

> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` 这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。

## 二、Personalized Top（target_limit 30 · 实际 22）

选取规则（与日报完全一致，复用同一函数 `select_top`）：① score ≥ **55**（配置化最低阈值）② 有真实个性化证据（matched need / capability gap / update / replacement 至少一个成立）③ T3/discovery_only 需有 T1·T2·官方交叉佐证 ④ recommendation ≥ watch ⑤ 分数；多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。

> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；符合标准的不足 30 个时就输出实际数量，**不为凑数塞垃圾**。

> 本轮被三道质量门挡下的：低分（< 55）若干 / 无个性化证据若干 / T3 无交叉佐证 **23** 条（仍留在 WATCHLIST）。跨仓同功能族折叠 **1** 条（见 2.1）。

「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；
`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。
`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。

| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |
|---|---|---|---|---|---|---|---|---|
| 1 | 80.6 | install_candidate | `github/awesome-copilot/ai-prompt-engineering-safety-review` | T1 github/awesome-copilot | agent-governance | prompt-manager(36) | weak | pass |
| 2 | 79.4 | install_candidate | `stablyai/orca/orca-emulator-android` | T1 stablyai/orca | android | landedazi-android(50) | none | pass |
| 3 | 72.2 | install_candidate | `github/awesome-copilot/publish-to-pages` | T1 github/awesome-copilot | deploy, github-auto | github-projects-profile(48) | weak | review_required |
| 4 | 68.8 | install_candidate | `github/awesome-copilot/secret-scanning` | T1 github/awesome-copilot | secret-safety, github-auto | github-projects-profile(28) | weak | review_required |
| 5 | 68.3 | install_candidate | `anthropics/skills/claude-api` | T1 anthropics/skills | llm-api | prompt-manager(36) | weak | review_required |
| 6 | 66.2 | install_candidate | `wshobson/agents/github-actions-templates` | T2 wshobson/agents | deploy, github-auto | github-projects-profile(28) | weak | review_required |
| 7 | 71.5 | watch | `microsoft/skills/frontend-ui-dark-ts` | T1 microsoft/skills | frontend-design | yejian-buguangdeng(66)；party-night-v1-2(50) | strong | pass |
| 8 | 71.5 | watch | `vercel-labs/agent-skills/react-view-transitions` | T1 vercel-labs/agent-skills | frontend-design | yejian-buguangdeng(58)；party-night-v1-2(38) | strong | pass |
| 9 | 66.0 | watch | `wshobson/agents/responsive-design` | T2 wshobson/agents | frontend-design, responsive | personal-rss(44)；family-insurance-dashboard(44) | strong | pass |
| 10 | 63.5 | watch | `anthropics/skills/web-artifacts-builder` | T1 anthropics/skills | frontend-design | yejian-buguangdeng(54)；a-share-index-valuation-report(40) | strong | review_required |
| 11 | 62.0 | watch | `wshobson/agents/python-packaging` | T2 wshobson/agents | desktop-app, python-auto | github-projects-profile(36)；DeepSeekBalanceWidget-Mac(36) | strong | pass |
| 12 | 61.4 | watch | `google/skills/google-mobile-ads-get-started` | T1 google/skills | android | landedazi-android(50) | strong | pass |
| 13 | 58.8 | watch | `vercel-labs/agent-skills/react-native-skills` | T1 vercel-labs/agent-skills | expo-rn | stretch-side-timer-project(96)；protein-calculator(84) | strong | pass |
| 14 | 55.6 | watch | `microsoft/skills/github-issue-creator` | T1 microsoft/skills | github-auto | github-projects-profile(32) | strong | pass |
| 15 | 75.8 | watch | `microsoft/skills/azure-microsoft-playwright-testing-ts` | T1 microsoft/skills | deploy, browser-qa | party-night-v1-2(32)；personal-rss(32) | weak | pass |
| 16 | 73.5 | watch | `google/skills/bigquery-bigframes` | T1 google/skills | python-auto | github-projects-profile(36)；DeepSeekBalanceWidget-Mac(36) | none | pass |
| 17 | 64.0 | watch | `google/skills/cloud-monitoring-chart-generation` | T1 google/skills | dashboard-viz | family-insurance-dashboard(32) | none | review_required |
| 18 | 84.0 | install_candidate | `anthropics/skills/webapp-testing` | T1 anthropics/skills | frontend-design, browser-qa | — | weak | review_required |
| 19 | 71.0 | watch | `vercel-labs/agent-skills/vercel-cli-with-tokens` | T1 vercel-labs/agent-skills | deploy, secret-safety | — | strong | review_required |
| 20 | 61.3 | watch | `bacoco/shipguard/sg-ship` | T—(unverified) bottom_up_search | browser-qa | — | weak | pass |
| 21 | 59.1 | watch | `huggingface/skills/hf-cloud-sagemaker-deployment-planner` | T1 huggingface/skills | deploy | — | strong | pass |
| 22 | 56.0 | watch | `stablyai/orca/orca-per-workspace-env` | T1 stablyai/orca | — | personal-rss(44)；family-insurance-dashboard(44) | weak | pass |

仓库分布：9 个仓库承载 22 条 → `github/awesome-copilot`×3、`anthropics/skills`×3、`wshobson/agents`×3、`microsoft/skills`×3、`vercel-labs/agent-skills`×3、`google/skills`×3、`stablyai/orca`×2。

### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（1 个功能族有备选）

候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。
判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。
备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。

| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |
|---|---|---|
| `anthropics/skills/webapp-testing` | `github/awesome-copilot/webapp-testing`（85） | 同名同功能 |

## 三、安全清单（Security Gate v2.3）

核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。每条 finding 带 `confidence` 与 `behavior_context`（mention / instruction / executable / remote_execution / **warning**），verdict 四值 `pass / review_required / block / unscanned`。

> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / 安全审计文档举反例）一律降为 `review_required`。

总体：pass 395 / review_required 202 / block 3 / unscanned 505

### 3.1 block 级阻断（reject，3 条）

仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。警示/反例语境不在此列。

| canonical_key | 来源 | 阻断规则 | 证据 |
|---|---|---|---|
| `github/awesome-copilot/aspire` | T1 | pipe_to_shell | `curl -sSL https://aspire.dev/install.sh | bash` |
| `github/awesome-copilot/azure-container-registry-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |
| `github/awesome-copilot/azure-devops-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |

### 3.2 review_required 需人工复核（202 条；其中 0 条被挡在安装候选之外）

口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— 一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable 的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；`warning` 语境（安全文档举反例）不挡安装、也不 block。

| canonical_key | 来源 | 是否挡安装 | 命中规则 |
|---|---|---|---|
| `anthropics/skills/claude-api` | T1 | 否（语境性提及） | credential_files,network_generic |
| `anthropics/skills/doc-coauthoring` | T1 | 否（语境性提及） | network_generic |
| `anthropics/skills/docx` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/mcp-builder` | T1 | 否（语境性提及） | network_generic |
| `anthropics/skills/pptx` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/webapp-testing` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/xlsx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/agent-governance` | T1 | 否（语境性提及） | network_generic,sudo |
| `github/awesome-copilot/agent-owasp-compliance` | T1 | 否（语境性提及） | dynamic_code |
| `github/awesome-copilot/containerize-aspnet-framework` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/containerize-aspnetcore` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/convert-excel-to-md` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/doc-and-modernize` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/flowstudio-power-automate-mcp` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/foundry-hosted-agent-copilotkit` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-actions-hardening` | T1 | 否（语境性提及） | credential_files |
| `github/awesome-copilot/github-copilot-starter` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-issues` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-release` | T1 | 否（语境性提及） | git_push_auto,network_generic |
| `github/awesome-copilot/mcp-create-declarative-agent` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/mcp-implementation-security-review` | T1 | 否（语境性提及） | credential_files,dynamic_code,network_generic,postinstall_hook |
| `github/awesome-copilot/mcp-security-audit` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/md-to-docx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/pr-dashboard` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/scoutqa-test` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/secret-scanning` | T1 | 否（语境性提及） | git_push_auto |
| `github/awesome-copilot/suggest-awesome-github-copilot-agents` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/suggest-awesome-github-copilot-instructions` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/suggest-awesome-github-copilot-skills` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/test-gap-audit` | T1 | 否（语境性提及） | bundled_scripts |
| `vercel-labs/agent-skills/deploy-to-vercel` | T1 | 否（语境性提及） | credential_files,git_push_auto,network_generic |
| `vercel-labs/agent-skills/web-design-guidelines` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-ads-api-mcp-setup` | T1 | 否（语境性提及） | network_generic,sudo |
| `google/skills/agent-platform-deploy` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `google/skills/cloud-monitoring-chart-generation` | T1 | 否（语境性提及） | bundled_scripts |
| `google/skills/gemini-agents-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-api` | T1 | 否（语境性提及） | credential_files |
| `google/skills/gemini-interactions-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-live-api` | T1 | 否（语境性提及） | sudo |
| `google/skills/google-cloud-global-frontend-configuration` | T1 | 否（语境性提及） | network_generic |

### 3.3 install 候选的两阶段审查（PASS 2）

带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行：进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 `.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。**只做静态读取，绝不执行脚本。**

深度审查状态分布：complete 24 / failed 0 / pending 0 / not_required 576 / skipped 505；`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。

## 四、更新候选（update_available，2 条）

| canonical_key | 外部最新 | 上游活跃度 | 说明 |
|---|---|---|---|
| `browseros-ai/browseros/browseros-neo` | — | active | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |
| `kkkkhazix/khazix-skills/aihot` | — | unknown | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |

### 4.1 恢复/替换候选（replacement_candidate，3 条）

判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，coverage=strong / availability=degraded），或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**

| canonical_key | 说明 |
|---|---|
| `stablyai/orca/computer-use` | 中分 51：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orca-cli` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orchestration` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |

## 五、v2.3 修掉的问题（语义精度整改记录）

v2.2 的架构不变，本轮只做**语义精度**整改（§一–§九）。

| # | 问题 | v2.2 表现 | v2.3 处置 |
|---|---|---|---|
| 1 | 「项目类型适用」单独制造项目匹配 | `TYPE_W=30` 最后 ×2，仅凭「同属 Web/PWA / Android / macOS」就拿到 60 分：`orca-emulator-android` → `DeepSeekBalanceWidget-Mac` 90；Bats testing → 多个普通 PWA 60；GitHub issue creator → Expo/Android 60 | 建立 **DIRECT_PROJECT_EVIDENCE**：`tech_stack` 直接命中 / `positioning` 语义命中 / `shared_need` 项目需求命中 / `lexical` 词面重叠（≥5 字符且非平台泛词）—— 四类至少一项成立才产生匹配，否则 `matched_projects=[]`；`TYPE_W` 30→10 降为 secondary boost，**不得单独成立**。本轮直接证据率 **351/351** |
| 2 | `llm-api` 把广告 API 当大模型接入 | `google-ads-api-mcp-setup` 因 `API + Gemini` 命中 llm-api；`google-mobile-ads-validate` 同样命中 | 改为「LLM/model/provider 语境 **AND** api/sdk/tool calling/structured output/streaming/接入 等动作」，并加 `none_of`（google ads / mobile ads / admob / advertising / prompt injection）|
| 3 | `deploy` 被 Vercel / CI 语境误命中 | `react-best-practices` 仅因来自 Vercel 命中 deploy；`bats-testing-patterns` 仅因 CI/CD 命中 deploy | `deploy` 的 `any_of` 只留**真部署动词**（deploy / hosting / release pipeline / 部署上线…）；vercel / netlify / ci-cd 全部降为 `context_terms` |
| 4 | `voice-input` 把「可拿语音口述当材料」当成语音能力 | `github-issue-creator` 命中 voice-input | `any_of` 去掉裸 `dictation` / `transcription`；新增 `none_of`（as input material / accepts voice dictation / as raw material / tts only）|
| 5 | `supabase-db` 被裸 RLS 误命中 | `powerbi-modeling` 因 RLS 命中 supabase-db（Power BI 也有 row-level security） | `all_groups` 收紧为**必须出现 `supabase`**；RLS 不再单独成立，普通 PostgreSQL 归 `postgres_db` |
| 6 | Top 内跨仓同功能族重复占版面 | `github/awesome-copilot/webapp-testing` 与 `anthropics/skills/webapp-testing` 同占 Top1 / Top2 | 新增 **FUNCTIONAL_CLUSTER**：normalized name 相同（≥5 字符）/ description jaccard ≥ 0.62 且同前缀 / content_fingerprint 相同 → Top 只出 PRIMARY，其余进 `alternatives`；候选池仍两条都保留。本轮折叠 **1** 条 |
| 7 | `always_block` 忽略语境，安全文档举反例被 reject | `destructive_rm_root` / `pipe_to_shell` 命中即 block —— 安全审查 Skill 在文档里写 `rm -rf /` 反例也被直接 reject | block 仅限 `remote_execution` / `executable` / 明确祈使 `instruction` **且非警示语境**；新增 `warning` 语境（`never` / `do not` / `禁止` / `不要` / 举反例）一律降 `review_required`。真 `rm -rf ~/`、真 `curl | bash` 仍必 block；`rm -rf /tmp/...` 不误伤 |
| 8 | Top30 用低质量 watch 凑数 | `SkillsMP business-and-financial-operations-occupations` 约 31 分，仍因是 watch 被塞进 Top | 三道质量门：`score ≥ 55`（配置化）+ 必须有个性化证据（matched need / capability gap / update / replacement 至少一项）+ T3 无 T1·T2·官方交叉佐证不进 Top；不足直接输出 TopN。本轮实际 **22/30** |
| 9 | 归档包不自定位；SKIP 被算成 PASS | 解压后跑 `支撑/tests/test_pipeline.py` 返回 0，但 installed / skill context / matched_projects 3 项其实是 SKIP，却被等价写成「21/21 PASS」 | 输入 A 三级优先序（`SKILL_CONTEXT_PATH` → 包内 `支撑/输入/SKILL_CONTEXT.md` → 本机默认路径）；输入 B 同级 v4 自动发现，找不到则 SKIP 并明确提示；测试摘要拆 **PASS / SKIP / FAIL** 三分，SKIP 不计入 PASS |

## 六、如何复现／核对

```bash
# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）
python3 scripts/run_daily.py
# 只重算候选池
python3 scripts/analyze.py
# 重新生成本对照件
python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md
# 离线测试（27 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）
python3 tests/test_pipeline.py
```

**依赖的输入（缺一不可）**：

| 输入 | 解析优先序（v2.3 §九） | 作用 |
|---|---|---|
| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → ② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | 决定 PROJECT_MATCH / 相关性否决 / matched_projects |
| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | ① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → ③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 `capability_gap_match` |
| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |

**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：

```bash
SKILL_REPO_ROOT=/path/to/仓库 \
SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \
SKILL_DATA_DIR=/path/to/data \
python3 scripts/run_daily.py
```

可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR` / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。

> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— 本件生成时输入 A local_default → `~/Developer/coding/1.Active/000-alw-github 档案/SKILL_CONTEXT.md`（可读）。

> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；对照件其余内容在不同环境下应当逐位一致。
