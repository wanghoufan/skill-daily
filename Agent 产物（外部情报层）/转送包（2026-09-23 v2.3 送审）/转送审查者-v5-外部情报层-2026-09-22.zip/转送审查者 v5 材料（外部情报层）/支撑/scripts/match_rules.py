# -*- coding: utf-8 -*-
"""语义匹配规则引擎（v2.2）。

为什么要有这个模块（v2.1 → v2.2 的根本改动）：
  v2.1 用的是「关键词列表 + 整词匹配」。虽然已经修掉了子串事故（`ui` 命中 build/require），
  但仍有更深的语义错误：**「出现某个平台词」被等同于「满足某项能力需求」**。
  典型误报：
    · Google Mobile Ads SDK / IMA DAI SDK / Penpot UI-UX / responsive-design
      → 只因文本里出现 android / ios / mobile / expo 就被记成 mobile_qa（移动端 QA）
    · alloydb-basics / postgresql-optimization
      → 只因出现 PostgreSQL 就被当成 supabase_db 缺口解决方案
    · 任何示例里带一段 Python → 就被认为解决「Python 本地自动化」
  这些误报会直接抬高 PROJECT_MATCH（25/100）与 CAPABILITY_GAP（20/100），
  把真正相关的候选挤下去。

MATCH_RULE 语义（本模块的核心数据结构）：
    {
      "all_groups": [ [kw,...], [kw,...] ],  # 组间 AND，组内 OR —— 「平台词 + 动作词」组合条件
      "any_of":     [kw, ...],               # 额外必要条件（与 all_groups 之间也是 AND）
      "none_of":    [kw, ...],               # 命中任一即否决（排除性条件）
      "context_terms": [kw, ...],            # 语境词：不参与判定，命中则记入证据用于解释
    }
  规则里出现的所有关键词一律走 hit()：单字词按整词匹配，含空格/点/井号的按短语匹配。
  **禁止子串匹配**（v2.1 的 `ui` 事故，见 tests/test_keyword_matching_no_substring.py）。

本模块只做纯计算，不读文件、不联网 —— 便于离线测试与在多台机器上复用。
"""
import re

# ---------- 命中原语 ----------
_WORD_RE = re.compile(r"[a-z0-9][a-z0-9\+#\.]*")


def bag(name, desc):
    """返回 (整词集合, 原文小写, 连字符/下划线归一化文本)。

    norm 用于短语匹配：把 `react-native` / `react_native` / `react native` 统一成
    "react native"，避免因为连接符写法不同而漏命中。
    """
    raw = f"{name or ''} {desc or ''}".lower()
    words = set(_WORD_RE.findall(raw))
    norm = re.sub(r"\s+", " ", re.sub(r"[\-_/]+", " ", raw))
    return words, raw, norm


def hit(words, text, norm, kw):
    """单字关键词 → 整词匹配；含空格/点/井号的关键词 → 短语匹配。

    整词匹配是硬要求：v2.1 之前用 `kw in text` 导致 `ui` 命中 build/require/guidance，
    使 PROJECT_MATCH 恒为满分、Top30 被无关技能占满。
    """
    k = kw.lower()
    if " " in k or "." in k or "#" in k:
        return k in norm or k in text
    return k in words


def hit_any(words, text, norm, kws):
    return any(hit(words, text, norm, k) for k in kws)


def match_rule(words, text, norm, rule):
    """执行一条 MATCH_RULE，返回 (是否命中, 命中证据列表)。

    判定顺序：all_groups（组间 AND / 组内 OR）→ any_of → none_of（否决）。
    context_terms 只补证据，不影响判定结果。
    """
    if not rule:
        return False, []
    ev = []
    for group in rule.get("all_groups") or []:
        h = [k for k in group if hit(words, text, norm, k)]
        if not h:
            return False, []
        ev += h
    a = rule.get("any_of")
    if a:
        h = [k for k in a if hit(words, text, norm, k)]
        if not h:
            return False, []
        ev += h
    n = rule.get("none_of")
    if n and hit_any(words, text, norm, n):
        return False, []
    for k in rule.get("context_terms") or []:
        if hit(words, text, norm, k):
            ev.append(k)
    return True, sorted(set(ev))


def rule_hits(cand, rules, limit=None):
    """对一整张规则表跑匹配，返回 [(key, [evidence]), ...]（保持规则表定义顺序）。"""
    words, text, norm = bag(cand.get("skill_name"), cand.get("description"))
    out = []
    for key, rule in rules.items():
        ok, ev = match_rule(words, text, norm, rule)
        if ok:
            out.append((key, ev))
            if limit and len(out) >= limit:
                break
    return out


# ==========================================================================
# 一、能力标签规则 CAP_RULE（读已装侧 CAPABILITY_SUPPRESSION / 决定能力缺口）
# ==========================================================================
# v2.2 关键收紧：
#   · mobile_qa 必须「移动平台证据」AND「QA/设备/构建验收证据」，不再单凭出现 android/mobile
#   · supabase_db 必须真 Supabase 语境（或 RLS）；普通 PostgreSQL 归 postgres_db
#   · 新增 mobile_dev / expo_rn_dev：移动「开发」能力与移动「QA」能力分列，
#     React Native / Expo 最佳实践属于开发，不自动属于 QA
_MOBILE_PLATFORM = ["android", "ios", "expo", "react native", "flutter", "mobile app",
                    "mobile application", "移动端", "安卓"]
_QA_OR_DEVICE = ["qa", "test", "tests", "testing", "e2e", "end to end", "adb", "emulator",
                 "real device", "device farm", "appium", "detox", "maestro", "xctest",
                 "espresso", "ui test", "build verification", "signing", "keystore", "apk",
                 "aab", "app bundle", "install verification", "launch verification",
                 "自动化测试", "真机", "签名"]

CAP_RULE = {
    "mobile_qa": {
        # 组间 AND：既要移动平台，又要 QA / 设备 / 构建验收证据
        "all_groups": [_MOBILE_PLATFORM, _QA_OR_DEVICE],
        "context_terms": _QA_OR_DEVICE + _MOBILE_PLATFORM,
    },
    "mobile_dev": {
        # 移动「开发」：只要是移动平台的开发/最佳实践即可，不要求 QA 证据
        "all_groups": [["expo", "react native", "flutter", "android", "ios", "swiftui",
                        "jetpack compose", "kotlin multiplatform", "mobile app development",
                        "mobile development", "跨平台开发", "移动开发"]],
        "any_of": ["app", "development", "developer", "skill", "best practices", "ui",
                   "component", "navigation", "编程", "框架"],
        "context_terms": ["expo", "react native", "android", "ios"],
    },
    "expo_rn_dev": {
        "all_groups": [["expo", "react native", "react-native", "expo router", "expo sdk",
                        "expo modules", "nativewind"]],
        "context_terms": ["expo", "react native"],
    },
    "image_creative": {
        "any_of": ["image generation", "image-generation", "image editing", "image-editing",
                   "illustration", "thumbnail", "svg art", "svg generation", "creative image",
                   "图片生成", "图片处理", "图像生成", "相册封面"],
        "none_of": ["image analysis", "imageanalysis", "ocr", "vision api", "object detection"],
    },
    "data_analytics": {
        "any_of": ["analytics", "data analysis", "data-analysis", "data visualization",
                   "data-visualization", "chart generation", "chart-generation", "pandas",
                   "dataframe", "report generation", "数据分析", "可视化"],
        "none_of": ["google analytics", "web analytics"],
    },
    "security_audit": {
        "any_of": ["security audit", "security-audit", "vulnerability", "owasp", "penetration test",
                   "penetration testing", "threat model", "secret scanning", "dependency audit",
                   "安全审计", "漏洞"],
    },
    "supabase_db": {
        # v2.3：裸 RLS 不足 —— Power BI / 其他数据库也有 row-level security，
        # 必须**明确出现 supabase** 才算 Supabase 能力（旧版把裸 rls 当证据，属误报）。
        "all_groups": [["supabase"]],
        "context_terms": ["rls", "row level security", "postgres", "postgresql",
                          "migration", "database"],
    },
    "postgres_db": {
        "all_groups": [["postgres", "postgresql", "psql", "pgvector", "alloydb", "cloud sql"]],
        "none_of": ["supabase"],
        "context_terms": ["database", "sql", "query", "index", "migration"],
    },
    "testing_qa": {
        "any_of": ["test", "tests", "testing", "qa", "e2e", "end to end", "playwright",
                   "pytest", "vitest", "jest", "unit test", "integration test", "test suite",
                   "测试", "自动化测试"],
    },
    "docx_xlsx": {
        "any_of": ["docx", "xlsx", "doc", "excel", "spreadsheet", "pptx", "powerpoint",
                   "office document", "office documents", "word document", "表格处理", "文档处理"],
    },
    "mcp_dev": {
        "any_of": ["mcp", "model context protocol"],
    },
    "windows": {
        "any_of": ["windows", "powershell", "win32", "wpf", "winui", "windows 11"],
    },
    "macos": {
        "any_of": ["macos", "darwin", "applescript", "appkit", "cocoa", "mac os"],
    },
    "frontend_design": {
        "any_of": ["frontend", "front-end", "front end", "web design", "web-design",
                   "ui design", "ui-design", "ui/ux", "ux", "css", "tailwind", "shadcn",
                   "design system", "design-system", "responsive design", "visual design",
                   "界面设计", "前端设计"],
    },
    "browser_automation": {
        "any_of": ["browser automation", "browser-automation", "playwright", "puppeteer",
                   "selenium", "chrome devtools", "cdp", "headless browser", "web scraping",
                   "浏览器自动化"],
    },
    "course_pipeline": {
        "any_of": ["transcript", "transcription", "course notes", "course-notes",
                   "markdown organize", "lecture notes"],
    },
    "deployment_vercel": {
        "all_groups": [["vercel"]],
        "context_terms": ["deploy", "deployment", "hosting", "preview"],
    },
    "deployment_netlify": {
        "all_groups": [["netlify"]],
        "context_terms": ["deploy", "deployment", "hosting"],
    },
    "github_ops": {
        "any_of": ["github", "pull request", "pull-request", "repository management",
                   "code review", "issue management"],
    },
}

# ==========================================================================
# 二、项目需求规则 NEED_RULE（需求侧真相源，读 SKILL_CONTEXT.md 的 needs 权重）
# ==========================================================================
# 与 CAP_RULE 分开的理由：CAP_RULE 决定「已装侧能力压制」，NEED_RULE 决定「是否命中
# 用户真实需求」。两侧混用会让「平台词」同时在两个方向放大误差。
NEED_RULE = {
    # w=51（最高权重）：Agent / 多智能体治理与提示词工程
    "agent-governance": {"any_of": ["agent governance", "agent orchestration", "multi agent",
                                    "multi-agent", "orchestrator", "agent team", "agent teams",
                                    "skill manager", "guardrail", "guardrails", "prompt engineering",
                                    "prompt-engineering", "subagent", "sub-agent", "agent protocol",
                                    "智能体治理", "多智能体"]},
    # v2.2 收紧：真实需求是「Android 真机 QA / 构建签名」，不是「任何 Android 内容」
    "android": {"all_groups": [["android", "kotlin", "jetpack", "gradle", "安卓"],
                               ["qa", "test", "testing", "e2e", "adb", "emulator", "real device",
                                "device", "build", "signing", "keystore", "apk", "aab",
                                "verification", "install", "launch", "真机", "签名"]],
                "context_terms": ["android", "kotlin"]},
    "browser-qa": {"any_of": ["browser testing", "browser-testing", "playwright", "e2e",
                              "end to end testing", "acceptance test", "visual testing",
                              "visual regression", "cdp", "webapp testing", "web app testing",
                              "浏览器测试", "端到端测试"]},
    "dashboard-viz": {"any_of": ["dashboard", "chart generation", "chart-generation",
                                 "data visualization", "data-visualization", "grafana",
                                 "plotting", "charts", "看板", "报表"]},
    "data-pipeline": {"any_of": ["etl", "data pipeline", "data-pipeline", "ingest",
                                 "data warehouse", "warehouse", "data ingestion"]},
    # v2.2 收紧：不再用裸 `release` 命中所有「发布」语境
    # v2.3 再收紧：Vercel / Netlify / CI-CD 只能作**语境**（context_terms），
    #   必须真的出现 deploy/hosting/release-pipeline 动作词才算「部署能力」。
    #   事故：react-best-practices 只因来自 Vercel、bats-testing-patterns 只因 CI/CD
    #   就被判成 deploy 能力。
    "deploy": {"any_of": ["deploy", "deployment", "deploying", "hosting", "hosted",
                          "release pipeline", "deployment pipeline", "deploy pipeline",
                          "publish pipeline", "static hosting", "site deployment",
                          "部署上线", "上线部署", "部署流水线"],
               "context_terms": ["vercel", "netlify", "cloudflare pages", "ci", "cd", "ci-cd",
                                 "ci cd", "continuous deployment", "continuous delivery",
                                 "github actions", "pipeline"],
               "none_of": ["deployment manager", "oracle"]},
    # v2.2 收紧：不能因描述里写 "desktop application" 就命中，重点在打包/签名/发布
    "desktop-app": {"any_of": ["tauri", "electron", "menubar", "menu bar app", "native desktop",
                               "desktop packaging", "app packaging", "packaging", "code signing",
                               "notarization", "dmg", "nsis", "msix", "app bundle", "pkg installer",
                               "跨平台打包", "桌面应用打包"],
                    "context_terms": ["desktop", "native", "installer"]},
    "docker-infra": {"any_of": ["docker", "dockerfile", "docker compose", "containerize",
                                "containerization", "compose file", "容器化"]},
    "expo-rn": {"any_of": ["expo", "react native", "react-native", "expo router", "expo sdk",
                           "expo modules", "nativewind"]},
    "finance-calc": {"any_of": ["finance", "financial", "portfolio", "stock", "stocks", "etf",
                                "investment", "investing", "dividend", "valuation", "backtest",
                                "quantitative trading", "估值", "股息", "投资", "回撤"]},
    "frontend-design": {"any_of": ["frontend", "front-end", "front end", "web design",
                                   "web-design", "ui design", "ui-design", "ui/ux", "ux",
                                   "css", "tailwind", "shadcn", "design system", "responsive design",
                                   "visual design", "前端设计", "界面设计", "设计审查"]},
    "github-auto": {"any_of": ["github", "pull request", "pull-request", "github actions",
                               "code review", "repository automation"]},
    # v2.2 收紧：不再用裸 `prompt`；重点在 API/SDK/streaming/structured output/tool calling
    # v2.3 再收紧：必须 **LLM/model/provider 语境** AND **API/SDK/动作词**。
    #   单独的 "API" / "SDK integration" / "Gemini" 不足以证明这是 LLM 接入能力。
    #   事故：google-ads-api-mcp-setup（Google Ads API + Gemini）、
    #        google-mobile-ads-validate（Mobile Ads SDK）都被误判成 LLM API 集成。
    "llm-api": {"all_groups": [["llm", "large language model", "language model", "openai",
                                "anthropic", "claude api", "dashscope", "qwen", "deepseek",
                                "gemini", "model api", "chat completion", "chat completions",
                                "text generation model", "大模型", "模型接入"]],
                "any_of": ["api", "sdk", "api integration", "sdk integration", "tool calling",
                           "function calling", "structured output", "streaming response",
                           "streaming", "model inference", "inference endpoint", "endpoint",
                           "provider integration", "接入", "调用"],
                # 广告 / 投放语境即使出现 Gemini 也不是 LLM 接入能力
                "none_of": ["google ads", "mobile ads", "admob", "advertising", "ad manager",
                            "ads api", "search ads", "ad network", "prompt injection"],
                "context_terms": ["api", "sdk", "model", "llm"]},
    "media-transcribe": {"any_of": ["transcript", "transcription", "whisper", "asr", "subtitle",
                                    "subtitles", "speech to text", "speech-to-text", "voice to text",
                                    "视频转文字", "字幕"]},
    # v2.2 收紧：不要裸 photo/image，重点在 EXIF / gallery / album / library / metadata
    "photo-mgmt": {"any_of": ["exif", "gallery", "albums", "album management", "photo library",
                              "photo-library", "image library", "photo management",
                              "photo-management", "image management", "asset management",
                              "asset library", "metadata extraction", "lightroom",
                              "media library", "相册", "照片管理", "素材管理"],
                   "context_terms": ["photo", "image", "metadata"]},
    "privacy-local": {"any_of": ["local first", "local-first", "privacy", "privacy preserving",
                                 "encryption", "encrypt", "end to end encrypted", "self hosted",
                                 "self-hosted", "data sovereignty", "本地优先", "隐私"]},
    "pwa-offline": {"any_of": ["pwa", "progressive web app", "offline first", "offline-first",
                               "offline support", "service worker", "service-worker",
                               "web app manifest", "installable web app", "离线", "本地存储"]},
    # v2.2 新增组合条件：Python 平台词 + 自动化/脚本/数据处理动作词
    "python-auto": {"all_groups": [["python", "python3"]],
                    "any_of": ["automation", "automate", "scripting", "script", "scripts",
                               "data processing", "data-processing", "local workflow",
                               "batch processing", "cli tool", "cli", "pandas", "csv",
                               "file processing", "自动化", "数据处理"],
                    "context_terms": ["python"]},
    "responsive": {"any_of": ["responsive", "responsiveness", "mobile first", "mobile-first",
                              "breakpoint", "media query", "responsive layout", "响应式"]},
    "secret-safety": {"any_of": ["secret", "secrets", "credential", "credentials", "api key",
                                 "api-key", "apikey", "env var", "env-var", "environment variable",
                                 "keychain", "dotenv", "secret management", "密钥管理"]},
    "spec-driven": {"any_of": ["spec driven", "spec-driven", "specification", "specifications",
                               "prd", "requirements document", "design doc", "rfc"]},
    # v2.2 收紧：必须真 Supabase 语境或 RLS；普通 PostgreSQL 不算
    # v2.3 再收紧：裸 RLS 不算（Power BI 等也有 row-level security）→ 必须明确 supabase
    "supabase-db": {"all_groups": [["supabase"]],
                    "context_terms": ["rls", "row level security", "postgres", "postgresql",
                                      "migration", "database"]},
    "task-integration": {"any_of": ["ticktick", "dida", "dida365", "task management",
                                    "task-management", "todo", "to-do", "calendar", "reminder",
                                    "task automation", "任务管理", "日历"]},
    # v2.2 收紧：不再把纯 TTS 当语音输入
    # v2.3 再收紧：**「可以接受 voice dictation 作为输入材料」≠「提供语音输入能力」**。
    #   事故：github-issue-creator（"create issues from voice dictation or text"）被误判。
    #   修法：必须同时有 voice/speech/audio 语境 AND 明确的语音输入/识别动作词；
    #        裸 `dictation`（常指「把听写文本当素材」）不再算证据。
    "voice-input": {"all_groups": [["voice", "speech", "audio", "microphone", "麦克风",
                                    "语音", "听写"]],
                    "any_of": ["voice input", "voice-input", "speech recognition",
                               "speech-to-text", "speech to text", "stt", "dictation engine",
                               "dictation mode", "dictation support", "audio input",
                               "voice control", "voice command", "transcribe audio",
                               "语音输入", "语音识别", "语音转文字", "声音输入"],
                    "none_of": ["voice dictation as input", "accepts voice dictation",
                                "as input material", "as raw material", "text to speech only",
                                "tts only"],
                    "context_terms": ["voice", "speech", "audio"]},
}

# 平台错配：用户技术栈（SKILL_CONTEXT.md tech）里不存在的云/企业平台与语言。
# 命中即降权（不直接否决——仍可能含通用方法），但必须显式记录，便于人工复核。
MISMATCH_KW = ["azure", "google cloud", "gcp", "bigquery", "aws", "amazon web services",
               "salesforce", "airflow", "kubernetes", "k8s", "terraform", "oracle", "sap",
               "dynamics 365", "sharepoint", "databricks", "snowflake", "java", "c#", ".net",
               "dotnet", "asp.net", "csharp", "spring boot", "blazor"]


def domain_mismatch(cand):
    """返回命中的错配平台列表（空 = 没错配）。"""
    words, text, norm = bag(cand.get("skill_name"), cand.get("description"))
    return [kw for kw in MISMATCH_KW if hit(words, text, norm, kw)]


# ==========================================================================
# 三、能力标签 / 需求匹配的高层接口
# ==========================================================================
def capability_tags(cand):
    """把候选映射到已装侧的能力命名空间（用于能力缺口匹配）。"""
    return [cap for cap, _ in rule_hits(cand, CAP_RULE)]


def matched_needs(cand, needs_meta):
    """返回命中的项目需求列表，按权重降序。

    needs_meta 来自 SKILL_CONTEXT.md 的 needs（{need: {"w": 权重, ...}}）；
    未在 NEED_RULE 里定义规则的需求会被跳过（保持证据驱动，不猜）。
    """
    out = []
    for need, ev in rule_hits(cand, NEED_RULE):
        meta = needs_meta.get(need)
        if not meta:
            continue
        out.append({"need": need, "weight": meta.get("w"), "evidence": ev[:6]})
    out.sort(key=lambda n: -(n["weight"] or 0))
    return out


# ==========================================================================
# 四、项目级匹配（v2.2 新增）：把「对我哪个项目有用」真正答成项目名
# ==========================================================================
# 数据源：SKILL_CONTEXT.md §2「当前活跃项目」，行格式：
#   - `repo-name` — 定位描述 — 技术栈1 / 技术栈2 — YYYY-MM-DD
# 设计原则：只做本地日报用途，不联网、不外传。
_PROJ_LINE_RE = re.compile(
    r"^-\s+`([^`]+)`\s+—\s+(.*?)\s+—\s+(.*?)\s+—\s+(\d{4}-\d{2}-\d{2})\s*$")

# 技术栈标签 → 候选侧关键词（含同义词/常见写法）
TECH_MATCH = {
    "TypeScript": {"kw": ["typescript", "ts"], "label": "TypeScript", "w": 6},
    "React": {"kw": ["react", "jsx", "tsx", "react hooks"], "label": "React", "w": 9},
    "Next.js": {"kw": ["next.js", "nextjs", "next js", "app router"], "label": "Next.js", "w": 9},
    "PWA": {"kw": ["pwa", "progressive web app", "web app manifest", "installable web app"],
            "label": "PWA", "w": 14},
    "离线与本地存储": {"kw": ["offline", "localstorage", "local storage", "indexeddb",
                              "service worker", "cache api"], "label": "离线/本地存储", "w": 13},
    "Supabase": {"kw": ["supabase"], "label": "Supabase", "w": 16},
    "Postgres": {"kw": ["postgres", "postgresql", "psql"], "label": "Postgres", "w": 12},
    "Python": {"kw": ["python", "python3"], "label": "Python", "w": 8},
    "Docker": {"kw": ["docker", "dockerfile", "docker compose", "container"], "label": "Docker",
               "w": 12},
    "自托管": {"kw": ["self hosted", "self-hosted", "selfhost", "homelab"], "label": "自托管",
               "w": 10},
    "Expo": {"kw": ["expo", "expo router", "expo sdk"], "label": "Expo", "w": 16},
    "React Native": {"kw": ["react native", "react-native", "nativewind"], "label": "React Native",
                     "w": 16},
    "Android": {"kw": ["android", "adb", "emulator", "apk", "aab", "gradle"], "label": "Android",
                "w": 15},
    "Kotlin": {"kw": ["kotlin", "jetpack compose"], "label": "Kotlin", "w": 12},
    # v2.3 §六：去掉裸 "macos" —— 「支持在 macOS 上运行」不等于「提供 macOS 桌面开发能力」。
    # 事故：orca-emulator-android 描述写着 "on Windows, Linux, or macOS"（平台支持声明），
    # 却因此匹配上了纯 macOS 的 DeepSeekBalanceWidget-Mac。
    # 现在只认真正的 macOS 开发栈词（AppKit / Cocoa / SwiftUI / 菜单栏 / Swift）。
    "macOS 桌面": {"kw": ["appkit", "cocoa", "swiftui", "menubar", "menu bar app", "swift",
                          "菜单栏应用", "macos app", "macos application"],
                   "label": "macOS 桌面", "w": 13},
    "原生": {"kw": ["native app", "native desktop", "swift", "objective-c"], "label": "原生", "w": 7},
    "LLM API": {"kw": ["llm", "openai", "anthropic", "dashscope", "qwen", "deepseek", "gemini",
                       "chat completion", "model api", "api integration"],
                "label": "LLM API 接入", "w": 14},
    "Tailwind": {"kw": ["tailwind", "shadcn"], "label": "Tailwind", "w": 8},
    "shadcn": {"kw": ["shadcn", "radix ui"], "label": "shadcn", "w": 7},
    "单文件 HTML 工具": {"kw": ["single html", "single-file html", "standalone html",
                                "single page html", "vanilla html"],
                         "label": "单文件 HTML", "w": 10},
    "Playwright": {"kw": ["playwright", "browser automation", "e2e"], "label": "Playwright", "w": 12},
    "Shell": {"kw": ["shell", "bash", "zsh", "command line", "cli script"], "label": "Shell", "w": 8},
    "Cloudflare": {"kw": ["cloudflare", "workers", "cloudflare pages"], "label": "Cloudflare",
                   "w": 10},
    "Vercel": {"kw": ["vercel"], "label": "Vercel", "w": 11},
    "Netlify": {"kw": ["netlify"], "label": "Netlify", "w": 11},
    "CF Pages": {"kw": ["cloudflare pages", "pages functions"], "label": "CF Pages", "w": 9},
    ".NET": {"kw": ["dotnet", ".net", "csharp", "c#", "wpf", "winui"], "label": ".NET", "w": 8},
    "C#": {"kw": ["csharp", "c#"], "label": "C#", "w": 7},
}

# 描述文本里的「事实关键词」→ 加权（用于描述层面重叠，弥补技术栈标签不全）
DESC_SIGNALS = {
    "打卡": {"kw": ["check in", "checkin", "打卡", "visit log"], "label": "打卡记录", "w": 6},
    "看板": {"kw": ["dashboard", "看板"], "label": "看板", "w": 9},
    "报告": {"kw": ["report", "报告"], "label": "报告生成", "w": 8},
    "离线": {"kw": ["offline", "离线"], "label": "离线可用", "w": 10},
    "测试": {"kw": ["test", "testing", "测试"], "label": "测试验证", "w": 8},
    "部署": {"kw": ["deploy", "deployment", "部署"], "label": "部署上线", "w": 9},
}


# 技术栈标签 → 项目类型（对应 SKILL_CONTEXT.md §1「当前主要开发类型」）
TECH_TYPE = {
    "PWA": "Web/PWA", "React": "Web/PWA", "Next.js": "Web/PWA", "TypeScript": "Web/PWA",
    "Tailwind": "Web/PWA", "shadcn": "Web/PWA", "单文件 HTML 工具": "Web/PWA",
    "离线与本地存储": "Web/PWA",
    "Expo": "Expo/RN", "React Native": "Expo/RN",
    "Android": "Android", "Kotlin": "Android",
    "macOS 桌面": "macOS 桌面", "原生": "macOS 桌面",
    ".NET": ".NET/Windows 桌面", "C#": ".NET/Windows 桌面",
    "Python": "Python 自动化", "Shell": "Shell/脚本",
    "LLM API": "AI/Agent 工具",
    "Supabase": "数据库/Supabase", "Postgres": "数据库/Supabase",
    "Docker": "部署/基础设施", "自托管": "部署/基础设施", "Vercel": "部署/基础设施",
    "Netlify": "部署/基础设施", "Cloudflare": "部署/基础设施", "CF Pages": "部署/基础设施",
}

# 候选能力 → 它真正能服务的项目类型
# 作用：像 webapp-testing（浏览器 E2E）这类候选，描述里不会出现 React/Next.js，
# 但它服务的正是「Web/PWA 项目」——没有这层映射就会答不出项目名。
CAP_TYPE = {
    "browser_automation": ["Web/PWA"],
    # testing_qa 太通用，不指向 Python 自动化等具体类型——否则 pytest 类候选会把
    # Web 测试类候选拖去匹配 Python 项目。真正的连接由技术栈词面（Python 标签）负责。
    "testing_qa": ["Web/PWA"],
    "frontend_design": ["Web/PWA"],
    "image_creative": ["Web/PWA"],
    "data_analytics": ["Python 自动化", "AI/Agent 工具"],
    "security_audit": ["Web/PWA", "部署/基础设施"],
    "mobile_qa": ["Expo/RN", "Android"],
    "mobile_dev": ["Expo/RN", "Android"],
    "expo_rn_dev": ["Expo/RN"],
    "supabase_db": ["数据库/Supabase"],
    "postgres_db": ["数据库/Supabase"],
    "deployment_vercel": ["部署/基础设施"],
    "deployment_netlify": ["部署/基础设施"],
    "mcp_dev": ["AI/Agent 工具"],
    "github_ops": ["AI/Agent 工具", "部署/基础设施"],
    "macos": ["macOS 桌面"],
    "windows": [".NET/Windows 桌面"],
    "docx_xlsx": ["Python 自动化"],
    "course_pipeline": ["Python 自动化"],
}
TYPE_W = 10   # v2.3：类型适用降为 **secondary boost**，不再单独产生 matched_project
TYPE_BOOST = TYPE_W   # 别名（语义同前，越小越说明它只是辅助证据）
DIRECT_EVIDENCE_KINDS = ("tech_stack", "positioning", "shared_need", "lexical")
DIRECT_EVIDENCE_LABEL = {
    "tech_stack": "项目技术栈直接命中",
    "positioning": "项目定位/功能语义直接命中",
    "shared_need": "项目自身需求与候选能力直接命中",
    "lexical": "项目定位与候选描述词面直接重叠",
}
# 词面重叠时忽略的「无区分度词」：平台名与技术栈泛词。
# 为什么：候选描述写 "runs on Windows, Linux, or macOS" 只是**平台支持声明**，
# 不该因此匹配上一个纯 macOS 项目（v2.3 实测事故：orca-emulator-android →
# DeepSeekBalanceWidget-Mac 就靠共有的 "macos" 一词成立的）。
_LEXICAL_STOP = {"macos", "windows", "linux", "android", "ios", "unix", "darwin",
                 "platform", "platforms", "device", "devices", "phone", "phones",
                 "support", "supports", "using", "based", "guide", "guides",
                 "skill", "skills", "tool", "tools", "workflow", "workflows",
                 "project", "projects", "local", "remote", "files", "python"}

# 命中的**项目需求** → 它能服务的项目类型。
# 为什么还需要这一层：`agent-governance`（最高权重需求）这类需求在 CAP_RULE 里
# 没有对应的已装侧能力标签，只靠能力标签推类型会漏掉一大批候选
#（实测覆盖率只有 21%，远达不到「高匹配候选必须答出项目名」的要求）。
NEED_TYPE = {
    "agent-governance": ["AI/Agent 工具"],
    "android": ["Android"],
    "browser-qa": ["Web/PWA"],
    "dashboard-viz": ["Web/PWA", "Python 自动化"],
    "data-pipeline": ["Python 自动化", "部署/基础设施"],
    "deploy": ["部署/基础设施"],
    "desktop-app": ["macOS 桌面", ".NET/Windows 桌面"],
    "docker-infra": ["部署/基础设施"],
    "expo-rn": ["Expo/RN"],
    "finance-calc": ["Web/PWA", "Python 自动化"],
    "frontend-design": ["Web/PWA"],
    "github-auto": ["AI/Agent 工具", "部署/基础设施"],
    "llm-api": ["AI/Agent 工具", "Web/PWA"],
    "media-transcribe": ["Python 自动化"],
    "photo-mgmt": ["Web/PWA", "Expo/RN"],
    "privacy-local": ["Web/PWA"],
    "pwa-offline": ["Web/PWA"],
    "python-auto": ["Python 自动化"],
    "responsive": ["Web/PWA"],
    "secret-safety": ["部署/基础设施"],
    "spec-driven": ["AI/Agent 工具"],
    "supabase-db": ["数据库/Supabase"],
    "task-integration": ["AI/Agent 工具"],
    "voice-input": ["Expo/RN", "Android"],
}


def load_projects(context_text):
    """从 SKILL_CONTEXT.md 文本解析「当前活跃项目」。返回 [{name, desc, tech[], date}]。"""
    projects = []
    in_section = False
    for line in (context_text or "").split("\n"):
        if line.startswith("## 2."):
            in_section = True
            continue
        if in_section and line.startswith("## 3."):
            break
        if not in_section:
            continue
        m = _PROJ_LINE_RE.match(line)
        if not m:
            continue
        name, desc, tech, date = m.groups()
        techs = [t.strip() for t in re.split(r"[/／、,，]", tech) if t.strip()]
        projects.append({"name": name.strip(), "desc": desc.strip(),
                         "tech": techs, "date": date.strip(),
                         "is_placeholder": desc.strip() in ("(无描述)", "")})
    return projects


def match_projects(cand, projects, limit=5, min_score=20):
    """为候选匹配最相关的项目，返回 [{project, evidence, direct_evidence, match_score}]。

    v2.3 关键改动（§一 / §六）：**禁止「项目类型适用」单独制造项目匹配**。

    旧实现把「候选能力所属类型 ∩ 项目所属类型」（TYPE_W=30，末尾 ×2 → 60 分）当作
    强证据，于是只要候选被打上 macOS / Android / Web-PWA 能力标签，就能匹配同类项目。
    实测误报：
      · `orca-emulator-android` → `DeepSeekBalanceWidget-Mac`（90 分，毫无关系）
      · Bats testing → 多个普通 PWA 项目（60 分）
      · GitHub issue creator → Expo / Android 项目（60 分）

    现在必须至少存在一条 **DIRECT_PROJECT_EVIDENCE**（直接证据）：
      ① tech_stack   候选能力与项目**明确技术栈**直接命中
      ② positioning  候选任务与项目**定位/功能语义**直接命中
      ③ shared_need  项目**自身需求**与候选能力直接命中
      ④ lexical      项目定位与候选描述**词面直接重叠**（长词，防 "app"/"test" 泛词）
    四者皆无 → **不产生 matched_project**（宁可空，也不给「类型像」的假匹配）。
    「同属 Web/PWA / Android / macOS」只作 secondary boost，不能单独成立。
    """
    words, text, norm = bag(cand.get("skill_name"), cand.get("description"))
    # 候选能服务的项目类型（只用于 secondary boost，不再作为入选依据）
    cand_types = set()
    for cap in capability_tags(cand):
        cand_types |= set(CAP_TYPE.get(cap, []))
    cand_needs = {need for need, _ev in rule_hits(cand, NEED_RULE)}
    for need in cand_needs:
        cand_types |= set(NEED_TYPE.get(need, []))
    out = []
    for p in projects:
        hits, score, direct = [], 0.0, []
        pwords, ptext, pnorm = bag(p["name"], p["desc"])
        # ① 直接证据：候选能力 ↔ 项目明确技术栈
        for t in p["tech"]:
            rule = TECH_MATCH.get(t)
            if not rule:
                continue
            if hit_any(words, text, norm, rule["kw"]):
                hits.append(rule["label"])
                score += rule["w"]
                direct.append(("tech_stack", rule["label"]))
        # ② 直接证据：候选任务 ↔ 项目定位/功能语义
        for _, sig in DESC_SIGNALS.items():
            if hit_any(pwords, ptext, pnorm, sig["kw"]) and hit_any(words, text, norm, sig["kw"]):
                hits.append(sig["label"])
                score += sig["w"]
                direct.append(("positioning", sig["label"]))
        # ③ 直接证据：项目自身需求 ↔ 候选能力
        p_needs = {need for need, _e in rule_hits(
            {"skill_name": p["name"], "description": p["desc"]}, NEED_RULE)}
        shared_needs = cand_needs & p_needs
        if shared_needs:
            score += min(12, 6 * len(shared_needs))
            direct.append(("shared_need", "/".join(sorted(shared_needs)[:3])))
        # ④ 直接证据：词面直接重叠（≥5 字符长词，且排除无区分度的平台/泛词）
        overlap = {w for w in (words & pwords) if len(w) >= 5 and w not in _LEXICAL_STOP}
        if overlap:
            score += min(10, 6 + 2 * len(overlap))
            direct.append(("lexical", "/".join(sorted(overlap)[:3])))
        if not direct:
            continue      # ← v2.3 核心：无直接证据 → 不产生匹配
        # secondary boost：类型适用只加分，不能单独让项目进 matched_projects
        ptypes = {TECH_TYPE.get(t) for t in p["tech"]} - {None}
        shared = cand_types & ptypes
        if shared:
            score += TYPE_BOOST
            hits.append("类型适用（次要）：" + "/".join(sorted(shared)))
        norm_score = min(96, int(round(score * 2.0)))   # 归一化到 0~96
        if norm_score < min_score:
            continue
        out.append({"project": p["name"],
                    "positioning": p["desc"][:90],
                    "evidence": hits[:6] or ["技术栈词面重叠"],
                    "direct_evidence": [f"{DIRECT_EVIDENCE_LABEL[k]}：{v}" for k, v in direct][:4],
                    "direct_evidence_kinds": sorted({k for k, _ in direct}),
                    "match_score": norm_score})
    # 同分时保持 projects 的原序（SKILL_CONTEXT.md §2 已按活跃日期降序）→ 活跃项目优先
    out.sort(key=lambda x: -x["match_score"])
    return out[:limit]
