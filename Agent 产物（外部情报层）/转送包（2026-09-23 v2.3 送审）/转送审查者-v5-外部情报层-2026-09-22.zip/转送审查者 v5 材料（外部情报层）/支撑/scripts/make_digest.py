#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""候选池精简对照件生成器（给审查者看的「看得完」视图）。

完整数据是 data/SKILL_CANDIDATES.json；本脚本只抽出几类可核对的切片：
  ① 总览计数（含数据质量 Gate 与安全 verdict 分布）
  ② Personalized Top（实际数量，不含 ignore/reject）+ ALTERNATIVES（跨仓同功能族）
  ③ 安全清单（block 级阻断 / review_required 需人工复核）
  ④ 更新候选与恢复候选
  ⑤ 本轮修掉的问题（整改记录）
  ⑥ 复现与依赖（口径以 v2.3 为准）

Top 的排序与多样性规则**直接复用 build_context 的函数**（`select_top`），不另写一套，
避免「日报里的 Top」与「对照件里的 Top」不一致。

用法：
    python3 scripts/make_digest.py                # 输出到 stdout
    python3 scripts/make_digest.py -o out.md      # 输出到文件
"""
import os
import sys
import json
import argparse
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (CANDIDATES_PATH, REGISTRY_PATH, load_config,  # noqa: E402
                    SKILL_CONTEXT_PATH, PATH_RESOLUTION, BASE)
import build_context as bc  # noqa: E402


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _path_source(key):
    """§九：报告某个输入到底走的是哪条解析路径（env / 包内自定位 / 本机默认）。
    `PATH_RESOLUTION` 形如 {"skill_context": "package:/.../支撑/输入/SKILL_CONTEXT.md"}"""
    return (PATH_RESOLUTION or {}).get(key, "未记录")


def _path_report(key, resolved):
    """给审查者看的可核对串：走的是哪条路径 + 最终落到哪个文件。

    注意：这一行**刻意随运行环境变化**（env / 包内自定位 / 本机默认），
    因此不同环境下重生成的对照件在这一行必然不同 —— 其余内容应当逐位一致。
    """
    label = _path_source(key)
    exists = "可读" if os.path.exists(resolved) else "**不可读**"
    shown = resolved
    # 归档包内自定位时，路径前缀因解压位置而异；只保留包内相对部分，便于核对
    if label.startswith("package:"):
        shown = "…/" + os.path.relpath(resolved, BASE)
    elif label == "local_default":
        shown = resolved.replace(os.path.expanduser("~"), "~")
    return f"{label} → `{shown}`（{exists}）"


def fmt_needs(pm):
    ns = (pm or {}).get("matched_needs") or []
    return ", ".join(ns[:3]) if ns else "—"


def fmt_projects(pm, limit=2):
    mps = (pm or {}).get("matched_projects") or []
    if not mps:
        return "—"
    return "；".join(f"{m['project']}({m['match_score']})" for m in mps[:limit])


def rules_of(sec, level=None):
    fs = [f for f in (sec or {}).get("findings", [])
          if level is None or f.get("level") == level]
    return ",".join(sorted({f.get("rule", "?") for f in fs})) or "—"


def build():
    cands_doc = load(CANDIDATES_PATH)
    I = cands_doc["candidates"]
    reg = load(REGISTRY_PATH)
    S = [x for t in reg["tiers"].values() for x in (t if isinstance(t, list) else [])]
    cfg = load_config()
    counts = cands_doc.get("counts", {})
    quarantine = cands_doc.get("quarantine", {})

    rec = collections.Counter(x["recommendation"] for x in I)
    rel = collections.Counter(x["installed_relationship"] for x in I)
    risk = collections.Counter(x["security"]["risk_level"] for x in I)
    verdict = collections.Counter(x["security"].get("verdict") for x in I)
    deep = collections.Counter(x["security"].get("deep_scan_status") for x in I)
    gap = collections.Counter((x.get("capability_gap_match") or {}).get("gap_level") for x in I)
    scanned = sum(1 for x in I if x["security"]["status"] == "scanned")
    # v2.2：分母只取「真有需求证据」的高匹配候选（与 build_context 口径一致）
    hm = [x for x in I if x["recommendation"] in ("install_candidate", "watch")
          and (x.get("project_match") or {}).get("need_evidence")]
    hm_proj = [x for x in hm if (x.get("project_match") or {}).get("matched_projects")]

    # --- Top：复用日报同一套门槛 + 排序 + 多样性/功能族规则 ---
    top_cfg = cfg.get("top_candidates", {})
    target_limit = top_cfg.get("target_limit", 30)
    min_top_score = top_cfg.get("min_score")
    allowed = tuple(top_cfg.get("allowed_recommendations", ["install_candidate", "watch"]))
    pool = [c for c in I
            if c["installed_relationship"] != "already_installed"
            and c["recommendation"] in allowed]
    ranked = sorted(pool, key=bc.rank_candidate)
    corroborated = bc.build_corroborated_repos(reg, I)
    top, top_alts = bc.select_top(ranked, limit=target_limit, min_score=min_top_score,
                                  corroborated_repos=corroborated)
    functional_dupes = sum(len(v) for v in top_alts.values())
    t3_unc = [c for c in ranked if bc.is_t3_uncorroborated(c, corroborated)]
    # §一：项目匹配「直接证据率」——matched_projects 每一条都必须带 direct_evidence
    mp_entries = [m for c in I
                  for m in ((c.get("project_match") or {}).get("matched_projects") or [])]
    mp_direct = [m for m in mp_entries if m.get("direct_evidence")]

    blocked = [x for x in I if x["security"].get("verdict") == "block"]
    review = [x for x in I if x["security"].get("verdict") == "review_required"]
    review_ctx = [x for x in review if x["security"].get("install_blocked")]
    review_mention = [x for x in review if not x["security"].get("install_blocked")]
    upd = [x for x in I if x.get("update_available")]
    repl = [x for x in I if x["installed_relationship"] == "replacement_candidate"]

    L = []
    A = L.append
    A("# 候选池精简对照件（External Skill Intelligence v2.3）")
    A("")
    A(f"> 数据基线：{cands_doc.get('generated')}｜源文件 `SKILL_CANDIDATES.json`（{len(I)} 条）")
    A("> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。")
    A("> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；"
      "排名/安装量只是 adoption signal，不等于推荐。")
    A("")

    # 一、总览
    A("## 一、总览")
    A("")
    A("| 项目 | 数值 |")
    A("|---|---|")
    A(f"| 来源注册表 | {len(S)} 源（" +
      " / ".join(f"T{k} {v}" for k, v in sorted(collections.Counter(s["tier"] for s in S).items())) + "）|")
    A(f"| 候选（raw → 合法池） | {counts.get('raw_candidates')} → {len(I)} |")
    A(f"| 数据质量 Gate | 剔除构建产物 {counts.get('invalid_artifacts_removed', 0)} 条 / "
      f"非法 skill 名 {counts.get('invalid_names_removed', 0)} 条 |")
    A(f"| bottom-up 硬门 | 共 {counts.get('bottom_up_total', 0)} 条搜索结果 → "
      f"过 SKILL.md 硬门 {counts.get('bottom_up_verified', 0)} / 隔离 {counts.get('bottom_up_quarantined', 0)} |")
    A(f"| 推荐分布 | " + " / ".join(f"{k} {v}" for k, v in sorted(rec.items())) + " |")
    A(f"| 与已装关系 | " + " / ".join(f"{k} {v}" for k, v in sorted(rel.items())) + " |")
    A(f"| 安全风险 | " + " / ".join(f"{k} {v}" for k, v in sorted(risk.items())) +
      f"（已静态审查 {scanned}）|")
    A(f"| 安全 verdict | pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)} |")
    A(f"| 深度静态审查 | complete {deep.get('complete',0)}（= install 候选）"
      f" / failed {deep.get('failed',0)} / pending {deep.get('pending',0)}"
      f" / not_required {deep.get('not_required',0)} / skipped {deep.get('skipped',0)} |")
    A(f"| 能力缺口 | " + " / ".join(f"{k} {v}" for k, v in sorted(gap.items(), key=lambda kv: str(kv[0]))) + " |")
    A(f"| 命中项目需求 / 平台错配 | "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('need_evidence'))} / "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('domain_mismatch'))} |")
    A(f"| matched_projects 覆盖（高匹配候选） | {len(hm_proj)}/{len(hm)} "
      f"({(len(hm_proj)/max(1,len(hm))):.0%}) —— **v2.3 起不再是 KPI**，只作参考 |")
    A(f"| matched_project 直接证据率 | {len(mp_direct)}/{len(mp_entries)} "
      f"—— 每条匹配都必须有 direct_evidence（§一）|")
    A(f"| update_available / replacement_candidate | {len(upd)} / {len(repl)} |")
    A("")
    A("> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` "
      "这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。")
    A("")

    # 二、Top
    A(f"## 二、Personalized Top（target_limit {target_limit} · 实际 {len(top)}）")
    A("")
    A("选取规则（与日报完全一致，复用同一函数 `select_top`）："
      f"① score ≥ **{min_top_score}**（配置化最低阈值）② 有真实个性化证据"
      "（matched need / capability gap / update / replacement 至少一个成立）"
      "③ T3/discovery_only 需有 T1·T2·官方交叉佐证 ④ recommendation ≥ watch ⑤ 分数；"
      "多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。")
    A("")
    A("> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；"
      f"符合标准的不足 {target_limit} 个时就输出实际数量，**不为凑数塞垃圾**。")
    A("")
    A(f"> 本轮被三道质量门挡下的：低分（< {min_top_score}）若干 / "
      f"无个性化证据若干 / T3 无交叉佐证 **{len(t3_unc)}** 条（仍留在 WATCHLIST）。"
      f"跨仓同功能族折叠 **{functional_dupes}** 条（见 2.1）。")
    A("")
    A("「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；")
    A("`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。")
    A("`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。")
    A("")
    A("| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |")
    A("|---|---|---|---|---|---|---|---|---|")
    for i, c in enumerate(top, 1):
        gm = c.get("capability_gap_match") or {}
        sec = c["security"]
        st = f"{sec.get('verdict')}"
        A(f"| {i} | {c['score']:.1f} | {c['recommendation']} | `{c['canonical_key']}` | "
          f"{'T' + str(c['source_tier']) if c.get('source_tier') is not None else 'T—(unverified)'} "
          f"{c.get('source', '—')} | "
          f"{fmt_needs(c.get('project_match'))} | {fmt_projects(c.get('project_match'))} | "
          f"{gm.get('gap_level', '—')} | {st} |")
    A("")
    if top:
        repo_dist = collections.Counter(f"{c['owner']}/{c['repo']}" for c in top)
        multi = "、".join(f"`{k}`×{v}" for k, v in repo_dist.most_common() if v > 1)
        A(f"仓库分布：{len(repo_dist)} 个仓库承载 {len(top)} 条"
          + (f" → {multi}" if multi else "") + "。")
        A("")

    # 二·1、功能簇 ALTERNATIVES（§三/§八）
    A(f"### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（{len(top_alts)} 个功能族有备选）")
    A("")
    A("候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；"
      "但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。")
    A("判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ "
      "description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。")
    A("备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。")
    A("")
    if top_alts:
        A("| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |")
        A("|---|---|---|")
        for pk, dups in list(top_alts.items())[:20]:
            names = "；".join(
                f"`{d['canonical_key']}`（{d.get('score', '—')}）" for d in dups[:4])
            reasons = "；".join(sorted({str(d.get("reason", "—")) for d in dups}))
            A(f"| `{pk}` | {names} | {reasons} |")
    else:
        A("（无：本轮 Top 内没有跨仓同功能族重复）")
    A("")

    # 三、安全清单
    A(f"## 三、安全清单（Security Gate v2.3）")
    A("")
    A("核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。"
      "每条 finding 带 `confidence` 与 `behavior_context`"
      "（mention / instruction / executable / remote_execution / **warning**），verdict 四值 "
      "`pass / review_required / block / unscanned`。")
    A("")
    A("> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。"
      "`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；"
      "`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / "
      "安全审计文档举反例）一律降为 `review_required`。")
    A("")
    A(f"总体：pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)}")
    A("")
    A(f"### 3.1 block 级阻断（reject，{len(blocked)} 条）")
    A("")
    A("仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、"
      "`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。"
      "警示/反例语境不在此列。")
    A("")
    if blocked:
        A("| canonical_key | 来源 | 阻断规则 | 证据 |")
        A("|---|---|---|---|")
        for x in blocked[:40]:
            ev = ""
            for f in x["security"]["findings"]:
                if f.get("level") == "block":
                    ev = (f.get("evidence") or "")[:70]
                    break
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{','.join(x['security'].get('blocking_rules') or [])} | `{ev}` |")
    else:
        A("（无）")
    A("")
    A(f"### 3.2 review_required 需人工复核（{len(review)} 条；其中 {len(review_ctx)} 条被挡在安装候选之外）")
    A("")
    A("口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— "
      "一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable "
      "的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；"
      "`warning` 语境（安全文档举反例）不挡安装、也不 block。")
    A("")
    if review:
        A("| canonical_key | 来源 | 是否挡安装 | 命中规则 |")
        A("|---|---|---|---|")
        for x in (review_ctx + review_mention)[:40]:
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{'是' if x['security'].get('install_blocked') else '否（语境性提及）'} | "
              f"{rules_of(x['security'])} |")
    else:
        A("（无）")
    A("")
    A(f"### 3.3 install 候选的两阶段审查（PASS 2）")
    A("")
    A("带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行："
      "进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 "
      "`.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。"
      "**只做静态读取，绝不执行脚本。**")
    A("")
    A(f"深度审查状态分布：complete {deep.get('complete',0)} / failed {deep.get('failed',0)}"
      f" / pending {deep.get('pending',0)} / not_required {deep.get('not_required',0)}"
      f" / skipped {deep.get('skipped',0)}；"
      f"`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。")
    A("")

    # 四、更新候选
    A(f"## 四、更新候选（update_available，{len(upd)} 条）")
    A("")
    if upd:
        A("| canonical_key | 外部最新 | 上游活跃度 | 说明 |")
        A("|---|---|---|---|")
        for x in upd:
            A(f"| `{x['canonical_key']}` | {x.get('latest_version') or '—'} | "
              f"{x.get('upstream_activity') or '—'} | {(x.get('update_note') or '')[:70]} |")
    else:
        A("（无）")
    A("")
    if repl:
        A(f"### 4.1 恢复/替换候选（replacement_candidate，{len(repl)} 条）")
        A("")
        A("判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，"
          "coverage=strong / availability=degraded），"
          "或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**")
        A("")
        A("| canonical_key | 说明 |")
        A("|---|---|")
        for x in repl:
            A(f"| `{x['canonical_key']}` | {(x.get('recommendation_reason') or '')[:90]} |")
        A("")

    # 五、本轮整改记录
    A("## 五、v2.3 修掉的问题（语义精度整改记录）")
    A("")
    A("v2.2 的架构不变，本轮只做**语义精度**整改（§一–§九）。")
    A("")
    A("| # | 问题 | v2.2 表现 | v2.3 处置 |")
    A("|---|---|---|---|")
    A("| 1 | 「项目类型适用」单独制造项目匹配 | `TYPE_W=30` 最后 ×2，仅凭"
      "「同属 Web/PWA / Android / macOS」就拿到 60 分：`orca-emulator-android` → "
      "`DeepSeekBalanceWidget-Mac` 90；Bats testing → 多个普通 PWA 60；"
      "GitHub issue creator → Expo/Android 60 | 建立 **DIRECT_PROJECT_EVIDENCE**："
      "`tech_stack` 直接命中 / `positioning` 语义命中 / `shared_need` 项目需求命中 / "
      "`lexical` 词面重叠（≥5 字符且非平台泛词）—— 四类至少一项成立才产生匹配，"
      "否则 `matched_projects=[]`；`TYPE_W` 30→10 降为 secondary boost，"
      f"**不得单独成立**。本轮直接证据率 **{len(mp_direct)}/{len(mp_entries)}** |")
    A("| 2 | `llm-api` 把广告 API 当大模型接入 | `google-ads-api-mcp-setup` 因 `API + Gemini` "
      "命中 llm-api；`google-mobile-ads-validate` 同样命中 | 改为「LLM/model/provider 语境 "
      "**AND** api/sdk/tool calling/structured output/streaming/接入 等动作」，"
      "并加 `none_of`（google ads / mobile ads / admob / advertising / prompt injection）|")
    A("| 3 | `deploy` 被 Vercel / CI 语境误命中 | `react-best-practices` 仅因来自 Vercel "
      "命中 deploy；`bats-testing-patterns` 仅因 CI/CD 命中 deploy | `deploy` 的 `any_of` "
      "只留**真部署动词**（deploy / hosting / release pipeline / 部署上线…）；"
      "vercel / netlify / ci-cd 全部降为 `context_terms` |")
    A("| 4 | `voice-input` 把「可拿语音口述当材料」当成语音能力 | "
      "`github-issue-creator` 命中 voice-input | `any_of` 去掉裸 `dictation` / "
      "`transcription`；新增 `none_of`（as input material / accepts voice dictation / "
      "as raw material / tts only）|")
    A("| 5 | `supabase-db` 被裸 RLS 误命中 | `powerbi-modeling` 因 RLS 命中 supabase-db"
      "（Power BI 也有 row-level security） | `all_groups` 收紧为**必须出现 `supabase`**；"
      "RLS 不再单独成立，普通 PostgreSQL 归 `postgres_db` |")
    A("| 6 | Top 内跨仓同功能族重复占版面 | `github/awesome-copilot/webapp-testing` 与 "
      "`anthropics/skills/webapp-testing` 同占 Top1 / Top2 | 新增 **FUNCTIONAL_CLUSTER**："
      "normalized name 相同（≥5 字符）/ description jaccard ≥ 0.62 且同前缀 / "
      "content_fingerprint 相同 → Top 只出 PRIMARY，其余进 `alternatives`；"
      f"候选池仍两条都保留。本轮折叠 **{functional_dupes}** 条 |")
    A("| 7 | `always_block` 忽略语境，安全文档举反例被 reject | `destructive_rm_root` / "
      "`pipe_to_shell` 命中即 block —— 安全审查 Skill 在文档里写 `rm -rf /` 反例也被直接 reject | "
      "block 仅限 `remote_execution` / `executable` / 明确祈使 `instruction` **且非警示语境**；"
      "新增 `warning` 语境（`never` / `do not` / `禁止` / `不要` / 举反例）一律降 "
      "`review_required`。真 `rm -rf ~/`、真 `curl | bash` 仍必 block；"
      "`rm -rf /tmp/...` 不误伤 |")
    A("| 8 | Top30 用低质量 watch 凑数 | `SkillsMP business-and-financial-operations-occupations` "
      "约 31 分，仍因是 watch 被塞进 Top | 三道质量门："
      f"`score ≥ {min_top_score}`（配置化）+ 必须有个性化证据"
      "（matched need / capability gap / update / replacement 至少一项）"
      "+ T3 无 T1·T2·官方交叉佐证不进 Top；不足直接输出 TopN。"
      f"本轮实际 **{len(top)}/{target_limit}** |")
    A("| 9 | 归档包不自定位；SKIP 被算成 PASS | 解压后跑 `支撑/tests/test_pipeline.py` 返回 0，"
      "但 installed / skill context / matched_projects 3 项其实是 SKIP，却被等价写成"
      "「21/21 PASS」 | 输入 A 三级优先序（`SKILL_CONTEXT_PATH` → 包内 "
      "`支撑/输入/SKILL_CONTEXT.md` → 本机默认路径）；输入 B 同级 v4 自动发现，"
      "找不到则 SKIP 并明确提示；测试摘要拆 **PASS / SKIP / FAIL** 三分，"
      "SKIP 不计入 PASS |")
    A("")

    # 六、复现
    A("## 六、如何复现／核对")
    A("")
    A("```bash")
    A("# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）")
    A("python3 scripts/run_daily.py")
    A("# 只重算候选池")
    A("python3 scripts/analyze.py")
    A("# 重新生成本对照件")
    A("python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md")
    A("# 离线测试（27 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）")
    A("python3 tests/test_pipeline.py")
    A("```")
    A("")
    A("**依赖的输入（缺一不可）**：")
    A("")
    A("| 输入 | 解析优先序（v2.3 §九） | 作用 |")
    A("|---|---|---|")
    A("| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → "
      "② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | "
      "决定 PROJECT_MATCH / 相关性否决 / matched_projects |")
    A("| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | "
      "① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → "
      "③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 "
      "`capability_gap_match` |")
    A("| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |")
    A("")
    A("**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，"
      "未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。"
      "命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：")
    A("")
    A("```bash")
    A("SKILL_REPO_ROOT=/path/to/仓库 \\")
    A("SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \\")
    A("SKILL_DATA_DIR=/path/to/data \\")
    A("python3 scripts/run_daily.py")
    A("```")
    A("")
    A("可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR`"
      " / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。"
      "换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。")
    A("")
    A(f"> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— "
      f"本件生成时输入 A {_path_report('skill_context', SKILL_CONTEXT_PATH)}。")
    A("")
    A("> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；"
      "对照件其余内容在不同环境下应当逐位一致。")
    A("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default="-", help="输出文件；默认 stdout")
    a = ap.parse_args()
    md = build()
    if a.out == "-":
        print(md)
    else:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"written: {a.out} ({len(md.encode('utf-8'))} B)")


if __name__ == "__main__":
    main()
