# 候选池精简对照件（External Skill Intelligence v2.4）

> 数据基线：2026-09-23｜源文件 `SKILL_CANDIDATES.json`（1106 条）
> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。
> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；排名/安装量只是 adoption signal，不等于推荐。

## 一、总览

| 项目 | 数值 |
|---|---|
| 来源注册表 | 17 源（T0 2 / T1 9 / T2 3 / T3 3）|
| 候选（raw → 合法池） | 1170 → 1106 |
| 数据质量 Gate | 剔除构建产物 67 条 / 非法 skill 名 1 条 |
| bottom-up 硬门 | 共 41 条搜索结果 → 过 SKILL.md 硬门 17 / 隔离 23 |
| 推荐分布 | ignore 569 / install_candidate 20 / reject 3 / watch 514 |
| 与已装关系 | already_installed 14 / complement 45 / new_capability 1025 / overlap 19 / replacement_candidate 3 |
| 安全风险 | high 3 / low 396 / medium 201 / unknown 506（已静态审查 600）|
| 安全 verdict | pass 396 / review_required 201 / block 3 / unscanned 506 |
| 深度静态审查 | complete 20（= install 候选） / failed 0 / pending 0 / not_required 580 / skipped 506 |
| 能力缺口 | none 8 / strong 979 / weak 119 |
| 命中项目需求 / 平台错配 | 217 / 311 |
| matched_projects 覆盖（高匹配候选） | 35/139 (25%) —— **v2.3 起不再是 KPI**，只作参考 |
| matched_project 直接证据完整性 | 167/167 —— 每条匹配都必须带 1 类直接证据（完整性自检，**不是**质量 KPI）|
| update_available / replacement_candidate | 2 / 3 |

> **v2.4 §十：`direct evidence` 的「字段非空率」不再作为精度指标。**
> 字段非空只能证明写了；能不能证明「证据真的有效」，要看下面的分项计数：

| PROJECT_MATCH_QUALITY | 数值 | 含义 |
|---|---|---|
| matched_candidates | 106 | 至少有一个 matched_project 的候选数 |
| strong_tech_evidence | 100 | 专用技术栈直接命中（Expo / RN / Android / Supabase / Next.js / PWA / Vercel / .NET…）|
| positioning_evidence | 11 | 项目定位/功能语义命中 |
| shared_need_evidence | 28 | 项目自身需求与候选能力命中 |
| lexical_evidence | 49 | 词面重叠（需 ≥2 个高区分度词，或 1 个项目域高信号词）|
| **secondary_tech_only_rejected** | 102 | **只**靠泛用技术栈（TS / React / Python / Docker…）硬凑、已被拒的候选数 |
| **negated_evidence_rejected** | 30 | 被否定窗口 / 排除语境压掉的命中次数（看得见门在工作）|
| lexical_single_rejected | 887 | 词面重叠只因单个低区分度词（manager / service…）而不足以成立的次数 |
| unresolved_mismatch_candidates | 311 | 存在未解除平台错配的候选数（只作观察）|

> 四个 `*_evidence` 是**「候选 × 项目」条数**，同一条可同时具备多种证据；所有 matched_project 都必须至少带 1 类直接证据。**准确率优先于 coverage：matched_projects 下降完全可以接受。**

> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` 这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。

## 二、Personalized Top（target_limit 30 · 实际 20）

选取规则（与日报完全一致，复用同一函数 `select_top`）：① score ≥ **55**（配置化最低阈值）② 有真实个性化证据（matched need / capability gap / update / replacement 至少一个成立）③ T3/discovery_only 需有 T1·T2·官方交叉佐证 ④ **无未解除的平台错配**（v2.4 §九：项目档案里没有任何项目用该平台 → 不进 Top）⑤ recommendation ≥ watch ⑥ 分数；多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。

> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；符合标准的不足 30 个时就输出实际数量，**不为凑数塞垃圾**。

> 本轮被三道质量门挡下的：低分（< 55）若干 / 无个性化证据若干 / T3 无交叉佐证 **23** 条（仍留在 WATCHLIST）。跨仓同功能族折叠 **1** 条（见 2.1）。

「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；
`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。
`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。

| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |
|---|---|---|---|---|---|---|---|---|
| 1 | 79.4 | install_candidate | `stablyai/orca/orca-emulator-android` | T1 stablyai/orca | android | landedazi-android(50) | none | pass |
| 2 | 72.2 | install_candidate | `github/awesome-copilot/publish-to-pages` | T1 github/awesome-copilot | deploy, github-auto | github-projects-profile(32) | weak | review_required |
| 3 | 68.3 | install_candidate | `anthropics/skills/claude-api` | T1 anthropics/skills | llm-api | prompt-manager(44) | weak | review_required |
| 4 | 65.6 | install_candidate | `github/awesome-copilot/breakdown-test` | T1 github/awesome-copilot | github-auto | prompt-manager(44) | weak | pass |
| 5 | 71.8 | watch | `github/awesome-copilot/web-design-reviewer` | T1 github/awesome-copilot | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 6 | 69.6 | watch | `google/skills/agent-platform-prompt-management` | T1 google/skills | deploy | prompt-manager(24) | strong | pass |
| 7 | 69.5 | watch | `vercel-labs/agent-skills/react-view-transitions` | T1 vercel-labs/agent-skills | frontend-design | yejian-buguangdeng(46) | strong | pass |
| 8 | 65.8 | watch | `wshobson/agents/tailwind-design-system` | T2 wshobson/agents | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 9 | 65.8 | watch | `wshobson/agents/responsive-design` | T2 wshobson/agents | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 10 | 61.4 | watch | `google/skills/google-mobile-ads-get-started` | T1 google/skills | android | landedazi-android(50) | strong | pass |
| 11 | 58.8 | watch | `vercel-labs/agent-skills/react-native-skills` | T1 vercel-labs/agent-skills | expo-rn | stretch-side-timer-project(96)；protein-calculator(84) | strong | pass |
| 12 | 57.6 | watch | `wshobson/agents/prompt-engineering-patterns` | T2 wshobson/agents | agent-governance | prompt-manager(24) | strong | pass |
| 13 | 55.6 | watch | `microsoft/skills/github-issue-creator` | T1 microsoft/skills | github-auto | github-projects-profile(32) | strong | pass |
| 14 | 84.0 | install_candidate | `anthropics/skills/webapp-testing` | T1 anthropics/skills | frontend-design, browser-qa | — | weak | review_required |
| 15 | 71.3 | install_candidate | `browseros-ai/browseros/test-ui` | T1 browseros-ai/BrowserOS | browser-qa | — | weak | review_required |
| 16 | 71.0 | watch | `vercel-labs/agent-skills/vercel-cli-with-tokens` | T1 vercel-labs/agent-skills | deploy, secret-safety | — | strong | review_required |
| 17 | 71.0 | watch | `google/skills/agent-platform-tuning` | T1 google/skills | deploy, llm-api | — | strong | review_required |
| 18 | 68.5 | watch | `microsoft/skills/frontend-ui-dark-ts` | T1 microsoft/skills | frontend-design | — | strong | pass |
| 19 | 68.5 | watch | `microsoft/skills/frontend-design-review` | T1 microsoft/skills | frontend-design | — | strong | pass |
| 20 | 68.5 | watch | `anthropics/skills/canvas-design` | T1 anthropics/skills | frontend-design | — | strong | pass |

仓库分布：8 个仓库承载 20 条 → `github/awesome-copilot`×3、`anthropics/skills`×3、`google/skills`×3、`vercel-labs/agent-skills`×3、`wshobson/agents`×3、`microsoft/skills`×3。

### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（1 个功能族有备选）

候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。
判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。
备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。

| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |
|---|---|---|
| `anthropics/skills/webapp-testing` | `github/awesome-copilot/webapp-testing`（85） | 同名同功能 |

## 三、安全清单（Security Gate v2.4 · 沿用 v2.2 语境判定）

核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。每条 finding 带 `confidence` 与 `behavior_context`（mention / instruction / executable / remote_execution / **warning**），verdict 四值 `pass / review_required / block / unscanned`。

> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / 安全审计文档举反例）一律降为 `review_required`。

总体：pass 396 / review_required 201 / block 3 / unscanned 506

### 3.1 block 级阻断（reject，3 条）

仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。警示/反例语境不在此列。

| canonical_key | 来源 | 阻断规则 | 证据 |
|---|---|---|---|
| `github/awesome-copilot/aspire` | T1 | pipe_to_shell | `curl -sSL https://aspire.dev/install.sh | bash` |
| `github/awesome-copilot/azure-container-registry-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |
| `github/awesome-copilot/azure-devops-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |

### 3.2 review_required 需人工复核（201 条；其中 0 条被挡在安装候选之外）

口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— 一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable 的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；`warning` 语境（安全文档举反例）不挡安装、也不 block。

| canonical_key | 来源 | 是否挡安装 | 命中规则 |
|---|---|---|---|
| `anthropics/skills/claude-api` | T1 | 否（语境性提及） | credential_files,network_generic |
| `anthropics/skills/doc-coauthoring` | T1 | 否（语境性提及） | network_generic |
| `anthropics/skills/docx` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/mcp-builder` | T1 | 否（语境性提及） | network_generic |
| `anthropics/skills/pptx` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/webapp-testing` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/xlsx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/agent-governance` | T1 | 否（语境性提及） | network_generic,sudo |
| `github/awesome-copilot/agent-owasp-compliance` | T1 | 否（语境性提及） | dynamic_code |
| `github/awesome-copilot/containerize-aspnet-framework` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/containerize-aspnetcore` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/convert-excel-to-md` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/doc-and-modernize` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/flowstudio-power-automate-mcp` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-actions-hardening` | T1 | 否（语境性提及） | credential_files |
| `github/awesome-copilot/github-copilot-starter` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-issues` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-release` | T1 | 否（语境性提及） | git_push_auto,network_generic |
| `github/awesome-copilot/mcp-create-declarative-agent` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/mcp-implementation-security-review` | T1 | 否（语境性提及） | credential_files,dynamic_code,network_generic,postinstall_hook |
| `github/awesome-copilot/mcp-security-audit` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/md-to-docx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/pr-dashboard` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/publish-to-pages` | T1 | 否（语境性提及） | bundled_scripts,git_push_auto,network_generic |
| `github/awesome-copilot/scoutqa-test` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/secret-scanning` | T1 | 否（语境性提及） | git_push_auto |
| `github/awesome-copilot/suggest-awesome-github-copilot-agents` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/suggest-awesome-github-copilot-instructions` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/suggest-awesome-github-copilot-skills` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/test-gap-audit` | T1 | 否（语境性提及） | bundled_scripts |
| `vercel-labs/agent-skills/deploy-to-vercel` | T1 | 否（语境性提及） | credential_files,git_push_auto,network_generic |
| `vercel-labs/agent-skills/web-design-guidelines` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-ads-api-mcp-setup` | T1 | 否（语境性提及） | network_generic,sudo |
| `google/skills/agent-platform-deploy` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `google/skills/cloud-monitoring-chart-generation` | T1 | 否（语境性提及） | bundled_scripts |
| `google/skills/gemini-agents-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-api` | T1 | 否（语境性提及） | credential_files |
| `google/skills/gemini-interactions-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-live-api` | T1 | 否（语境性提及） | sudo |
| `google/skills/google-cloud-global-frontend-configuration` | T1 | 否（语境性提及） | network_generic |

### 3.3 install 候选的两阶段审查（PASS 2）

带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行：进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 `.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。**只做静态读取，绝不执行脚本。**

深度审查状态分布：complete 20 / failed 0 / pending 0 / not_required 580 / skipped 506；`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。

## 四、更新候选（update_available，2 条）

| canonical_key | 外部最新 | 上游活跃度 | 说明 |
|---|---|---|---|
| `browseros-ai/browseros/browseros-neo` | — | active | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |
| `kkkkhazix/khazix-skills/aihot` | — | unknown | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |

### 4.1 恢复/替换候选（replacement_candidate，3 条）

判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，coverage=strong / availability=degraded），或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**

| canonical_key | 说明 |
|---|---|
| `stablyai/orca/computer-use` | 中分 52.0：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orca-cli` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orchestration` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |

## 五、v2.4 修掉的问题（项目相关性最终收口）

v2.3 的架构、来源层、安全 Gate、Top 质量门、功能族折叠、归档自定位**全部保持**；本轮只修最后一类问题：**「规则形式上有 direct evidence，但真实语义仍是假相关。」**

| # | 问题 | v2.3 表现 | v2.4 处置 |
|---|---|---|---|
| 1 | 技术栈命中天然等于「直接项目证据」 | `azure-microsoft-playwright-testing-ts` 仅因描述里有 TypeScript，就匹配 party-night / personal-rss / protein-calculator / stretch-routine / prompt-manager 五个普通 TS 项目 | 把技术栈证据拆成 **STRONG / SECONDARY** 两级：专用技术栈（Expo / RN / Android / Supabase / Next.js / PWA / Vercel / .NET / Playwright / macOS 桌面…）可**独立**成立；泛用技术栈（TypeScript / JavaScript / Python / React / Docker / Shell / HTML / CSS / 自托管…）只加 `SECONDARY_BOOST`，**绝不单独成立**。直接证据首项由 `tech_stack` 改名 `strong_tech`；并加不变式守卫：strong 技术栈的权重必须够独立过 `min_score` |
| 2 | Docker 词典含裸 `container` | `container queries` 被当成 Docker → `responsive-design` 匹配 personal-rss / family-insurance-dashboard / hongli-dixin-calc；`orca-per-workspace-env` 也被牵连 | Docker 只认容器化语境词（docker / dockerfile / docker compose / containerization / container image / container runtime / docker container / 容器化），**删掉裸 `container`** |
| 3 | 词面重叠凭单个泛词成立 | Azure Resource Manager Skill 与 `prompt-manager` 只共有 `manager`，就产出「项目定位与候选描述词面直接重叠：manager」 | 大幅扩展泛词 stop list（manager / management / resource / service(s) / application(s) / system(s) / development / developer / testing / test(s) / data / model(s) / client / server / api(s)…）；词面证据改为「**≥2 个非 stop 的高区分度词**」或「**1 个项目域高信号词**」（prompt / insurance / rss / transcription / playwright / supabase / obsidian / valuation / dividend…）；单泛词一律不成立，并计入 `lexical_single_rejected` |
| 4 | 关键词落进否定语境仍算正向证据 | `azure-resource-manager-playwright-dotnet` 明写 `NOT for running Playwright tests`，却因出现 Playwright 被判 `browser-qa`；管理面 / 资源编排语境（management plane / control plane / resource manager / name availability / workspace quota）同样被误判 | 新增**通用否定窗口**（不是给 Playwright 打补丁）：按小句切分后丢弃含 `not / never / don't / does not / avoid / without / not intended / 非用于 / 不用于 / 不支持` 等否定标记的小句，只在**正向视图**判定命中；Skill 名不受描述否定影响。被压制且原本会命中的记入 `negated_evidence_rejected` |
| 5 | `deploy` 仍被 cloud-hosted / CI-CD 命中 | `azure-microsoft-playwright-testing-ts` 写的是 `cloud-hosted browsers` 与 CI/CD 集成，也被判 deploy —— 这不是「部署用户项目」 | 从 deploy 正向 `any_of` 删掉裸 `hosted`；`hosting / hosted / publish / publishing` 必须与**部署对象**（app / application / site / service / pages / build / artifact / production / environment…）同现才成立；CI/CD 只作 context，不是正向动作 |
| 6 | `testing_qa` 被偶然的 test / QA 污染 | `ai-prompt-engineering-safety-review` 只是提到 `testing methodologies`、`ai-team-orchestration` 只是 `optional QA`、`orca-per-workspace-env` 核心是环境 recipe，却都被打上 testing_qa，白拿 weak gap 的 15 分加成、人为推高排名 | testing_qa 改成**主能力证据**二选一：A. Skill 名本身含 test / testing / qa / e2e / playwright / pytest / vitest / jest…；B. 描述把测试当**核心任务**（run tests / write tests / test application / QA workflow / acceptance testing / regression testing / validate behavior / test suite / e2e tests / browser testing…）。`testing methodologies` / `optional QA` / `may be tested` / `QA is optional` / `examples include testing` 只算**提及**，不算能力 |
| 7 | `domain_mismatch` 只记录、不影响排序 | Azure Playwright Testing / Azure Resource Manager Playwright .NET / SageMaker deployment planner 虽已标 `domain_mismatch = azure / dotnet / aws`，仍能占高位 Top | 未解除的错配 → **不得 install_candidate、不得进 Personalized Top、总分 ×0.7 penalty**，默认进 watchlist；`select_top` 增加第四道门。解除条件 = **用户真实项目明确使用该平台**（Azure / AWS / .NET…），解除后自动走正常路径 ——**不做永久 blacklist**，只是「当前没有证据使用该技术栈 → 不该占个人 Top」|
| 8 | 精度指标只能证明「字段不为空」 | `351/351 direct evidence` 说明不了证据是否有效 | 改为 **PROJECT_MATCH_QUALITY**：分别统计 strong_tech / positioning / shared_need / lexical 四类证据条数，以及 `secondary_tech_only_rejected` / `negated_evidence_rejected` / `lexical_single_rejected` 三个「被拒」计数。**准确率优先于 coverage，matched_projects 下降完全可以接受** |

### 5.1 附带修掉的两个「规则看起来对、实际不生效」缺陷

v2.4 排查中发现并修掉 —— 二者都属于「写在配置里也测不出来」的类型，且会让 §五 的中文否定标记形同虚设：

| # | 缺陷 | 后果 | 处置 |
|---|---|---|---|
| A | 中文关键词命中率恒为 0 | `_WORD_RE` 是纯 ASCII（`[a-z0-9]…`），中文没有词边界，整词匹配下规则表里 **48 个 NEED_RULE + 27 个 CAP_RULE 中文关键词**，加上 TECH_MATCH 的 `容器化` / `菜单栏应用`，**全部是永不命中的死词** | 含 CJK 的关键词改走子串匹配；回归测试对规则表做**全量自检**（中文关键词不得再有死词），同时保留英文整词匹配（`ui` 命中 build 的老事故不许回归）|
| B | 分句不含逗号 → 否定窗口过度压制 | 「非用于 A，可用于 B」整句被丢弃，把逗号后的**正向证据**一起误杀 | 逗号（`,` / `，`）纳入分句边界，否定只作用于本小句；修掉后 `negated_evidence_rejected` 由 **94 降到 30**，即减少了 64 处「假压制」|

### 5.2 v2.3 已验收通过、本轮**不重做**（§十二）

17 source registry · T0/T1/T2/T3 分层 · bottom-up 非 Skill 隔离 · ClawHub 构建产物过滤 · mobile_qa 误报修复 · supabase-db 普通 PostgreSQL 误报修复 · llm-api 广告 API 误报修复 · voice-input 误报修复 · Security warning vs 真执行区分 · deep scan 安装候选 Gate · Top 不含 ignore/reject · Top 不凑 30 · T3 无佐证不进 Top · functional family / alternatives · source official 口径统一 · 测试 PASS/SKIP/FAIL 三分 · 包内 SKILL_CONTEXT 自定位。

本轮结果：Top 实际 **20/30**，跨仓同功能族折叠 **1** 条，Top 内未解除平台错配 **0** 条。

## 六、如何复现／核对

```bash
# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）
python3 scripts/run_daily.py
# 只重算候选池
python3 scripts/analyze.py
# 重新生成本对照件
python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md
# 离线测试（35 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）
python3 tests/test_pipeline.py
```

**依赖的输入（缺一不可）**：

| 输入 | 解析优先序（v2.3 §九 / v2.4 §十二 保持） | 作用 |
|---|---|---|
| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → ② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | 决定 PROJECT_MATCH / 相关性否决 / matched_projects |
| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | ① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → ③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 `capability_gap_match` |
| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |

**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：

```bash
SKILL_REPO_ROOT=/path/to/仓库 \
SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \
SKILL_DATA_DIR=/path/to/data \
python3 scripts/run_daily.py
```

可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR` / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。

> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— 本件生成时输入 A local_default → `~/Developer/coding/1.Active/000-alw-github 档案/SKILL_CONTEXT.md`（可读）。

> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；对照件其余内容在不同环境下应当逐位一致。
