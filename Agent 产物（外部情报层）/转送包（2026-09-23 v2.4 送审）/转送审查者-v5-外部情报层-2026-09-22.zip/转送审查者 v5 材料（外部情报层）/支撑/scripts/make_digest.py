#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""候选池精简对照件生成器（给审查者看的「看得完」视图）。

完整数据是 data/SKILL_CANDIDATES.json；本脚本只抽出几类可核对的切片：
  ① 总览计数（含数据质量 Gate 与安全 verdict 分布）
  ② Personalized Top（实际数量，不含 ignore/reject）+ ALTERNATIVES（跨仓同功能族）
  ③ 安全清单（block 级阻断 / review_required 需人工复核）
  ④ 更新候选与恢复候选
  ⑤ 本轮修掉的问题（整改记录）
  ⑥ 复现与依赖（口径以 v2.4 为准）

Top 的排序与多样性规则**直接复用 build_context 的函数**（`select_top`），不另写一套，
避免「日报里的 Top」与「对照件里的 Top」不一致。

用法：
    python3 scripts/make_digest.py                # 输出到 stdout
    python3 scripts/make_digest.py -o out.md      # 输出到文件
"""
import os
import sys
import json
import argparse
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (CANDIDATES_PATH, REGISTRY_PATH, load_config,  # noqa: E402
                    SKILL_CONTEXT_PATH, PATH_RESOLUTION, BASE)
import build_context as bc  # noqa: E402


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _path_source(key):
    """§九：报告某个输入到底走的是哪条解析路径（env / 包内自定位 / 本机默认）。
    `PATH_RESOLUTION` 形如 {"skill_context": "package:/.../支撑/输入/SKILL_CONTEXT.md"}"""
    return (PATH_RESOLUTION or {}).get(key, "未记录")


def _path_report(key, resolved):
    """给审查者看的可核对串：走的是哪条路径 + 最终落到哪个文件。

    注意：这一行**刻意随运行环境变化**（env / 包内自定位 / 本机默认），
    因此不同环境下重生成的对照件在这一行必然不同 —— 其余内容应当逐位一致。
    """
    label = _path_source(key)
    exists = "可读" if os.path.exists(resolved) else "**不可读**"
    shown = resolved
    # 归档包内自定位时，路径前缀因解压位置而异；只保留包内相对部分，便于核对
    if label.startswith("package:"):
        shown = "…/" + os.path.relpath(resolved, BASE)
    elif label == "local_default":
        shown = resolved.replace(os.path.expanduser("~"), "~")
    return f"{label} → `{shown}`（{exists}）"


def fmt_needs(pm):
    ns = (pm or {}).get("matched_needs") or []
    return ", ".join(ns[:3]) if ns else "—"


def fmt_projects(pm, limit=2):
    mps = (pm or {}).get("matched_projects") or []
    if not mps:
        return "—"
    return "；".join(f"{m['project']}({m['match_score']})" for m in mps[:limit])


def rules_of(sec, level=None):
    fs = [f for f in (sec or {}).get("findings", [])
          if level is None or f.get("level") == level]
    return ",".join(sorted({f.get("rule", "?") for f in fs})) or "—"


def build():
    cands_doc = load(CANDIDATES_PATH)
    I = cands_doc["candidates"]
    reg = load(REGISTRY_PATH)
    S = [x for t in reg["tiers"].values() for x in (t if isinstance(t, list) else [])]
    cfg = load_config()
    counts = cands_doc.get("counts", {})
    quarantine = cands_doc.get("quarantine", {})

    rec = collections.Counter(x["recommendation"] for x in I)
    rel = collections.Counter(x["installed_relationship"] for x in I)
    risk = collections.Counter(x["security"]["risk_level"] for x in I)
    verdict = collections.Counter(x["security"].get("verdict") for x in I)
    deep = collections.Counter(x["security"].get("deep_scan_status") for x in I)
    gap = collections.Counter((x.get("capability_gap_match") or {}).get("gap_level") for x in I)
    scanned = sum(1 for x in I if x["security"]["status"] == "scanned")
    # v2.2：分母只取「真有需求证据」的高匹配候选（与 build_context 口径一致）
    hm = [x for x in I if x["recommendation"] in ("install_candidate", "watch")
          and (x.get("project_match") or {}).get("need_evidence")]
    hm_proj = [x for x in hm if (x.get("project_match") or {}).get("matched_projects")]

    # --- Top：复用日报同一套门槛 + 排序 + 多样性/功能族规则 ---
    top_cfg = cfg.get("top_candidates", {})
    target_limit = top_cfg.get("target_limit", 30)
    min_top_score = top_cfg.get("min_score")
    allowed = tuple(top_cfg.get("allowed_recommendations", ["install_candidate", "watch"]))
    pool = [c for c in I
            if c["installed_relationship"] != "already_installed"
            and c["recommendation"] in allowed]
    ranked = sorted(pool, key=bc.rank_candidate)
    corroborated = bc.build_corroborated_repos(reg, I)
    top, top_alts = bc.select_top(ranked, limit=target_limit, min_score=min_top_score,
                                  corroborated_repos=corroborated)
    functional_dupes = sum(len(v) for v in top_alts.values())
    t3_unc = [c for c in ranked if bc.is_t3_uncorroborated(c, corroborated)]
    # §一：项目匹配「直接证据率」——matched_projects 每一条都必须带 direct_evidence
    mp_entries = [m for c in I
                  for m in ((c.get("project_match") or {}).get("matched_projects") or [])]
    mp_direct = [m for m in mp_entries if m.get("direct_evidence")]

    blocked = [x for x in I if x["security"].get("verdict") == "block"]
    review = [x for x in I if x["security"].get("verdict") == "review_required"]
    review_ctx = [x for x in review if x["security"].get("install_blocked")]
    review_mention = [x for x in review if not x["security"].get("install_blocked")]
    upd = [x for x in I if x.get("update_available")]
    repl = [x for x in I if x["installed_relationship"] == "replacement_candidate"]

    L = []
    A = L.append
    A("# 候选池精简对照件（External Skill Intelligence v2.4）")
    A("")
    A(f"> 数据基线：{cands_doc.get('generated')}｜源文件 `SKILL_CANDIDATES.json`（{len(I)} 条）")
    A("> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。")
    A("> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；"
      "排名/安装量只是 adoption signal，不等于推荐。")
    A("")

    # 一、总览
    A("## 一、总览")
    A("")
    A("| 项目 | 数值 |")
    A("|---|---|")
    A(f"| 来源注册表 | {len(S)} 源（" +
      " / ".join(f"T{k} {v}" for k, v in sorted(collections.Counter(s["tier"] for s in S).items())) + "）|")
    A(f"| 候选（raw → 合法池） | {counts.get('raw_candidates')} → {len(I)} |")
    A(f"| 数据质量 Gate | 剔除构建产物 {counts.get('invalid_artifacts_removed', 0)} 条 / "
      f"非法 skill 名 {counts.get('invalid_names_removed', 0)} 条 |")
    A(f"| bottom-up 硬门 | 共 {counts.get('bottom_up_total', 0)} 条搜索结果 → "
      f"过 SKILL.md 硬门 {counts.get('bottom_up_verified', 0)} / 隔离 {counts.get('bottom_up_quarantined', 0)} |")
    A(f"| 推荐分布 | " + " / ".join(f"{k} {v}" for k, v in sorted(rec.items())) + " |")
    A(f"| 与已装关系 | " + " / ".join(f"{k} {v}" for k, v in sorted(rel.items())) + " |")
    A(f"| 安全风险 | " + " / ".join(f"{k} {v}" for k, v in sorted(risk.items())) +
      f"（已静态审查 {scanned}）|")
    A(f"| 安全 verdict | pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)} |")
    A(f"| 深度静态审查 | complete {deep.get('complete',0)}（= install 候选）"
      f" / failed {deep.get('failed',0)} / pending {deep.get('pending',0)}"
      f" / not_required {deep.get('not_required',0)} / skipped {deep.get('skipped',0)} |")
    A(f"| 能力缺口 | " + " / ".join(f"{k} {v}" for k, v in sorted(gap.items(), key=lambda kv: str(kv[0]))) + " |")
    A(f"| 命中项目需求 / 平台错配 | "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('need_evidence'))} / "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('domain_mismatch'))} |")
    A(f"| matched_projects 覆盖（高匹配候选） | {len(hm_proj)}/{len(hm)} "
      f"({(len(hm_proj)/max(1,len(hm))):.0%}) —— **v2.3 起不再是 KPI**，只作参考 |")
    A(f"| matched_project 直接证据完整性 | {len(mp_direct)}/{len(mp_entries)} "
      f"—— 每条匹配都必须带 1 类直接证据（完整性自检，**不是**质量 KPI）|")
    A(f"| update_available / replacement_candidate | {len(upd)} / {len(repl)} |")
    A("")
    A("> **v2.4 §十：`direct evidence` 的「字段非空率」不再作为精度指标。**")
    A("> 字段非空只能证明写了；能不能证明「证据真的有效」，要看下面的分项计数：")
    A("")
    pq = cands_doc.get("project_match_quality") or {}
    if pq:
        A("| PROJECT_MATCH_QUALITY | 数值 | 含义 |")
        A("|---|---|---|")
        A(f"| matched_candidates | {pq.get('matched_candidates', 0)} | 至少有一个 matched_project 的候选数 |")
        A(f"| strong_tech_evidence | {pq.get('strong_tech_evidence', 0)} | "
          "专用技术栈直接命中（Expo / RN / Android / Supabase / Next.js / PWA / Vercel / .NET…）|")
        A(f"| positioning_evidence | {pq.get('positioning_evidence', 0)} | 项目定位/功能语义命中 |")
        A(f"| shared_need_evidence | {pq.get('shared_need_evidence', 0)} | 项目自身需求与候选能力命中 |")
        A(f"| lexical_evidence | {pq.get('lexical_evidence', 0)} | "
          "词面重叠（需 ≥2 个高区分度词，或 1 个项目域高信号词）|")
        A(f"| **secondary_tech_only_rejected** | {pq.get('secondary_tech_only_rejected', 0)} | "
          "**只**靠泛用技术栈（TS / React / Python / Docker…）硬凑、已被拒的候选数 |")
        A(f"| **negated_evidence_rejected** | {pq.get('negated_evidence_rejected', 0)} | "
          "被否定窗口 / 排除语境压掉的命中次数（看得见门在工作）|")
        A(f"| lexical_single_rejected | {pq.get('lexical_single_rejected', 0)} | "
          "词面重叠只因单个低区分度词（manager / service…）而不足以成立的次数 |")
        A(f"| unresolved_mismatch_candidates | {pq.get('unresolved_mismatch_candidates', 0)} | "
          "存在未解除平台错配的候选数（只作观察）|")
        A("")
        A("> 四个 `*_evidence` 是**「候选 × 项目」条数**，同一条可同时具备多种证据；"
          "所有 matched_project 都必须至少带 1 类直接证据。"
          "**准确率优先于 coverage：matched_projects 下降完全可以接受。**")
    else:
        A("（本次数据未携带 project_match_quality —— 需重跑 `scripts/analyze.py`）")
    A("")
    A("> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` "
      "这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。")
    A("")

    # 二、Top
    A(f"## 二、Personalized Top（target_limit {target_limit} · 实际 {len(top)}）")
    A("")
    A("选取规则（与日报完全一致，复用同一函数 `select_top`）："
      f"① score ≥ **{min_top_score}**（配置化最低阈值）② 有真实个性化证据"
      "（matched need / capability gap / update / replacement 至少一个成立）"
      "③ T3/discovery_only 需有 T1·T2·官方交叉佐证 "
      "④ **无未解除的平台错配**（v2.4 §九：项目档案里没有任何项目用该平台 → 不进 Top）"
      "⑤ recommendation ≥ watch ⑥ 分数；"
      "多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。")
    A("")
    A("> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；"
      f"符合标准的不足 {target_limit} 个时就输出实际数量，**不为凑数塞垃圾**。")
    A("")
    A(f"> 本轮被三道质量门挡下的：低分（< {min_top_score}）若干 / "
      f"无个性化证据若干 / T3 无交叉佐证 **{len(t3_unc)}** 条（仍留在 WATCHLIST）。"
      f"跨仓同功能族折叠 **{functional_dupes}** 条（见 2.1）。")
    A("")
    A("「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；")
    A("`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。")
    A("`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。")
    A("")
    A("| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |")
    A("|---|---|---|---|---|---|---|---|---|")
    for i, c in enumerate(top, 1):
        gm = c.get("capability_gap_match") or {}
        sec = c["security"]
        st = f"{sec.get('verdict')}"
        A(f"| {i} | {c['score']:.1f} | {c['recommendation']} | `{c['canonical_key']}` | "
          f"{'T' + str(c['source_tier']) if c.get('source_tier') is not None else 'T—(unverified)'} "
          f"{c.get('source', '—')} | "
          f"{fmt_needs(c.get('project_match'))} | {fmt_projects(c.get('project_match'))} | "
          f"{gm.get('gap_level', '—')} | {st} |")
    A("")
    if top:
        repo_dist = collections.Counter(f"{c['owner']}/{c['repo']}" for c in top)
        multi = "、".join(f"`{k}`×{v}" for k, v in repo_dist.most_common() if v > 1)
        A(f"仓库分布：{len(repo_dist)} 个仓库承载 {len(top)} 条"
          + (f" → {multi}" if multi else "") + "。")
        A("")

    # 二·1、功能簇 ALTERNATIVES（§三/§八）
    A(f"### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（{len(top_alts)} 个功能族有备选）")
    A("")
    A("候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；"
      "但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。")
    A("判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ "
      "description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。")
    A("备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。")
    A("")
    if top_alts:
        A("| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |")
        A("|---|---|---|")
        for pk, dups in list(top_alts.items())[:20]:
            names = "；".join(
                f"`{d['canonical_key']}`（{d.get('score', '—')}）" for d in dups[:4])
            reasons = "；".join(sorted({str(d.get("reason", "—")) for d in dups}))
            A(f"| `{pk}` | {names} | {reasons} |")
    else:
        A("（无：本轮 Top 内没有跨仓同功能族重复）")
    A("")

    # 三、安全清单
    A(f"## 三、安全清单（Security Gate v2.4 · 沿用 v2.2 语境判定）")
    A("")
    A("核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。"
      "每条 finding 带 `confidence` 与 `behavior_context`"
      "（mention / instruction / executable / remote_execution / **warning**），verdict 四值 "
      "`pass / review_required / block / unscanned`。")
    A("")
    A("> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。"
      "`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；"
      "`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / "
      "安全审计文档举反例）一律降为 `review_required`。")
    A("")
    A(f"总体：pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)}")
    A("")
    A(f"### 3.1 block 级阻断（reject，{len(blocked)} 条）")
    A("")
    A("仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、"
      "`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。"
      "警示/反例语境不在此列。")
    A("")
    if blocked:
        A("| canonical_key | 来源 | 阻断规则 | 证据 |")
        A("|---|---|---|---|")
        for x in blocked[:40]:
            ev = ""
            for f in x["security"]["findings"]:
                if f.get("level") == "block":
                    ev = (f.get("evidence") or "")[:70]
                    break
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{','.join(x['security'].get('blocking_rules') or [])} | `{ev}` |")
    else:
        A("（无）")
    A("")
    A(f"### 3.2 review_required 需人工复核（{len(review)} 条；其中 {len(review_ctx)} 条被挡在安装候选之外）")
    A("")
    A("口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— "
      "一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable "
      "的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；"
      "`warning` 语境（安全文档举反例）不挡安装、也不 block。")
    A("")
    if review:
        A("| canonical_key | 来源 | 是否挡安装 | 命中规则 |")
        A("|---|---|---|---|")
        for x in (review_ctx + review_mention)[:40]:
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{'是' if x['security'].get('install_blocked') else '否（语境性提及）'} | "
              f"{rules_of(x['security'])} |")
    else:
        A("（无）")
    A("")
    A(f"### 3.3 install 候选的两阶段审查（PASS 2）")
    A("")
    A("带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行："
      "进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 "
      "`.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。"
      "**只做静态读取，绝不执行脚本。**")
    A("")
    A(f"深度审查状态分布：complete {deep.get('complete',0)} / failed {deep.get('failed',0)}"
      f" / pending {deep.get('pending',0)} / not_required {deep.get('not_required',0)}"
      f" / skipped {deep.get('skipped',0)}；"
      f"`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。")
    A("")

    # 四、更新候选
    A(f"## 四、更新候选（update_available，{len(upd)} 条）")
    A("")
    if upd:
        A("| canonical_key | 外部最新 | 上游活跃度 | 说明 |")
        A("|---|---|---|---|")
        for x in upd:
            A(f"| `{x['canonical_key']}` | {x.get('latest_version') or '—'} | "
              f"{x.get('upstream_activity') or '—'} | {(x.get('update_note') or '')[:70]} |")
    else:
        A("（无）")
    A("")
    if repl:
        A(f"### 4.1 恢复/替换候选（replacement_candidate，{len(repl)} 条）")
        A("")
        A("判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，"
          "coverage=strong / availability=degraded），"
          "或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**")
        A("")
        A("| canonical_key | 说明 |")
        A("|---|---|")
        for x in repl:
            A(f"| `{x['canonical_key']}` | {(x.get('recommendation_reason') or '')[:90]} |")
        A("")

    # 五、本轮整改记录
    A("## 五、v2.4 修掉的问题（项目相关性最终收口）")
    A("")
    A("v2.3 的架构、来源层、安全 Gate、Top 质量门、功能族折叠、归档自定位**全部保持**；"
      "本轮只修最后一类问题：**「规则形式上有 direct evidence，但真实语义仍是假相关。」**")
    A("")
    A("| # | 问题 | v2.3 表现 | v2.4 处置 |")
    A("|---|---|---|---|")
    A("| 1 | 技术栈命中天然等于「直接项目证据」 | `azure-microsoft-playwright-testing-ts` "
      "仅因描述里有 TypeScript，就匹配 party-night / personal-rss / protein-calculator / "
      "stretch-routine / prompt-manager 五个普通 TS 项目 | 把技术栈证据拆成 "
      "**STRONG / SECONDARY** 两级：专用技术栈（Expo / RN / Android / Supabase / Next.js / "
      "PWA / Vercel / .NET / Playwright / macOS 桌面…）可**独立**成立；泛用技术栈"
      "（TypeScript / JavaScript / Python / React / Docker / Shell / HTML / CSS / 自托管…）"
      "只加 `SECONDARY_BOOST`，**绝不单独成立**。直接证据首项由 `tech_stack` 改名 "
      "`strong_tech`；并加不变式守卫：strong 技术栈的权重必须够独立过 `min_score` |")
    A("| 2 | Docker 词典含裸 `container` | `container queries` 被当成 Docker → "
      "`responsive-design` 匹配 personal-rss / family-insurance-dashboard / hongli-dixin-calc；"
      "`orca-per-workspace-env` 也被牵连 | Docker 只认容器化语境词（docker / dockerfile / "
      "docker compose / containerization / container image / container runtime / "
      "docker container / 容器化），**删掉裸 `container`** |")
    A("| 3 | 词面重叠凭单个泛词成立 | Azure Resource Manager Skill 与 `prompt-manager` 只共有 "
      "`manager`，就产出「项目定位与候选描述词面直接重叠：manager」 | 大幅扩展泛词 stop list"
      "（manager / management / resource / service(s) / application(s) / system(s) / "
      "development / developer / testing / test(s) / data / model(s) / client / server / api(s)…）；"
      "词面证据改为「**≥2 个非 stop 的高区分度词**」或「**1 个项目域高信号词**」"
      "（prompt / insurance / rss / transcription / playwright / supabase / obsidian / "
      "valuation / dividend…）；单泛词一律不成立，并计入 `lexical_single_rejected` |")
    A("| 4 | 关键词落进否定语境仍算正向证据 | `azure-resource-manager-playwright-dotnet` 明写 "
      "`NOT for running Playwright tests`，却因出现 Playwright 被判 `browser-qa`；"
      "管理面 / 资源编排语境（management plane / control plane / resource manager / "
      "name availability / workspace quota）同样被误判 | 新增**通用否定窗口**（不是给 "
      "Playwright 打补丁）：按小句切分后丢弃含 `not / never / don't / does not / avoid / "
      "without / not intended / 非用于 / 不用于 / 不支持` 等否定标记的小句，只在**正向视图**"
      "判定命中；Skill 名不受描述否定影响。被压制且原本会命中的记入 "
      "`negated_evidence_rejected` |")
    A("| 5 | `deploy` 仍被 cloud-hosted / CI-CD 命中 | `azure-microsoft-playwright-testing-ts` "
      "写的是 `cloud-hosted browsers` 与 CI/CD 集成，也被判 deploy —— 这不是「部署用户项目」 | "
      "从 deploy 正向 `any_of` 删掉裸 `hosted`；`hosting / hosted / publish / publishing` "
      "必须与**部署对象**（app / application / site / service / pages / build / artifact / "
      "production / environment…）同现才成立；CI/CD 只作 context，不是正向动作 |")
    A("| 6 | `testing_qa` 被偶然的 test / QA 污染 | `ai-prompt-engineering-safety-review` 只是"
      "提到 `testing methodologies`、`ai-team-orchestration` 只是 `optional QA`、"
      "`orca-per-workspace-env` 核心是环境 recipe，却都被打上 testing_qa，"
      "白拿 weak gap 的 15 分加成、人为推高排名 | testing_qa 改成**主能力证据**二选一："
      "A. Skill 名本身含 test / testing / qa / e2e / playwright / pytest / vitest / jest…；"
      "B. 描述把测试当**核心任务**（run tests / write tests / test application / QA workflow / "
      "acceptance testing / regression testing / validate behavior / test suite / e2e tests / "
      "browser testing…）。`testing methodologies` / `optional QA` / `may be tested` / "
      "`QA is optional` / `examples include testing` 只算**提及**，不算能力 |")
    A("| 7 | `domain_mismatch` 只记录、不影响排序 | Azure Playwright Testing / Azure Resource "
      "Manager Playwright .NET / SageMaker deployment planner 虽已标 `domain_mismatch = "
      "azure / dotnet / aws`，仍能占高位 Top | 未解除的错配 → **不得 install_candidate、"
      "不得进 Personalized Top、总分 ×0.7 penalty**，默认进 watchlist；`select_top` 增加第四道门。"
      "解除条件 = **用户真实项目明确使用该平台**（Azure / AWS / .NET…），解除后自动走正常路径 ——"
      "**不做永久 blacklist**，只是「当前没有证据使用该技术栈 → 不该占个人 Top」|")
    A("| 8 | 精度指标只能证明「字段不为空」 | `351/351 direct evidence` 说明不了证据是否有效 | "
      "改为 **PROJECT_MATCH_QUALITY**：分别统计 strong_tech / positioning / shared_need / "
      "lexical 四类证据条数，以及 `secondary_tech_only_rejected` / "
      "`negated_evidence_rejected` / `lexical_single_rejected` 三个「被拒」计数。"
      "**准确率优先于 coverage，matched_projects 下降完全可以接受** |")
    A("")
    A("### 5.1 附带修掉的两个「规则看起来对、实际不生效」缺陷")
    A("")
    A("v2.4 排查中发现并修掉 —— 二者都属于「写在配置里也测不出来」的类型，"
      "且会让 §五 的中文否定标记形同虚设：")
    A("")
    A("| # | 缺陷 | 后果 | 处置 |")
    A("|---|---|---|---|")
    A("| A | 中文关键词命中率恒为 0 | `_WORD_RE` 是纯 ASCII（`[a-z0-9]…`），中文没有词边界，"
      "整词匹配下规则表里 **48 个 NEED_RULE + 27 个 CAP_RULE 中文关键词**，"
      "加上 TECH_MATCH 的 `容器化` / `菜单栏应用`，**全部是永不命中的死词** | "
      "含 CJK 的关键词改走子串匹配；回归测试对规则表做**全量自检**"
      "（中文关键词不得再有死词），同时保留英文整词匹配（`ui` 命中 build 的老事故不许回归）|")
    A("| B | 分句不含逗号 → 否定窗口过度压制 | 「非用于 A，可用于 B」整句被丢弃，"
      "把逗号后的**正向证据**一起误杀 | 逗号（`,` / `，`）纳入分句边界，否定只作用于本小句；"
      "修掉后 `negated_evidence_rejected` 由 **94 降到 30**，即减少了 64 处「假压制」|")
    A("")
    A("### 5.2 v2.3 已验收通过、本轮**不重做**（§十二）")
    A("")
    A("17 source registry · T0/T1/T2/T3 分层 · bottom-up 非 Skill 隔离 · ClawHub 构建产物过滤 · "
      "mobile_qa 误报修复 · supabase-db 普通 PostgreSQL 误报修复 · llm-api 广告 API 误报修复 · "
      "voice-input 误报修复 · Security warning vs 真执行区分 · deep scan 安装候选 Gate · "
      "Top 不含 ignore/reject · Top 不凑 30 · T3 无佐证不进 Top · functional family / "
      "alternatives · source official 口径统一 · 测试 PASS/SKIP/FAIL 三分 · "
      "包内 SKILL_CONTEXT 自定位。")
    A("")
    A(f"本轮结果：Top 实际 **{len(top)}/{target_limit}**，跨仓同功能族折叠 "
      f"**{functional_dupes}** 条，Top 内未解除平台错配 **0** 条。")
    A("")

    # 六、复现
    A("## 六、如何复现／核对")
    A("")
    A("```bash")
    A("# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）")
    A("python3 scripts/run_daily.py")
    A("# 只重算候选池")
    A("python3 scripts/analyze.py")
    A("# 重新生成本对照件")
    A("python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md")
    A("# 离线测试（35 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）")
    A("python3 tests/test_pipeline.py")
    A("```")
    A("")
    A("**依赖的输入（缺一不可）**：")
    A("")
    A("| 输入 | 解析优先序（v2.3 §九 / v2.4 §十二 保持） | 作用 |")
    A("|---|---|---|")
    A("| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → "
      "② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | "
      "决定 PROJECT_MATCH / 相关性否决 / matched_projects |")
    A("| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | "
      "① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → "
      "③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 "
      "`capability_gap_match` |")
    A("| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |")
    A("")
    A("**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，"
      "未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。"
      "命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：")
    A("")
    A("```bash")
    A("SKILL_REPO_ROOT=/path/to/仓库 \\")
    A("SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \\")
    A("SKILL_DATA_DIR=/path/to/data \\")
    A("python3 scripts/run_daily.py")
    A("```")
    A("")
    A("可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR`"
      " / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。"
      "换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。")
    A("")
    A(f"> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— "
      f"本件生成时输入 A {_path_report('skill_context', SKILL_CONTEXT_PATH)}。")
    A("")
    A("> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；"
      "对照件其余内容在不同环境下应当逐位一致。")
    A("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default="-", help="输出文件；默认 stdout")
    a = ap.parse_args()
    md = build()
    if a.out == "-":
        print(md)
    else:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"written: {a.out} ({len(md.encode('utf-8'))} B)")


if __name__ == "__main__":
    main()
