# 候选池精简对照件（External Skill Intelligence v2.5）

> 数据基线：2026-09-23｜源文件 `SKILL_CANDIDATES.json`（1106 条）
> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。
> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；排名/安装量只是 adoption signal，不等于推荐。

## 一、总览

| 项目 | 数值 |
|---|---|
| 来源注册表 | 17 源（T0 2 / T1 9 / T2 3 / T3 3）|
| 候选（raw → 合法池） | 1170 → 1106 |
| 数据质量 Gate | 剔除构建产物 67 条 / 非法 skill 名 1 条 |
| bottom-up 硬门 | 共 41 条搜索结果 → 过 SKILL.md 硬门 17 / 隔离 23 |
| 推荐分布 | ignore 596 / install_candidate 15 / reject 3 / watch 492 |
| 与已装关系 | already_installed 14 / complement 48 / new_capability 1022 / overlap 19 / replacement_candidate 3 |
| 安全风险 | high 3 / low 395 / medium 202 / unknown 506（已静态审查 600）|
| 安全 verdict | pass 395 / review_required 202 / block 3 / unscanned 506 |
| 深度静态审查 | complete 15（= install 候选） / failed 0 / pending 0 / not_required 585 / skipped 506 |
| 能力缺口 | none 8 / strong 1009 / weak 89 |
| 命中项目需求 / 平台错配 | 178 / 315 |
| matched_projects 覆盖（高匹配候选） | 18/112 (16%) —— **v2.3 起不再是 KPI**，只作参考 |
| matched_project 直接证据完整性 | 122/122 —— 每条匹配都必须带 1 类直接证据（完整性自检，**不是**质量 KPI）|
| update_available / replacement_candidate | 2 / 3 |

> **v2.4 §十：`direct evidence` 的「字段非空率」不再作为精度指标。**
> 字段非空只能证明写了；能不能证明「证据真的有效」，要看下面的分项计数：

| PROJECT_MATCH_QUALITY | 数值 | 含义 |
|---|---|---|
| matched_candidates | 66 | 至少有一个 matched_project 的候选数 |
| strong_tech_evidence | 103 | 专用技术栈直接命中（Expo / RN / Android / Supabase / Next.js / PWA / Vercel / .NET…）|
| positioning_evidence | 12 | 项目定位/功能语义命中 |
| shared_need_evidence | 20 | 项目自身需求与候选能力命中 |
| lexical_evidence | 1 | 词面证据（v2.5：独立成立仅限**领域短语**；词级重叠只作次要加分，泛词与裸 prompt 全禁）|
| **secondary_tech_only_rejected** | 106 | **只**靠泛用技术栈（TS / React / Python / Docker…）硬凑、已被拒的候选数 |
| **negated_evidence_rejected** | 118 | 被否定窗口 / 排除语境压掉的命中次数（看得见门在工作）|
| lexical_single_rejected | 943 | 词面重叠只因单个低区分度词（manager / service…）而不足以成立的次数 |
| lexical_alone_rejected | 1 | v2.5 §三：词面 boost 想**独立**造匹配、被拒的次数（词面只作次要加分）|
| lexical_phrase_direct_evidence | 1 | v2.5 §五：靠人工整理的领域短语独立成立的词面直接证据条数 |
| **bare_prompt_direct_evidence** | 0 | v2.5 §四：裸 prompt 被当直接证据的次数 —— **必须为 0** |
| **tech_words_used_as_lexical_direct_evidence** | 0 | v2.5 §四：泛用技术词（react / native / typescript / api…）充当词面直接证据的次数 —— **必须为 0** |
| unresolved_mismatch_candidates | 315 | 存在未解除平台错配的候选数（只作观察）|

> 四个 `*_evidence` 是**「候选 × 项目」条数**，同一条可同时具备多种证据；所有 matched_project 都必须至少带 1 类直接证据。**准确率优先于 coverage：matched_projects 下降完全可以接受。**

> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` 这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。

## 二、Personalized Top（target_limit 30 · 实际 19）

选取规则（与日报完全一致，复用同一函数 `select_top`）：① score ≥ **55**（配置化最低阈值）② 有真实个性化证据（matched need / capability gap / update / replacement 至少一个成立）③ T3/discovery_only 需有 T1·T2·官方交叉佐证 ④ **无未解除的平台错配**（v2.4 §九：项目档案里没有任何项目用该平台 → 不进 Top）⑤ recommendation ≥ watch ⑥ 分数；多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。

> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；符合标准的不足 30 个时就输出实际数量，**不为凑数塞垃圾**。

> 本轮被三道质量门挡下的：低分（< 55）若干 / 无个性化证据若干 / T3 无交叉佐证 **23** 条（仍留在 WATCHLIST）。跨仓同功能族折叠 **1** 条（见 2.1）。

「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；
`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。
`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。

| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |
|---|---|---|---|---|---|---|---|---|
| 1 | 79.4 | install_candidate | `stablyai/orca/orca-emulator-android` | T1 stablyai/orca | android | landedazi-android(50) | none | pass |
| 2 | 71.8 | watch | `github/awesome-copilot/web-design-reviewer` | T1 github/awesome-copilot | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 3 | 65.8 | watch | `wshobson/agents/tailwind-design-system` | T2 wshobson/agents | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 4 | 65.8 | watch | `wshobson/agents/responsive-design` | T2 wshobson/agents | frontend-design, responsive | a-share-index-valuation-report(32) | strong | pass |
| 5 | 58.8 | watch | `vercel-labs/agent-skills/react-native-skills` | T1 vercel-labs/agent-skills | expo-rn | stretch-side-timer-project(96)；protein-calculator(84) | strong | pass |
| 6 | 85.0 | install_candidate | `github/awesome-copilot/webapp-testing` | T1 github/awesome-copilot | frontend-design, browser-qa | — | weak | pass |
| 7 | 81.0 | install_candidate | `github/awesome-copilot/msstore-cli` | T1 github/awesome-copilot | deploy, secret-safety | — | weak | pass |
| 8 | 79.0 | install_candidate | `wshobson/agents/e2e-testing-patterns` | T2 wshobson/agents | deploy, browser-qa | — | weak | pass |
| 9 | 71.3 | install_candidate | `browseros-ai/browseros/test-ui` | T1 browseros-ai/BrowserOS | browser-qa | — | weak | review_required |
| 10 | 71.0 | watch | `vercel-labs/agent-skills/vercel-cli-with-tokens` | T1 vercel-labs/agent-skills | deploy, secret-safety | — | strong | review_required |
| 11 | 68.6 | watch | `google/skills/agent-platform-endpoint-management` | T1 google/skills | deploy | — | strong | pass |
| 12 | 68.5 | watch | `microsoft/skills/frontend-ui-dark-ts` | T1 microsoft/skills | frontend-design | — | strong | pass |
| 13 | 68.5 | watch | `microsoft/skills/frontend-design-review` | T1 microsoft/skills | frontend-design | — | strong | pass |
| 14 | 68.5 | watch | `anthropics/skills/canvas-design` | T1 anthropics/skills | frontend-design | — | strong | pass |
| 15 | 68.5 | watch | `vercel-labs/agent-skills/react-view-transitions` | T1 vercel-labs/agent-skills | frontend-design | — | strong | pass |
| 16 | 60.6 | watch | `google/skills/agent-platform-deploy` | T1 google/skills | deploy | — | strong | review_required |
| 17 | 60.6 | watch | `google/skills/cloud-run-basics` | T1 google/skills | deploy | — | strong | review_required |
| 18 | 60.5 | watch | `anthropics/skills/web-artifacts-builder` | T1 anthropics/skills | frontend-design | — | strong | review_required |
| 19 | 56.6 | watch | `microsoft/skills/deploy` | T1 microsoft/skills | deploy | — | strong | review_required |

仓库分布：8 个仓库承载 19 条 → `github/awesome-copilot`×3、`wshobson/agents`×3、`vercel-labs/agent-skills`×3、`google/skills`×3、`microsoft/skills`×3、`anthropics/skills`×2。

### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（1 个功能族有备选）

候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。
判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。
备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。

| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |
|---|---|---|
| `github/awesome-copilot/webapp-testing` | `anthropics/skills/webapp-testing`（84） | 同名同功能 |

## 三、安全清单（Security Gate v2.4 · 沿用 v2.2 语境判定）

核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。每条 finding 带 `confidence` 与 `behavior_context`（mention / instruction / executable / remote_execution / **warning**），verdict 四值 `pass / review_required / block / unscanned`。

> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / 安全审计文档举反例）一律降为 `review_required`。

总体：pass 395 / review_required 202 / block 3 / unscanned 506

### 3.1 block 级阻断（reject，3 条）

仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。警示/反例语境不在此列。

| canonical_key | 来源 | 阻断规则 | 证据 |
|---|---|---|---|
| `github/awesome-copilot/aspire` | T1 | pipe_to_shell | `curl -sSL https://aspire.dev/install.sh | bash` |
| `github/awesome-copilot/azure-container-registry-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |
| `github/awesome-copilot/azure-devops-cli` | T1 | pipe_to_shell | `curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash` |

### 3.2 review_required 需人工复核（202 条；其中 0 条被挡在安装候选之外）

口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— 一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable 的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；`warning` 语境（安全文档举反例）不挡安装、也不 block。

| canonical_key | 来源 | 是否挡安装 | 命中规则 |
|---|---|---|---|
| `anthropics/skills/claude-api` | T1 | 否（语境性提及） | credential_files,network_generic |
| `anthropics/skills/docx` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/mcp-builder` | T1 | 否（语境性提及） | network_generic |
| `anthropics/skills/webapp-testing` | T1 | 否（语境性提及） | bundled_scripts |
| `anthropics/skills/xlsx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/agent-governance` | T1 | 否（语境性提及） | network_generic,sudo |
| `github/awesome-copilot/agent-owasp-compliance` | T1 | 否（语境性提及） | dynamic_code |
| `github/awesome-copilot/containerize-aspnet-framework` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/containerize-aspnetcore` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/convert-excel-to-md` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/flowstudio-power-automate-mcp` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/github-actions-hardening` | T1 | 否（语境性提及） | credential_files |
| `github/awesome-copilot/github-issues` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/mcp-create-declarative-agent` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/mcp-implementation-security-review` | T1 | 否（语境性提及） | credential_files,dynamic_code,network_generic,postinstall_hook |
| `github/awesome-copilot/mcp-security-audit` | T1 | 否（语境性提及） | credential_files,network_generic |
| `github/awesome-copilot/md-to-docx` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/pr-dashboard` | T1 | 否（语境性提及） | bundled_scripts |
| `github/awesome-copilot/publish-to-pages` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `github/awesome-copilot/scoutqa-test` | T1 | 否（语境性提及） | network_generic |
| `github/awesome-copilot/secret-scanning` | T1 | 否（语境性提及） | git_push_auto |
| `github/awesome-copilot/test-gap-audit` | T1 | 否（语境性提及） | bundled_scripts |
| `vercel-labs/agent-skills/deploy-to-vercel` | T1 | 否（语境性提及） | credential_files,git_push_auto,network_generic |
| `vercel-labs/agent-skills/web-design-guidelines` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-ads-api-mcp-setup` | T1 | 否（语境性提及） | network_generic,sudo |
| `google/skills/agent-platform-deploy` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `google/skills/cloud-monitoring-chart-generation` | T1 | 否（语境性提及） | bundled_scripts |
| `google/skills/gemini-agents-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-api` | T1 | 否（语境性提及） | credential_files |
| `google/skills/gemini-interactions-api` | T1 | 否（语境性提及） | network_generic |
| `google/skills/gemini-live-api` | T1 | 否（语境性提及） | sudo |
| `google/skills/google-cloud-global-frontend-configuration` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-cloud-solution-agentic-analytics-spark-knowledge-catalog` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-cloud-solution-build-deploy-agents` | T1 | 否（语境性提及） | network_generic |
| `google/skills/google-cloud-solution-multi-agent-security` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `browseros-ai/browseros/test-ui` | T1 | 否（语境性提及） | bundled_scripts,network_generic |
| `huggingface/skills/hf-mcp` | T1 | 否（语境性提及） | network_generic |
| `microsoft/skills/azure-speech-to-text-rest-py` | T1 | 否（语境性提及） | credential_files |
| `microsoft/skills/azure-keyvault-secrets-ts` | T1 | 否（语境性提及） | credential_files |
| `microsoft/skills/deploy` | T1 | 否（语境性提及） | credential_files |

### 3.3 install 候选的两阶段审查（PASS 2）

带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行：进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 `.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。**只做静态读取，绝不执行脚本。**

深度审查状态分布：complete 15 / failed 0 / pending 0 / not_required 585 / skipped 506；`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。

## 四、更新候选（update_available，2 条）

| canonical_key | 外部最新 | 上游活跃度 | 说明 |
|---|---|---|---|
| `browseros-ai/browseros/browseros-neo` | — | active | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |
| `kkkkhazix/khazix-skills/aihot` | — | unknown | 已装但 version_status=outdated_version（上游 active）→ 属更新候选，不重复推荐安装，仅在 UPDAT |

### 4.1 恢复/替换候选（replacement_candidate，3 条）

判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，coverage=strong / availability=degraded），或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**

| canonical_key | 说明 |
|---|---|
| `stablyai/orca/computer-use` | 中分 52.0：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orca-cli` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |
| `stablyai/orca/orchestration` | 中分 48：值得关注，需人工判断（未命中项目需求；仅作观察） |

## 五、v2.5 修掉的问题（冻结前最后语义收口）

v2.4 的架构、来源层、安全 Gate、Top 质量门、直接证据分级、否定窗口、功能族折叠、归档自定位**全部保持**；本轮只修**剩余语义误判**（android 需求证据 / 否定逗号枚举 / 词面证据 / mcp_dev / docx_xlsx / github-auto / 证据语境四态），不重做已验收机制。

| # | 问题 | v2.4 表现 | v2.5 处置 |
|---|---|---|---|
| 1 | android 需求被裸 device / build / install / launch 命中 | `google-mobile-ads-get-started` / `-validate` 只是「在 Android 应用里集成广告 SDK」，因 install / device 等词被记成 Android QA 需求（w=27） | android = 平台证据 AND **真实 QA 证据**：A 表（qa / test / e2e / adb / emulator / real device / device farm / appium / detox / maestro / espresso / xctest / instrumentation / 真机 / 自动化测试）或 B 表（signing / keystore / signed apk / apk / aab / app bundle / build verification / release build verification / 签名 / 构建验收）；裸 device / build / install / launch **禁止**作正向证据。反向回归：`orca-emulator-android` 必须仍然命中 android + mobile_qa（adb / emulator 是真证据）|
| 2 | 否定窗口在逗号枚举处把 B、C 洗回正向 | v2.4 把逗号当分句边界，`Don't use for A, B, or C.` 只有 A 被否，B / C 复活 —— `agent-platform-prompt-management` 明写不用于部署仍误命中 deploy（w=38）；`agent-platform-tuning` 同误判 | 两段式：**大句**只按 句号（需跟空白/行尾，保住 next.js / .net / node.js）/ 分号 / 换行 / 句读 切分；**逗号只在段内传播否定状态**；遇到显式对比词（but / however / instead / whereas / use for / can be used for / 但是 / 但 / 不过 / 而是 / 可用于 / 可以用于 / 适用于）才恢复正向。`Not for A, but use for B.` 与 `非用于 A、B、C，但可用于部署上线` 必须照常恢复 |
| 3 | 词面证据凭泛用技术词或裸 prompt 独立成立 | `react-view-transitions` 因 react / native 匹配 `yejian-buguangdeng`；`claude-api` 与 `breakdown-test` 因裸 `prompt` 匹配 `prompt-manager` | 泛用技术词（react / native / javascript / typescript / python / css / html / tailwind / next / nextjs / android / kotlin / expo / mobile / web / api / sdk / model / cloud…）从词面证据**全禁**；`prompt` 移出高信号词。词面独立成立只认**人工整理的领域短语**（prompt management / managed prompts / prompt library / prompt versioning / 提示词管理…）；普通词面重叠降级为**次要加分**（须与 strong_tech / positioning / shared_need 同现），单独造匹配计入 `lexical_alone_rejected` |
| 4 | 精度自检只能证明「字段非空」 | 无法回答「裸 prompt / 技术词是否又混进来了」 | 新增三个显式计数：`lexical_phrase_direct_evidence`（短语独立成立次数）、**`bare_prompt_direct_evidence` 恒为 0**、**`tech_words_used_as_lexical_direct_evidence` 恒为 0**（非 0 即回归失败）|
| 5 | 提到 MCP ≠ 具备 MCP 开发能力 | `claude-api` 描述里「支持与 MCP 配合」被打上 mcp_dev 标签、吃缺口分 | mcp_dev 需**核心开发证据**：build / create / develop / implement / write / set up … MCP（server / tool / client / Model Context Protocol implementation）/ MCP SDK / 编写 MCP / MCP 服务开发，或 Skill 名含 mcp-server / mcp-development / mcp-builder。「支持 MCP / 可与 MCP 使用 / 文档包含 MCP」只算 mention；`claude-api` 失去 mcp_dev、保留 llm-api；真实 MCP builder 不受影响 |
| 6 | PPTX 冒充 docx_xlsx | `publish-to-pages` 生成 PPTX / PDF / HTML，却被记成 docx_xlsx 能力、拿文档缺口分 | docx_xlsx 只认 docx / xlsx / Word / Excel / spreadsheet / 明确的 office document / 上下文中的文档处理·表格处理；PPTX / PowerPoint 单列 `pptx_processing` 标签，**不得**伪造 docx_xlsx |
| 7 | 裸 `github` 命中 github-auto | `breakdown-test` 只因引用 GitHub 仓库语境就被记成 github-auto 需求（且顺带带出错误的词面项目匹配） | github-auto = GitHub 平台词 AND 运维语义词（GitHub Actions / gh CLI / repository automation / issue creation / pull request automation / PR review / release automation / labels / milestones / workflow dispatch / repository sync / commit automation / GitHub API / 自动建 issue / 自动 PR / 仓库同步…）|
| 8 | 「顺带提及」与「核心能力」在评分层无统一口径 | mcp_dev / docx_xlsx / github-auto / android / deploy 各自为政，修一处漏一处 | 统一字段 `capability_evidence_context` ∈ {primary, supporting, mention, negated}：只有 primary 拿满 capability gap 分；supporting 上限 8；mention / negated 上限 2；需求侧 supporting 权重 ×0.5。以后新增误报按四态归类修，**不再手写候选黑名单** |

### 5.1 v2.4 附带修掉的两个「规则看起来对、实际不生效」缺陷（保留，v2.5 仍生效）

v2.4 排查中发现并修掉 —— 二者都属于「写在配置里也测不出来」的类型，且会让 §五 的中文否定标记形同虚设：

| # | 缺陷 | 后果 | 处置 |
|---|---|---|---|
| A | 中文关键词命中率恒为 0 | `_WORD_RE` 是纯 ASCII（`[a-z0-9]…`），中文没有词边界，整词匹配下规则表里 **48 个 NEED_RULE + 27 个 CAP_RULE 中文关键词**，加上 TECH_MATCH 的 `容器化` / `菜单栏应用`，**全部是永不命中的死词** | 含 CJK 的关键词改走子串匹配；回归测试对规则表做**全量自检**（中文关键词不得再有死词），同时保留英文整词匹配（`ui` 命中 build 的老事故不许回归）|
| B | 分句不含逗号 → 否定窗口过度压制 | 「非用于 A，可用于 B」整句被丢弃，把逗号后的**正向证据**一起误杀 | 逗号（`,` / `，`）纳入分句边界，否定只作用于本小句；修掉后 `negated_evidence_rejected` 由 **94 降到 30**，即减少了 64 处「假压制」|

### 5.2 v2.4 已验收通过、本轮**不重做**（§十二）

strong / secondary 技术栈分级与 `strong_tech` 直接证据 · Docker 词典删裸 `container` · 词面 stop list 与 `lexical_single_rejected` · 通用否定窗口（逗号语义在 v2.5 §五.2 收紧，窗口本体保留）· deploy 的 hosted+部署对象同现 · testing_qa 主能力证据 · 未解除 domain_mismatch 四道门（×0.7 / 不 install / 不进 Top）· PROJECT_MATCH_QUALITY 分项计数 · CJK 死词全量自检 · 17 source registry · T0/T1/T2/T3 分层 · bottom-up 非 Skill 隔离 · ClawHub 构建产物过滤 · mobile_qa / supabase-db / llm-api / voice-input 误报修复 · Security warning vs 真执行区分 · deep scan 安装候选 Gate · Top 不含 ignore/reject · Top 不凑 30 · T3 无佐证不进 Top · functional family / alternatives · source official 口径统一 · 测试 PASS/SKIP/FAIL 三分 · 包内 SKILL_CONTEXT 自定位。

本轮 §十一 重审（实际数据核对）：三处禁选项目匹配出现 **0** 处（应为 0）；`google-mobile-ads-get-started` / `agent-platform-prompt-management` 因错误规则占用 Top **0** 处（应为 0）；Top 内未解除平台错配 **0** 条（应为 0）。

本轮结果：Top 实际 **19/30**，跨仓同功能族折叠 **1** 条。

## 六、如何复现／核对

```bash
# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）
python3 scripts/run_daily.py
# 只重算候选池
python3 scripts/analyze.py
# 重新生成本对照件
python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md
# 离线测试（43 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）
python3 tests/test_pipeline.py
```

**依赖的输入（缺一不可）**：

| 输入 | 解析优先序（v2.3 §九 / v2.4 §十二 保持） | 作用 |
|---|---|---|
| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → ② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | 决定 PROJECT_MATCH / 相关性否决 / matched_projects |
| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | ① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → ③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 `capability_gap_match` |
| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |

**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：

```bash
SKILL_REPO_ROOT=/path/to/仓库 \
SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \
SKILL_DATA_DIR=/path/to/data \
python3 scripts/run_daily.py
```

可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR` / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。

> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— 本件生成时输入 A local_default → `~/Developer/coding/1.Active/000-alw-github 档案/SKILL_CONTEXT.md`（可读）。

> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；对照件其余内容在不同环境下应当逐位一致。
