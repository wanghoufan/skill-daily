#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""候选池精简对照件生成器（给审查者看的「看得完」视图）。

完整数据是 data/SKILL_CANDIDATES.json；本脚本只抽出几类可核对的切片：
  ① 总览计数（含数据质量 Gate 与安全 verdict 分布）
  ② Personalized Top（实际数量，不含 ignore/reject）+ ALTERNATIVES（跨仓同功能族）
  ③ 安全清单（block 级阻断 / review_required 需人工复核）
  ④ 更新候选与恢复候选
  ⑤ 本轮修掉的问题（整改记录）
  ⑥ 复现与依赖（口径以 v2.5 为准）

Top 的排序与多样性规则**直接复用 build_context 的函数**（`select_top`），不另写一套，
避免「日报里的 Top」与「对照件里的 Top」不一致。

用法：
    python3 scripts/make_digest.py                # 输出到 stdout
    python3 scripts/make_digest.py -o out.md      # 输出到文件
"""
import os
import sys
import json
import argparse
import collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (CANDIDATES_PATH, REGISTRY_PATH, load_config,  # noqa: E402
                    SKILL_CONTEXT_PATH, PATH_RESOLUTION, BASE)
import build_context as bc  # noqa: E402


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _path_source(key):
    """§九：报告某个输入到底走的是哪条解析路径（env / 包内自定位 / 本机默认）。
    `PATH_RESOLUTION` 形如 {"skill_context": "package:/.../支撑/输入/SKILL_CONTEXT.md"}"""
    return (PATH_RESOLUTION or {}).get(key, "未记录")


def _path_report(key, resolved):
    """给审查者看的可核对串：走的是哪条路径 + 最终落到哪个文件。

    注意：这一行**刻意随运行环境变化**（env / 包内自定位 / 本机默认），
    因此不同环境下重生成的对照件在这一行必然不同 —— 其余内容应当逐位一致。
    """
    label = _path_source(key)
    exists = "可读" if os.path.exists(resolved) else "**不可读**"
    shown = resolved
    # 归档包内自定位时，路径前缀因解压位置而异；只保留包内相对部分，便于核对
    if label.startswith("package:"):
        shown = "…/" + os.path.relpath(resolved, BASE)
    elif label == "local_default":
        shown = resolved.replace(os.path.expanduser("~"), "~")
    return f"{label} → `{shown}`（{exists}）"


def fmt_needs(pm):
    ns = (pm or {}).get("matched_needs") or []
    return ", ".join(ns[:3]) if ns else "—"


def fmt_projects(pm, limit=2):
    mps = (pm or {}).get("matched_projects") or []
    if not mps:
        return "—"
    return "；".join(f"{m['project']}({m['match_score']})" for m in mps[:limit])


def rules_of(sec, level=None):
    fs = [f for f in (sec or {}).get("findings", [])
          if level is None or f.get("level") == level]
    return ",".join(sorted({f.get("rule", "?") for f in fs})) or "—"


def build():
    cands_doc = load(CANDIDATES_PATH)
    I = cands_doc["candidates"]
    reg = load(REGISTRY_PATH)
    S = [x for t in reg["tiers"].values() for x in (t if isinstance(t, list) else [])]
    cfg = load_config()
    counts = cands_doc.get("counts", {})
    quarantine = cands_doc.get("quarantine", {})

    rec = collections.Counter(x["recommendation"] for x in I)
    rel = collections.Counter(x["installed_relationship"] for x in I)
    risk = collections.Counter(x["security"]["risk_level"] for x in I)
    verdict = collections.Counter(x["security"].get("verdict") for x in I)
    deep = collections.Counter(x["security"].get("deep_scan_status") for x in I)
    gap = collections.Counter((x.get("capability_gap_match") or {}).get("gap_level") for x in I)
    scanned = sum(1 for x in I if x["security"]["status"] == "scanned")
    # v2.2：分母只取「真有需求证据」的高匹配候选（与 build_context 口径一致）
    hm = [x for x in I if x["recommendation"] in ("install_candidate", "watch")
          and (x.get("project_match") or {}).get("need_evidence")]
    hm_proj = [x for x in hm if (x.get("project_match") or {}).get("matched_projects")]

    # --- Top：复用日报同一套门槛 + 排序 + 多样性/功能族规则 ---
    top_cfg = cfg.get("top_candidates", {})
    target_limit = top_cfg.get("target_limit", 30)
    min_top_score = top_cfg.get("min_score")
    allowed = tuple(top_cfg.get("allowed_recommendations", ["install_candidate", "watch"]))
    pool = [c for c in I
            if c["installed_relationship"] != "already_installed"
            and c["recommendation"] in allowed]
    ranked = sorted(pool, key=bc.rank_candidate)
    corroborated = bc.build_corroborated_repos(reg, I)
    top, top_alts = bc.select_top(ranked, limit=target_limit, min_score=min_top_score,
                                  corroborated_repos=corroborated)
    functional_dupes = sum(len(v) for v in top_alts.values())
    t3_unc = [c for c in ranked if bc.is_t3_uncorroborated(c, corroborated)]
    # §一：项目匹配「直接证据率」——matched_projects 每一条都必须带 direct_evidence
    mp_entries = [m for c in I
                  for m in ((c.get("project_match") or {}).get("matched_projects") or [])]
    mp_direct = [m for m in mp_entries if m.get("direct_evidence")]

    blocked = [x for x in I if x["security"].get("verdict") == "block"]
    review = [x for x in I if x["security"].get("verdict") == "review_required"]
    review_ctx = [x for x in review if x["security"].get("install_blocked")]
    review_mention = [x for x in review if not x["security"].get("install_blocked")]
    upd = [x for x in I if x.get("update_available")]
    repl = [x for x in I if x["installed_relationship"] == "replacement_candidate"]

    L = []
    A = L.append
    A("# 候选池精简对照件（External Skill Intelligence v2.5）")
    A("")
    A(f"> 数据基线：{cands_doc.get('generated')}｜源文件 `SKILL_CANDIDATES.json`（{len(I)} 条）")
    A("> 本件是**给审查者看得完的切片视图**，用于核对；完整数据与全部字段以 JSON 为准。")
    A("> 只做发现与评估：**不安装、不删除、不升级任何 Skill**；"
      "排名/安装量只是 adoption signal，不等于推荐。")
    A("")

    # 一、总览
    A("## 一、总览")
    A("")
    A("| 项目 | 数值 |")
    A("|---|---|")
    A(f"| 来源注册表 | {len(S)} 源（" +
      " / ".join(f"T{k} {v}" for k, v in sorted(collections.Counter(s["tier"] for s in S).items())) + "）|")
    A(f"| 候选（raw → 合法池） | {counts.get('raw_candidates')} → {len(I)} |")
    A(f"| 数据质量 Gate | 剔除构建产物 {counts.get('invalid_artifacts_removed', 0)} 条 / "
      f"非法 skill 名 {counts.get('invalid_names_removed', 0)} 条 |")
    A(f"| bottom-up 硬门 | 共 {counts.get('bottom_up_total', 0)} 条搜索结果 → "
      f"过 SKILL.md 硬门 {counts.get('bottom_up_verified', 0)} / 隔离 {counts.get('bottom_up_quarantined', 0)} |")
    A(f"| 推荐分布 | " + " / ".join(f"{k} {v}" for k, v in sorted(rec.items())) + " |")
    A(f"| 与已装关系 | " + " / ".join(f"{k} {v}" for k, v in sorted(rel.items())) + " |")
    A(f"| 安全风险 | " + " / ".join(f"{k} {v}" for k, v in sorted(risk.items())) +
      f"（已静态审查 {scanned}）|")
    A(f"| 安全 verdict | pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)} |")
    A(f"| 深度静态审查 | complete {deep.get('complete',0)}（= install 候选）"
      f" / failed {deep.get('failed',0)} / pending {deep.get('pending',0)}"
      f" / not_required {deep.get('not_required',0)} / skipped {deep.get('skipped',0)} |")
    A(f"| 能力缺口 | " + " / ".join(f"{k} {v}" for k, v in sorted(gap.items(), key=lambda kv: str(kv[0]))) + " |")
    A(f"| 命中项目需求 / 平台错配 | "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('need_evidence'))} / "
      f"{sum(1 for x in I if (x.get('project_match') or {}).get('domain_mismatch'))} |")
    A(f"| matched_projects 覆盖（高匹配候选） | {len(hm_proj)}/{len(hm)} "
      f"({(len(hm_proj)/max(1,len(hm))):.0%}) —— **v2.3 起不再是 KPI**，只作参考 |")
    A(f"| matched_project 直接证据完整性 | {len(mp_direct)}/{len(mp_entries)} "
      f"—— 每条匹配都必须带 1 类直接证据（完整性自检，**不是**质量 KPI）|")
    A(f"| update_available / replacement_candidate | {len(upd)} / {len(repl)} |")
    A("")
    A("> **v2.4 §十：`direct evidence` 的「字段非空率」不再作为精度指标。**")
    A("> 字段非空只能证明写了；能不能证明「证据真的有效」，要看下面的分项计数：")
    A("")
    pq = cands_doc.get("project_match_quality") or {}
    if pq:
        A("| PROJECT_MATCH_QUALITY | 数值 | 含义 |")
        A("|---|---|---|")
        A(f"| matched_candidates | {pq.get('matched_candidates', 0)} | 至少有一个 matched_project 的候选数 |")
        A(f"| strong_tech_evidence | {pq.get('strong_tech_evidence', 0)} | "
          "专用技术栈直接命中（Expo / RN / Android / Supabase / Next.js / PWA / Vercel / .NET…）|")
        A(f"| positioning_evidence | {pq.get('positioning_evidence', 0)} | 项目定位/功能语义命中 |")
        A(f"| shared_need_evidence | {pq.get('shared_need_evidence', 0)} | 项目自身需求与候选能力命中 |")
        A(f"| lexical_evidence | {pq.get('lexical_evidence', 0)} | "
          "词面证据（v2.5：独立成立仅限**领域短语**；词级重叠只作次要加分，泛词与裸 prompt 全禁）|")
        A(f"| **secondary_tech_only_rejected** | {pq.get('secondary_tech_only_rejected', 0)} | "
          "**只**靠泛用技术栈（TS / React / Python / Docker…）硬凑、已被拒的候选数 |")
        A(f"| **negated_evidence_rejected** | {pq.get('negated_evidence_rejected', 0)} | "
          "被否定窗口 / 排除语境压掉的命中次数（看得见门在工作）|")
        A(f"| lexical_single_rejected | {pq.get('lexical_single_rejected', 0)} | "
          "词面重叠只因单个低区分度词（manager / service…）而不足以成立的次数 |")
        A(f"| lexical_alone_rejected | {pq.get('lexical_alone_rejected', 0)} | "
          "v2.5 §三：词面 boost 想**独立**造匹配、被拒的次数（词面只作次要加分）|")
        A(f"| lexical_phrase_direct_evidence | {pq.get('lexical_phrase_direct_evidence', 0)} | "
          "v2.5 §五：靠人工整理的领域短语独立成立的词面直接证据条数 |")
        A(f"| **bare_prompt_direct_evidence** | {pq.get('bare_prompt_direct_evidence', 0)} | "
          "v2.5 §四：裸 prompt 被当直接证据的次数 —— **必须为 0** |")
        A(f"| **tech_words_used_as_lexical_direct_evidence** | "
          f"{pq.get('tech_words_used_as_lexical_direct_evidence', 0)} | "
          "v2.5 §四：泛用技术词（react / native / typescript / api…）充当词面直接证据的次数"
          " —— **必须为 0** |")
        A(f"| unresolved_mismatch_candidates | {pq.get('unresolved_mismatch_candidates', 0)} | "
          "存在未解除平台错配的候选数（只作观察）|")
        A("")
        A("> 四个 `*_evidence` 是**「候选 × 项目」条数**，同一条可同时具备多种证据；"
          "所有 matched_project 都必须至少带 1 类直接证据。"
          "**准确率优先于 coverage：matched_projects 下降完全可以接受。**")
    else:
        A("（本次数据未携带 project_match_quality —— 需重跑 `scripts/analyze.py`）")
    A("")
    A("> **v2.3 的口径变化**：`candidate 数量` / `matched_projects 覆盖率` / `Top30 是否凑满` "
      "这三项**不再是目标**；准确率优先。Top 里出现空位比塞垃圾好。")
    A("")

    # 二、Top
    A(f"## 二、Personalized Top（target_limit {target_limit} · 实际 {len(top)}）")
    A("")
    A("选取规则（与日报完全一致，复用同一函数 `select_top`）："
      f"① score ≥ **{min_top_score}**（配置化最低阈值）② 有真实个性化证据"
      "（matched need / capability gap / update / replacement 至少一个成立）"
      "③ T3/discovery_only 需有 T1·T2·官方交叉佐证 "
      "④ **无未解除的平台错配**（v2.4 §九：项目档案里没有任何项目用该平台 → 不进 Top）"
      "⑤ recommendation ≥ watch ⑥ 分数；"
      "多样性最后执行：同仓库上限 3 条 + **跨仓同功能族折叠**。")
    A("")
    A("> **只含 `install_candidate` / `watch`，不含 `ignore` / `reject`**；"
      f"符合标准的不足 {target_limit} 个时就输出实际数量，**不为凑数塞垃圾**。")
    A("")
    A(f"> 本轮被三道质量门挡下的：低分（< {min_top_score}）若干 / "
      f"无个性化证据若干 / T3 无交叉佐证 **{len(t3_unc)}** 条（仍留在 WATCHLIST）。"
      f"跨仓同功能族折叠 **{functional_dupes}** 条（见 2.1）。")
    A("")
    A("「安全」列的口径：`pass` = 静态审查无发现；`review_required` = 有语境性提及，需人工看一眼；")
    A("`block` = 高风险行为，已 reject；`unscanned` = 超出抓取预算，**最高只能是 watch**。")
    A("`T—` 表示来源未经验证（bottom-up 搜索结果），不参与安装推荐。")
    A("")
    A("| # | 分数 | 推荐 | canonical_key | 来源 | 命中需求 | 最匹配项目 | 缺口 | 安全 |")
    A("|---|---|---|---|---|---|---|---|---|")
    for i, c in enumerate(top, 1):
        gm = c.get("capability_gap_match") or {}
        sec = c["security"]
        st = f"{sec.get('verdict')}"
        A(f"| {i} | {c['score']:.1f} | {c['recommendation']} | `{c['canonical_key']}` | "
          f"{'T' + str(c['source_tier']) if c.get('source_tier') is not None else 'T—(unverified)'} "
          f"{c.get('source', '—')} | "
          f"{fmt_needs(c.get('project_match'))} | {fmt_projects(c.get('project_match'))} | "
          f"{gm.get('gap_level', '—')} | {st} |")
    A("")
    if top:
        repo_dist = collections.Counter(f"{c['owner']}/{c['repo']}" for c in top)
        multi = "、".join(f"`{k}`×{v}" for k, v in repo_dist.most_common() if v > 1)
        A(f"仓库分布：{len(repo_dist)} 个仓库承载 {len(top)} 条"
          + (f" → {multi}" if multi else "") + "。")
        A("")

    # 二·1、功能簇 ALTERNATIVES（§三/§八）
    A(f"### 2.1 FUNCTIONAL_CLUSTER —— ALTERNATIVES（{len(top_alts)} 个功能族有备选）")
    A("")
    A("候选池按 `owner/repo/skill` **保持独立记录**（不合并、不丢数据）；"
      "但 **Top 展示** 只出 PRIMARY —— 同一个功能族不连续推荐两个几乎一样的 Skill。")
    A("判定同族（满足其一即可）：normalized skill name 相同（≥5 字符）/ "
      "description jaccard ≥ 0.62 且名称同前缀 / content fingerprint 相同。")
    A("备选项**仍然完整保留在 `SKILL_CANDIDATES.json`**，此处只是不重复占版面。")
    A("")
    if top_alts:
        A("| PRIMARY（Top 内） | 被折叠的同族备选 | 判同族依据 |")
        A("|---|---|---|")
        for pk, dups in list(top_alts.items())[:20]:
            names = "；".join(
                f"`{d['canonical_key']}`（{d.get('score', '—')}）" for d in dups[:4])
            reasons = "；".join(sorted({str(d.get("reason", "—")) for d in dups}))
            A(f"| `{pk}` | {names} | {reasons} |")
    else:
        A("（无：本轮 Top 内没有跨仓同功能族重复）")
    A("")

    # 三、安全清单
    A(f"## 三、安全清单（Security Gate v2.4 · 沿用 v2.2 语境判定）")
    A("")
    A("核心区分：**「提到危险行为」≠「真的要求执行危险行为」**。"
      "每条 finding 带 `confidence` 与 `behavior_context`"
      "（mention / instruction / executable / remote_execution / **warning**），verdict 四值 "
      "`pass / review_required / block / unscanned`。")
    A("")
    A("> **v2.3 §四 修正**：`always_block` 规则不再「命中即 block」。"
      "`destructive_rm_root` / `pipe_to_shell` 等只有在**非警示语境**下才 block；"
      "`warning` 语境（`never ...` / `do not ...` / `禁止 ...` / `不要 ...` / "
      "安全审计文档举反例）一律降为 `review_required`。")
    A("")
    A(f"总体：pass {verdict.get('pass',0)} / review_required {verdict.get('review_required',0)}"
      f" / block {verdict.get('block',0)} / unscanned {verdict.get('unscanned',0)}")
    A("")
    A(f"### 3.1 block 级阻断（reject，{len(blocked)} 条）")
    A("")
    A("仅限高置信、**真会被执行**的高危行为：远程内容 pipe 进 shell/解释器、"
      "`rm -rf ~/` 或 `/`、凭据读取后外发、混淆 payload 执行等。官方来源**不豁免**。"
      "警示/反例语境不在此列。")
    A("")
    if blocked:
        A("| canonical_key | 来源 | 阻断规则 | 证据 |")
        A("|---|---|---|---|")
        for x in blocked[:40]:
            ev = ""
            for f in x["security"]["findings"]:
                if f.get("level") == "block":
                    ev = (f.get("evidence") or "")[:70]
                    break
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{','.join(x['security'].get('blocking_rules') or [])} | `{ev}` |")
    else:
        A("（无）")
    A("")
    A(f"### 3.2 review_required 需人工复核（{len(review)} 条；其中 {len(review_ctx)} 条被挡在安装候选之外）")
    A("")
    A("口径：属于敏感行为但**语境上只是提及/解释/示例/警示**，或虽有指令语境但危险度不足 —— "
      "一律不 reject，交人工判断。其中 `behavior_context` 为 instruction/executable "
      "的高敏感项会被挡在 `install_candidate` 之外（最高 watch）；"
      "`warning` 语境（安全文档举反例）不挡安装、也不 block。")
    A("")
    if review:
        A("| canonical_key | 来源 | 是否挡安装 | 命中规则 |")
        A("|---|---|---|---|")
        for x in (review_ctx + review_mention)[:40]:
            A(f"| `{x['canonical_key']}` | T{x.get('source_tier')} | "
              f"{'是' if x['security'].get('install_blocked') else '否（语境性提及）'} | "
              f"{rules_of(x['security'])} |")
    else:
        A("（无）")
    A("")
    A(f"### 3.3 install 候选的两阶段审查（PASS 2）")
    A("")
    A("带 `scripts/` 的候选不能只打一个 `bundled_scripts=low` 就放行："
      "进入 `install_candidate` 的候选会额外静态读取该 Skill 目录下的 "
      "`.py/.sh/.js/.ts/.mjs/.cjs/.ps1` 与 `package.json` 的 `postinstall`/`preinstall`。"
      "**只做静态读取，绝不执行脚本。**")
    A("")
    A(f"深度审查状态分布：complete {deep.get('complete',0)} / failed {deep.get('failed',0)}"
      f" / pending {deep.get('pending',0)} / not_required {deep.get('not_required',0)}"
      f" / skipped {deep.get('skipped',0)}；"
      f"`install_candidate` 必须先满足 `deep_scan_status = complete` 且无 block 级 finding。")
    A("")

    # 四、更新候选
    A(f"## 四、更新候选（update_available，{len(upd)} 条）")
    A("")
    if upd:
        A("| canonical_key | 外部最新 | 上游活跃度 | 说明 |")
        A("|---|---|---|---|")
        for x in upd:
            A(f"| `{x['canonical_key']}` | {x.get('latest_version') or '—'} | "
              f"{x.get('upstream_activity') or '—'} | {(x.get('update_note') or '')[:70]} |")
    else:
        A("（无）")
    A("")
    if repl:
        A(f"### 4.1 恢复/替换候选（replacement_candidate，{len(repl)} 条）")
        A("")
        A("判定口径：已装侧为 `known_missing`（如 Orca 三件套主副本缺失，"
          "coverage=strong / availability=degraded），"
          "或已装侧 `version_status=outdated_version` 且上游仍活跃。**仅登记候选，不自动安装。**")
        A("")
        A("| canonical_key | 说明 |")
        A("|---|---|")
        for x in repl:
            A(f"| `{x['canonical_key']}` | {(x.get('recommendation_reason') or '')[:90]} |")
        A("")

    # 五、本轮整改记录
    A("## 五、v2.5 修掉的问题（冻结前最后语义收口）")
    A("")
    A("v2.4 的架构、来源层、安全 Gate、Top 质量门、直接证据分级、否定窗口、功能族折叠、"
      "归档自定位**全部保持**；本轮只修**剩余语义误判**"
      "（android 需求证据 / 否定逗号枚举 / 词面证据 / mcp_dev / docx_xlsx / github-auto / "
      "证据语境四态），不重做已验收机制。")
    A("")
    A("| # | 问题 | v2.4 表现 | v2.5 处置 |")
    A("|---|---|---|---|")
    A("| 1 | android 需求被裸 device / build / install / launch 命中 | "
      "`google-mobile-ads-get-started` / `-validate` 只是「在 Android 应用里集成广告 SDK」，"
      "因 install / device 等词被记成 Android QA 需求（w=27） | android = 平台证据 AND "
      "**真实 QA 证据**：A 表（qa / test / e2e / adb / emulator / real device / device farm / "
      "appium / detox / maestro / espresso / xctest / instrumentation / 真机 / 自动化测试）"
      "或 B 表（signing / keystore / signed apk / apk / aab / app bundle / build verification / "
      "release build verification / 签名 / 构建验收）；裸 device / build / install / launch "
      "**禁止**作正向证据。反向回归：`orca-emulator-android` 必须仍然命中 "
      "android + mobile_qa（adb / emulator 是真证据）|")
    A("| 2 | 否定窗口在逗号枚举处把 B、C 洗回正向 | v2.4 把逗号当分句边界，"
      "`Don't use for A, B, or C.` 只有 A 被否，B / C 复活 —— "
      "`agent-platform-prompt-management` 明写不用于部署仍误命中 deploy（w=38）；"
      "`agent-platform-tuning` 同误判 | 两段式：**大句**只按 句号（需跟空白/行尾，"
      "保住 next.js / .net / node.js）/ 分号 / 换行 / 句读 切分；**逗号只在段内传播否定状态**；"
      "遇到显式对比词（but / however / instead / whereas / use for / can be used for / 但是 / "
      "但 / 不过 / 而是 / 可用于 / 可以用于 / 适用于）才恢复正向。"
      "`Not for A, but use for B.` 与 `非用于 A、B、C，但可用于部署上线` 必须照常恢复 |")
    A("| 3 | 词面证据凭泛用技术词或裸 prompt 独立成立 | `react-view-transitions` 因 "
      "react / native 匹配 `yejian-buguangdeng`；`claude-api` 与 `breakdown-test` 因裸 "
      "`prompt` 匹配 `prompt-manager` | 泛用技术词（react / native / javascript / "
      "typescript / python / css / html / tailwind / next / nextjs / android / kotlin / expo "
      "/ mobile / web / api / sdk / model / cloud…）从词面证据**全禁**；`prompt` 移出高信号词。"
      "词面独立成立只认**人工整理的领域短语**（prompt management / managed prompts / "
      "prompt library / prompt versioning / 提示词管理…）；普通词面重叠降级为"
      "**次要加分**（须与 strong_tech / positioning / shared_need 同现），"
      "单独造匹配计入 `lexical_alone_rejected` |")
    A("| 4 | 精度自检只能证明「字段非空」 | 无法回答「裸 prompt / 技术词是否又混进来了」 | "
      "新增三个显式计数：`lexical_phrase_direct_evidence`（短语独立成立次数）、"
      "**`bare_prompt_direct_evidence` 恒为 0**、"
      "**`tech_words_used_as_lexical_direct_evidence` 恒为 0**（非 0 即回归失败）|")
    A("| 5 | 提到 MCP ≠ 具备 MCP 开发能力 | `claude-api` 描述里「支持与 MCP 配合」"
      "被打上 mcp_dev 标签、吃缺口分 | mcp_dev 需**核心开发证据**："
      "build / create / develop / implement / write / set up … MCP（server / tool / client / "
      "Model Context Protocol implementation）/ MCP SDK / 编写 MCP / MCP 服务开发，"
      "或 Skill 名含 mcp-server / mcp-development / mcp-builder。"
      "「支持 MCP / 可与 MCP 使用 / 文档包含 MCP」只算 mention；"
      "`claude-api` 失去 mcp_dev、保留 llm-api；真实 MCP builder 不受影响 |")
    A("| 6 | PPTX 冒充 docx_xlsx | `publish-to-pages` 生成 PPTX / PDF / HTML，"
      "却被记成 docx_xlsx 能力、拿文档缺口分 | docx_xlsx 只认 docx / xlsx / Word / Excel / "
      "spreadsheet / 明确的 office document / 上下文中的文档处理·表格处理；"
      "PPTX / PowerPoint 单列 `pptx_processing` 标签，**不得**伪造 docx_xlsx |")
    A("| 7 | 裸 `github` 命中 github-auto | `breakdown-test` 只因引用 GitHub 仓库语境"
      "就被记成 github-auto 需求（且顺带带出错误的词面项目匹配） | github-auto = "
      "GitHub 平台词 AND 运维语义词（GitHub Actions / gh CLI / repository automation / "
      "issue creation / pull request automation / PR review / release automation / labels / "
      "milestones / workflow dispatch / repository sync / commit automation / GitHub API / "
      "自动建 issue / 自动 PR / 仓库同步…）|")
    A("| 8 | 「顺带提及」与「核心能力」在评分层无统一口径 | mcp_dev / docx_xlsx / "
      "github-auto / android / deploy 各自为政，修一处漏一处 | 统一字段 "
      "`capability_evidence_context` ∈ {primary, supporting, mention, negated}："
      "只有 primary 拿满 capability gap 分；supporting 上限 8；mention / negated 上限 2；"
      "需求侧 supporting 权重 ×0.5。以后新增误报按四态归类修，**不再手写候选黑名单** |")
    A("")
    A("### 5.1 v2.4 附带修掉的两个「规则看起来对、实际不生效」缺陷（保留，v2.5 仍生效）")
    A("")
    A("v2.4 排查中发现并修掉 —— 二者都属于「写在配置里也测不出来」的类型，"
      "且会让 §五 的中文否定标记形同虚设：")
    A("")
    A("| # | 缺陷 | 后果 | 处置 |")
    A("|---|---|---|---|")
    A("| A | 中文关键词命中率恒为 0 | `_WORD_RE` 是纯 ASCII（`[a-z0-9]…`），中文没有词边界，"
      "整词匹配下规则表里 **48 个 NEED_RULE + 27 个 CAP_RULE 中文关键词**，"
      "加上 TECH_MATCH 的 `容器化` / `菜单栏应用`，**全部是永不命中的死词** | "
      "含 CJK 的关键词改走子串匹配；回归测试对规则表做**全量自检**"
      "（中文关键词不得再有死词），同时保留英文整词匹配（`ui` 命中 build 的老事故不许回归）|")
    A("| B | 分句不含逗号 → 否定窗口过度压制 | 「非用于 A，可用于 B」整句被丢弃，"
      "把逗号后的**正向证据**一起误杀 | 逗号（`,` / `，`）纳入分句边界，否定只作用于本小句；"
      "修掉后 `negated_evidence_rejected` 由 **94 降到 30**，即减少了 64 处「假压制」|")
    A("")
    A("### 5.2 v2.4 已验收通过、本轮**不重做**（§十二）")
    A("")
    A("strong / secondary 技术栈分级与 `strong_tech` 直接证据 · Docker 词典删裸 "
      "`container` · 词面 stop list 与 `lexical_single_rejected` · 通用否定窗口"
      "（逗号语义在 v2.5 §五.2 收紧，窗口本体保留）· deploy 的 hosted+部署对象同现 · "
      "testing_qa 主能力证据 · 未解除 domain_mismatch 四道门（×0.7 / 不 install / 不进 Top）· "
      "PROJECT_MATCH_QUALITY 分项计数 · CJK 死词全量自检 · "
      "17 source registry · T0/T1/T2/T3 分层 · bottom-up 非 Skill 隔离 · ClawHub 构建产物过滤 · "
      "mobile_qa / supabase-db / llm-api / voice-input 误报修复 · Security warning vs 真执行区分 · "
      "deep scan 安装候选 Gate · Top 不含 ignore/reject · Top 不凑 30 · T3 无佐证不进 Top · "
      "functional family / alternatives · source official 口径统一 · 测试 PASS/SKIP/FAIL 三分 · "
      "包内 SKILL_CONTEXT 自定位。")
    A("")
    # v2.5 §十一：Top 重审 + 三处禁选项目匹配 —— 用**本轮实际数据**核对，不写死结论
    forbid_mp = {("vercel-labs/agent-skills/react-view-transitions", "yejian-buguangdeng"),
                 ("anthropics/skills/claude-api", "prompt-manager"),
                 ("github/awesome-copilot/breakdown-test", "prompt-manager")}
    hits_forbid = [(k, p) for c in I for p in
                   ((c.get("project_match") or {}).get("matched_projects") or [])
                   for k in [c["canonical_key"]] if (k, p.get("project")) in forbid_mp]
    suspects = ("google/skills/google-mobile-ads-get-started",
                "google/skills/agent-platform-prompt-management")
    in_top_suspects = [c["canonical_key"] for c in top if c["canonical_key"] in suspects
                       and ((c.get("project_match") or {}).get("matched_need_evidence_levels")
                            or {}).get("android") not in (None, "primary")]
    A(f"本轮 §十一 重审（实际数据核对）：三处禁选项目匹配出现 **{len(hits_forbid)}** 处（应为 0）；"
      f"`google-mobile-ads-get-started` / `agent-platform-prompt-management` 因错误规则占用 Top "
      f"**{len(in_top_suspects)}** 处（应为 0）；"
      f"Top 内未解除平台错配 **{sum(1 for c in top if bc.unresolved_mismatch(c))}** 条（应为 0）。")
    A("")
    A(f"本轮结果：Top 实际 **{len(top)}/{target_limit}**，跨仓同功能族折叠 "
      f"**{functional_dupes}** 条。")
    A("")

    # 六、复现
    A("## 六、如何复现／核对")
    A("")
    A("```bash")
    A("# 一键全流程（注册表 → 发现 → 分析 → Context → 本对照件）")
    A("python3 scripts/run_daily.py")
    A("# 只重算候选池")
    A("python3 scripts/analyze.py")
    A("# 重新生成本对照件")
    A("python3 scripts/make_digest.py -o ../CANDIDATES_DIGEST.md")
    A("# 离线测试（43 项，不联网；摘要分 PASS / SKIP / FAIL 三栏）")
    A("python3 tests/test_pipeline.py")
    A("```")
    A("")
    A("**依赖的输入（缺一不可）**：")
    A("")
    A("| 输入 | 解析优先序（v2.3 §九 / v2.4 §十二 保持） | 作用 |")
    A("|---|---|---|")
    A("| A 项目需求 `SKILL_CONTEXT.md` | ① `SKILL_CONTEXT_PATH` 环境变量 → "
      "② **包内 `支撑/输入/SKILL_CONTEXT.md`**（归档包解压后自定位） → ③ 本机默认路径 | "
      "决定 PROJECT_MATCH / 相关性否决 / matched_projects |")
    A("| B 已装侧底座 `INSTALLED_SKILLS_CONTEXT.md` + `SKILL_SOURCE_MAP.json` | "
      "① `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH` → ② 同级 v4 文件夹自动发现（向上 3 级） → "
      "③ 找不到则该组测试 **SKIP 并提示** | 决定 `installed_relationship` 与 "
      "`capability_gap_match` |")
    A("| C 外部候选 | `data/SKILL_CANDIDATES.json` | 本层产物 |")
    A("")
    A("**路径不再写死**：`scripts/common.py` 的所有输入路径都可用环境变量覆盖，"
      "未设置时按上表优先序自动定位（归档包内也能自洽），并用 `~` 展开（不写死用户名）。"
      "命中的来源会记录在 `common.PATH_RESOLUTION` 里，可核对到底读的是哪个文件：")
    A("")
    A("```bash")
    A("SKILL_REPO_ROOT=/path/to/仓库 \\")
    A("SKILL_CONTEXT_PATH=/path/to/SKILL_CONTEXT.md \\")
    A("SKILL_DATA_DIR=/path/to/data \\")
    A("python3 scripts/run_daily.py")
    A("```")
    A("")
    A("可覆盖的变量：`SKILL_REPO_ROOT` / `SKILL_CONTEXT_PATH` / `SKILL_DATA_DIR`"
      " / `INSTALLED_CTX_PATH` / `SOURCE_MAP_PATH`。"
      "换机器或跑归档副本时用环境变量指路，**不要改脚本内的路径**。")
    A("")
    A(f"> 未找到输入 A 时：`matched_projects` 会为空、需求证据全体失效 —— "
      f"本件生成时输入 A {_path_report('skill_context', SKILL_CONTEXT_PATH)}。")
    A("")
    A("> **本行会随运行环境变化**（env / 包内自定位 / 本机默认），属预期；"
      "对照件其余内容在不同环境下应当逐位一致。")
    A("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default="-", help="输出文件；默认 stdout")
    a = ap.parse_args()
    md = build()
    if a.out == "-":
        print(md)
    else:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(md)
        print(f"written: {a.out} ({len(md.encode('utf-8'))} B)")


if __name__ == "__main__":
    main()
