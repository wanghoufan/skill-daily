# -*- coding: utf-8 -*-
"""语义匹配规则引擎（v2.5）。

为什么要有这个模块（v2.1 → v2.2 的根本改动）：
  v2.1 用的是「关键词列表 + 整词匹配」。虽然已经修掉了子串事故（`ui` 命中 build/require），
  但仍有更深的语义错误：**「出现某个平台词」被等同于「满足某项能力需求」**。
  典型误报：
    · Google Mobile Ads SDK / IMA DAI SDK / Penpot UI-UX / responsive-design
      → 只因文本里出现 android / ios / mobile / expo 就被记成 mobile_qa（移动端 QA）
    · alloydb-basics / postgresql-optimization
      → 只因出现 PostgreSQL 就被当成 supabase_db 缺口解决方案
    · 任何示例里带一段 Python → 就被认为解决「Python 本地自动化」
  这些误报会直接抬高 PROJECT_MATCH（25/100）与 CAPABILITY_GAP（20/100），
  把真正相关的候选挤下去。

v2.3 修的是「规则形式上有 direct evidence，但真实语义仍然是假相关」的第一批：
  类型适用不得单独造匹配、NEED_RULE 二轮收紧、跨仓功能族折叠、always_block 误伤。

v2.4（本轮）修的是同一类问题的最后一层 —— **技术栈词与词面重叠造成的假相关**：
  ① 技术栈证据分 STRONG / SECONDARY：TypeScript / React / Python / Docker / Shell /
     HTML / CSS / GitHub 等泛用词**不得单独**产生项目匹配（事故：一个 Azure 云端
     Playwright 服务仅因描述里有 TypeScript，就匹配了 5 个普通 TS 项目）。
  ② Docker 词典删掉裸 `container`（事故：`container queries` 被当成 Docker）。
  ③ 词面重叠证据加泛词 stop list，并要求「≥2 个高区分度词」或「1 个明确项目域高信号词」
     （事故：Azure Resource Manager 与 prompt-manager 只因共有 `manager` 就成立）。
  ④ NEED_RULE 支持**否定窗口**：`not for X` / `不要用于 X` 里的词不得当正向证据
     （事故：描述写着 `NOT for running Playwright tests` 却仍被判 browser-qa）。
  ⑤ testing_qa 必须来自「主能力证据」（Skill 名含 test/e2e/playwright… 或描述明确
     把测试当核心任务），`testing methodologies` / `optional QA` 只算提及。

v2.5（冻结前最后收口，§一~§九）修的是同一类问题剩下的实例：
  ① android 需求必须对应「真机 QA / 构建签名」——裸 device/build/install/launch 一律
     不作正向证据（事故：google-mobile-ads-get-started 只是接入广告 SDK 就命中 android）。
  ② 否定窗口改为**两层**：逗号不再天然重置否定作用域，`Don't use for A, B, or C.` 中
     A/B/C 全部保持否定；显式转折标记（but / 但 / 可用于…）才恢复正向
     （事故：agent-platform-prompt-management 因 `model deployment to endpoints` 落在
     否定枚举第二段被「复活」成正向证据，误命中 deploy）。
  ③ 词面（lexical）证据不得再被技术泛词与裸 `prompt` 制造（react/native/… 归
     STRONG/SECONDARY_TECH 负责）；词级重叠只能作加分项，单独成立只允许
     明确登记过的「项目域短语」。
  ④ mcp_dev / docx_xlsx / github-auto 等能力判定从「出现即命中」改为「核心能力证据」；
     PPTX 不得冒充 docx_xlsx。
  ⑤ 统一候选级 `capability_evidence_context` 四态字段（primary/supporting/mention/negated），
     只有 primary 可拿完整 gap 分，supporting 上限 8，mention/negated 上限 2。

MATCH_RULE 语义（本模块的核心数据结构）：
    {
      "all_groups": [ [kw,...], [kw,...] ],  # 组间 AND，组内 OR —— 全部组都要命中
      "any_of":     [kw, ...],               # 任一命中即可（OR）
      "any_groups": [ [kw,...], [kw,...] ],  # 任一组「整组命中」即可（组内 AND / 组间 OR）
      "none_of":    [kw, ...],               # 命中任一即否决（排除性条件）
      "context_terms": [kw, ...],            # 语境词：不参与判定，命中则记入证据用于解释
      "custom":     callable,                # 无法用列表表达的复合判定（如 testing_qa）
    }
  · all_groups 必须全部命中；
  · 若给了 any_of 或 any_groups，则「(any_of 任一命中) 或 (any_groups 任一组全命中)」；
  · 二者都没给则不设正向条件。
  规则里出现的所有关键词一律走 hit()：单字词按整词匹配，含空格/点/井号的按短语匹配。
  **禁止子串匹配**（v2.1 的 `ui` 事故）。
  **否定窗口内的词一律不算命中**（v2.4 §五）。

本模块只做纯计算，不读文件、不联网 —— 便于离线测试与在多台机器上复用。
"""
import re

# ---------- 命中原语 ----------
_WORD_RE = re.compile(r"[a-z0-9][a-z0-9\+#\.]*")
# CJK / 全角：中文没有词边界，_WORD_RE 又是纯 ASCII，所以中文关键词永远进不了 words 集合。
# 事故（v2.4 查出）：规则表里 **48 个 NEED_RULE + 27 个 CAP_RULE + TECH_MATCH 的
# `容器化` / `菜单栏应用`** 中文关键词命中率恒为 0 —— 是写死也测不出来的死词，
# 而 §五 专门列了「非用于 / 不用于 / 不支持」中文否定标记，说明中文匹配本就该生效。
_CJK_RE = re.compile(r"[\u3400-\u9fff\u3040-\u30ff\uff65-\uff9f]")

# ---------- 否定窗口（v2.4 §五；v2.5 §二 改为两层作用域） ----------
# 第一层·语义段：只按 句点（后接空白/行尾，next.js / node.js / .net 不会被切碎）、
# 换行、分号、句读切；**普通逗号（, ，、）不再是段边界**。
# 第二层·段内子句：按逗号再切，否定状态在子句间**传递**：
#   · 子句含否定标记 → 丢弃，且其后子句继续视为否定范围（`Don't use for A, B, or C.`
#     的 A/B/C 全部否定 —— v2.4 按逗号重置，把 B/C「复活」成了正向证据）；
#   · 子句含显式「转折/恢复正向」标记（but / however / 但 / 可用于 / 可直接…）→ 恢复正向；
#   · 其余子句继承当前否定状态。
_CLAUSE_SPLIT_RE = re.compile(r"(?:\.(?=\s|$)|[\n;；。！!？?]+)")
_COMMA_SPLIT_RE = re.compile(r"[,，、]+")
_NEG_MARK_RE = re.compile(
    r"(?:\bnot\b|\bnever\b|\bno\s+longer\b|\bdon'?t\b|\bdoesn'?t\b|\bdo\s+not\b"
    r"|\bdoes\s+not\b|\bisn'?t\b|\bis\s+not\b|\baren'?t\b|\bare\s+not\b|\bavoid\b"
    r"|\bwithout\b|\bexcept\b|\bunavailable\b|\bdeprecated\b|\bnot\s+intended\b"
    r"|非用于|不用于|不支持|不适用|不能|禁止|不要|不可)", re.I)
# 显式「恢复正向」标记（v2.5 §二）。注意顺序：**先查否定标记再查恢复标记**，
# 所以 `Don't use for …` 里的 "use for" 不会把自己救回来。
_POS_RESTORE_RE = re.compile(
    r"(?:\bbut\b|\bhowever\b|\binstead\b|\bwhereas\b|\bwhile\b|\buse for\b|\bused for\b"
    r"|\bis used for\b|\bare used for\b|\bcan be used for\b|\bcould be used for\b"
    r"|但是|但|不过|而是|可以用于|可用于|适用于|可直接|即可)", re.I)


def _positive_chunks(raw):
    """两层否定作用域（v2.5 §二）：返回保留下来的「正向子句」列表。"""
    keep = []
    for seg in _CLAUSE_SPLIT_RE.split(raw or ""):
        if not seg:
            continue
        neg_active = False
        for part in _COMMA_SPLIT_RE.split(seg):
            if not part.strip():
                continue
            if _NEG_MARK_RE.search(part):
                neg_active = True          # 枚举的后续子句继续保持否定
                continue
            if _POS_RESTORE_RE.search(part):
                neg_active = False
                keep.append(part)
                continue
            if not neg_active:
                keep.append(part)
    return keep


def strip_negated(raw):
    """去掉处于否定作用域内的子句，只留「正向文本」（v2.4 §五 / v2.5 §二）。

    例：`Don't use for model training, model deployment to endpoints, or managing prompts.`
    → 三个逗号子句全部丢弃，其中的 deployment / endpoints / prompts 不再是正向证据。
    例：`Not for A, but use for B.` → A 丢弃，B 经 `but` 恢复为正向。
    """
    return " ".join(_positive_chunks(raw))


def negated_words(raw):
    """返回「恰好只落在否定作用域里」的词集合（用于诊断统计）。"""
    low = (raw or "").lower()
    all_w = set()
    for seg in _CLAUSE_SPLIT_RE.split(low):
        all_w |= set(_WORD_RE.findall(seg))
    pos_w = set()
    for part in _positive_chunks(low):
        pos_w |= set(_WORD_RE.findall(part))
    return all_w - pos_w


# ---------- 质量计数（v2.4 §十：PROJECT_MATCH_QUALITY） ----------
QUALITY = {
    "matched_candidates": 0,
    "strong_tech_evidence": 0,
    "positioning_evidence": 0,
    "shared_need_evidence": 0,
    "lexical_evidence": 0,
    "secondary_tech_only_rejected": 0,
    "negated_evidence_rejected": 0,
    "lexical_single_rejected": 0,
    # v2.5 §三/§五：词面证据重构后的审计计数
    "lexical_alone_rejected": 0,                     # 词级重叠本想单独成立，已降为「只加分」
    "lexical_phrase_direct_evidence": 0,             # 明确登记过的项目域短语单独成立
    "bare_prompt_direct_evidence": 0,                # 必须恒为 0（§十/§十四 审计项）
    "tech_words_used_as_lexical_direct_evidence": 0,  # 必须恒为 0（§四 不变式）
}
_KIND_TO_COUNT = {"strong_tech": "strong_tech_evidence",
                  "positioning": "positioning_evidence",
                  "shared_need": "shared_need_evidence",
                  "lexical": "lexical_evidence"}


def reset_quality():
    """每轮正式评估前清零，保证计数是「本轮候选级」而不是多次调用累加。"""
    for k in QUALITY:
        QUALITY[k] = 0


def bag(name, desc):
    """返回 (整词集合, 原文小写, 连字符/下划线归一化文本)。

    norm 用于短语匹配：把 `react-native` / `react_native` / `react native` 统一成
    "react native"，避免因为连接符写法不同而漏命中。
    """
    raw = f"{name or ''} {desc or ''}".lower()
    words = set(_WORD_RE.findall(raw))
    norm = re.sub(r"\s+", " ", re.sub(r"[\-_/]+", " ", raw))
    return words, raw, norm


def _ctx(name, desc):
    """一次算好一个候选的全部文本视图（含否定过滤后的正向视图）。"""
    words, text, norm = bag(name, desc)
    nwords, _nt, _nn = bag(name, "")
    ptext = strip_negated(text)
    pwords, _pt, pnorm = bag("", ptext)
    pwords |= nwords          # Skill 名里的词不受描述否定影响
    pnorm = f"{pnorm} {re.sub(r'[\\-_/]+', ' ', ' '.join(nwords))}".strip()
    return {"words": words, "text": text, "norm": norm, "name_words": nwords,
            "pwords": pwords, "ptext": ptext, "pnorm": pnorm}


def hit(words, text, norm, kw):
    """单字关键词 → 整词匹配；含空格/点/井号的关键词 → 短语匹配。

    整词匹配是硬要求：v2.1 之前用 `kw in text` 导致 `ui` 命中 build/require/guidance，
    使 PROJECT_MATCH 恒为满分、Top30 被无关技能占满。

    v2.4：含 CJK 的关键词改走子串匹配。中文没有词边界、`_WORD_RE` 又是纯 ASCII，
    若坚持整词匹配，规则表里全部中文关键词都是永不命中的死词（实测 75 个）。
    """
    k = kw.lower()
    if " " in k or "." in k or "#" in k or _CJK_RE.search(k):
        return k in norm or k in text
    return k in words


def hit_any(words, text, norm, kws):
    return any(hit(words, text, norm, k) for k in kws)


def hit_pos(ctx, kw):
    """只在**正向视图**（已去掉否定小句）上判定命中（v2.4 §五）。"""
    return hit(ctx["pwords"], ctx["ptext"], ctx["pnorm"], kw)


def hit_pos_any(ctx, kws):
    return any(hit_pos(ctx, k) for k in kws)


def _note_suppressed(ctx, kws):
    """统计「本来会命中、但被否定窗口压制掉」的关键词（§十 negated_evidence_rejected）。"""
    for k in kws:
        if hit(ctx["words"], ctx["text"], ctx["norm"], k) and not hit_pos(ctx, k):
            QUALITY["negated_evidence_rejected"] += 1


def rule_hits(cand, rules, limit=None, ctx=None):
    """对一整张规则表跑匹配，返回 [(key, [evidence]), ...]（保持规则表定义顺序）。"""
    if ctx is None:
        ctx = _ctx(cand.get("skill_name"), cand.get("description"))
    out = []
    for key, rule in rules.items():
        ok, ev = match_rule(ctx, rule)
        if ok:
            out.append((key, ev))
            if limit and len(out) >= limit:
                break
    return out


def match_rule(ctx, rule):
    """执行一条 MATCH_RULE，返回 (是否命中, 命中证据列表)。

    判定顺序：custom（若有）→ all_groups（组间 AND / 组内 OR）→ any_of / any_groups
    → none_of（否决）。context_terms 只补证据，不影响判定结果。
    **所有正向关键词都在「否定过滤后的文本」上判定**（v2.4 §五）。
    """
    if not rule:
        return False, []
    custom = rule.get("custom")
    if custom is not None:
        return custom(ctx)
    ev = []
    for group in rule.get("all_groups") or []:
        h = [k for k in group if hit_pos(ctx, k)]
        if not h:
            _note_suppressed(ctx, group)
            return False, []
        ev += h
    has_primary = bool(rule.get("any_of") or rule.get("any_groups"))
    if has_primary:
        ok = False
        a = rule.get("any_of")
        if a:
            h = [k for k in a if hit_pos(ctx, k)]
            if h:
                ok, ev = True, ev + h
            else:
                _note_suppressed(ctx, a)
        if not ok:
            for group in rule.get("any_groups") or []:
                if group and all(hit_pos(ctx, k) for k in group):
                    ok, ev = True, ev + list(group)
                    break
            if not ok:
                for group in rule.get("any_groups") or []:
                    _note_suppressed(ctx, group)
        if not ok:
            return False, []
    n = rule.get("none_of")
    if n:
        hit_n = [k for k in n if hit(ctx["words"], ctx["text"], ctx["norm"], k)]
        if hit_n:
            # 排除性语境（管理面 / 资源编排…）与否定窗口同属「被语境压制掉的假相关」，
            # 统一计入 negated_evidence_rejected，便于审查者看到这个门真的在工作。
            for k in hit_n:
                if k.lower() in _EXCLUSION_CONTEXT_TERMS:
                    QUALITY["negated_evidence_rejected"] += 1
            return False, []
    for k in rule.get("context_terms") or []:
        if hit(ctx["words"], ctx["text"], ctx["norm"], k):
            ev.append(k)
    return True, sorted(set(ev))


# ==========================================================================
# 一、能力标签规则 CAP_RULE（读已装侧 CAPABILITY_SUPPRESSION / 决定能力缺口）
# ==========================================================================
# v2.2 关键收紧：
#   · mobile_qa 必须「移动平台证据」AND「QA/设备/构建验收证据」，不再单凭出现 android/mobile
#   · supabase_db 必须真 Supabase 语境（或 RLS）；普通 PostgreSQL 归 postgres_db
#   · 新增 mobile_dev / expo_rn_dev：移动「开发」能力与移动「QA」能力分列，
#     React Native / Expo 最佳实践属于开发，不自动属于 QA
# v2.4 §七/§八 关键收紧：
#   · testing_qa 改成「主能力证据」判定，不再被 `testing methodologies` / `optional QA`
#     这类**顺带提及**污染（事故：ai-prompt-engineering-safety-review 与
#     ai-team-orchestration 因此白拿 weak gap 的 15 分加成）。
_MOBILE_PLATFORM = ["android", "ios", "expo", "react native", "flutter", "mobile app",
                    "mobile application", "移动端", "安卓"]
_QA_OR_DEVICE = ["qa", "test", "tests", "testing", "e2e", "end to end", "adb", "emulator",
                 "real device", "device farm", "appium", "detox", "maestro", "xctest",
                 "espresso", "ui test", "build verification", "signing", "keystore", "apk",
                 "aab", "app bundle", "install verification", "launch verification",
                 "自动化测试", "真机", "签名"]

# testing_qa 的「主能力证据」词表（v2.4 §八）：
#   A. Skill 名本身含测试身份词
_TESTING_NAME_TOKENS = {"test", "tests", "testing", "qa", "e2e", "playwright", "pytest",
                        "vitest", "jest", "cypress", "spec", "specs", "testify", "selenium"}
#   B. 描述明确把「测试」当核心任务（而不是顺带提一句）
_TESTING_CORE_PHRASES = [
    "run tests", "running tests", "run the tests", "run test", "execute tests",
    "executing tests", "write tests", "writing tests", "create tests", "creating tests",
    "test application", "test the application", "test applications", "testing application",
    "qa workflow", "acceptance testing", "regression testing", "validate behavior",
    "validate behaviour", "test suite", "test suites", "testing framework", "test framework",
    "e2e tests", "end to end tests", "end-to-end tests", "unit tests", "integration tests",
    "test automation", "browser testing", "webapp testing", "web app testing",
    "visual regression", "flaky tests", "debugging flaky tests", "testing standards",
    "运行测试", "编写测试", "测试套件", "自动化测试", "端到端测试",
]
#   只算「提及」、不算能力的写法（用于诊断与文档说明）
_TESTING_MENTION_ONLY = ["testing methodologies", "optional qa", "may be tested",
                         "qa is optional", "examples include testing"]


def _rule_testing_qa(ctx):
    """testing_qa 的复合判定（v2.4 §八）：名含测试身份词 或 描述把测试当核心任务。"""
    name_hit = sorted(ctx["name_words"] & _TESTING_NAME_TOKENS)
    phrase_hit = [p for p in _TESTING_CORE_PHRASES if hit_pos(ctx, p)]
    ev = name_hit + phrase_hit
    return (bool(ev), sorted(set(ev)))


# ---------- v2.5 §六：mcp_dev 必须是「核心 MCP 开发能力」 ----------
_MCP_TERMS = ["mcp", "model context protocol"]
_MCP_DEV_PHRASES = [
    "mcp server development", "mcp tool development", "mcp client development",
    "model context protocol implementation", "mcp integration development",
    "mcp server setup", "mcp sdk", "编写 mcp", "mcp 服务开发", "mcp开发", "mcp 开发",
]
# Skill 名本身断言了 MCP 能力（mcp-builder / mcp-server / mcp-setup…）
_MCP_NAME_PHRASES = ["mcp builder", "mcp server", "mcp servers", "mcp development",
                     "mcp dev", "mcp setup", "mcp client", "mcp tool", "mcp tools"]
# 「开发动词 …(同一句内) … mcp」——覆盖 "creating high-quality MCP servers" 这类
# 动词与 MCP 之间隔着修饰语的真实写法。
_MCP_DEV_RE = re.compile(
    r"\b(build|building|builds|create|creating|creates|develop|developing|develops"
    r"|implement|implementing|implements|write|writing|set up|setup|install|installing"
    r"|configure|configuring)\b[^.]{0,50}?\b(mcp|model context protocol)\b", re.I)
# 「使用侧」语境：集成/连接/暴露 —— 算 supporting，不算开发
_MCP_USAGE_TERMS = ["integration", "integrate", "connect", "connects", "expose", "exposes",
                    "interoperate"]


def _norm_name(name):
    return re.sub(r"[\-_/]+", " ", (name or "").lower()).strip()


def _cls_mcp(ctx):
    """返回 (证据语境等级, 证据)。等级见 v2.5 §九：primary/supporting/mention/negated。"""
    if not hit_any(ctx["words"], ctx["text"], ctx["norm"], _MCP_TERMS):
        return None, []
    if not hit_pos_any(ctx, _MCP_TERMS):
        return "negated", []          # MCP 只出现在否定作用域里
    ev = [p for p in _MCP_DEV_PHRASES if hit_pos(ctx, p)]
    if _MCP_DEV_RE.search(ctx["pnorm"]):
        ev.append("dev-verb+mcp")
    nn = _norm_name(" ".join(ctx["name_words"]))
    if any(p in nn for p in _MCP_NAME_PHRASES):
        ev.append("name-asserts-mcp")
    if ev:
        return "primary", sorted(set(ev))
    if "mcp" in nn or any(hit_pos(ctx, t) for t in _MCP_USAGE_TERMS):
        # 名含 mcp 或「与 MCP 集成/连接」——是真实的 MCP 使用能力，但不是开发
        return "supporting", []
    return "mention", []              # §六：文档里列了一句 MCP ≠ 具备 MCP 开发能力


def _rule_mcp_dev(ctx):
    """CAP 命中 = primary 或 supporting；单纯提及不得打 mcp_dev（事故：claude-api）。"""
    lvl, ev = _cls_mcp(ctx)
    return (lvl in ("primary", "supporting"), ev)


# ---------- v2.5 §七：docx_xlsx 只认 Word/Excel/表格，PPTX 另立标签 ----------
_DOCX_XLSX_PRIMARY = ["docx", "xlsx", "excel", "spreadsheet", "电子表格",
                      "word document", "word documents", "microsoft word"]
_DOCX_XLSX_SUPPORTING = ["office document", "office documents", "office file",
                         "office 文档", "文档处理", "表格处理"]
_PPTX_TERMS = ["pptx", "powerpoint", "演示文稿"]


def _cls_docx(ctx):
    prim = [k for k in _DOCX_XLSX_PRIMARY if hit_pos(ctx, k)]
    if prim:
        return "primary", prim
    sup = [k for k in _DOCX_XLSX_SUPPORTING if hit_pos(ctx, k)]
    if sup:
        return "supporting", sup
    if hit_pos_any(ctx, _PPTX_TERMS):
        return "mention", []     # §七：只处理 PPT 不算 DOCX/XLSX 能力
    return None, []


def _rule_docx_xlsx(ctx):
    lvl, ev = _cls_docx(ctx)
    return (lvl in ("primary", "supporting"), ev)


CAP_RULE = {
    "mobile_qa": {
        # 组间 AND：既要移动平台，又要 QA / 设备 / 构建验收证据
        "all_groups": [_MOBILE_PLATFORM, _QA_OR_DEVICE],
        "context_terms": _QA_OR_DEVICE + _MOBILE_PLATFORM,
    },
    "mobile_dev": {
        # 移动「开发」：只要是移动平台的开发/最佳实践即可，不要求 QA 证据
        "all_groups": [["expo", "react native", "flutter", "android", "ios", "swiftui",
                        "jetpack compose", "kotlin multiplatform", "mobile app development",
                        "mobile development", "跨平台开发", "移动开发"]],
        "any_of": ["app", "development", "developer", "skill", "best practices", "ui",
                   "component", "navigation", "编程", "框架"],
        "context_terms": ["expo", "react native", "android", "ios"],
    },
    "expo_rn_dev": {
        "all_groups": [["expo", "react native", "react-native", "expo router", "expo sdk",
                        "expo modules", "nativewind"]],
        "context_terms": ["expo", "react native"],
    },
    "image_creative": {
        "any_of": ["image generation", "image-generation", "image editing", "image-editing",
                   "illustration", "thumbnail", "svg art", "svg generation", "creative image",
                   "图片生成", "图片处理", "图像生成", "相册封面"],
        "none_of": ["image analysis", "imageanalysis", "ocr", "vision api", "object detection"],
    },
    "data_analytics": {
        "any_of": ["analytics", "data analysis", "data-analysis", "data visualization",
                   "data-visualization", "chart generation", "chart-generation", "pandas",
                   "dataframe", "report generation", "数据分析", "可视化"],
        "none_of": ["google analytics", "web analytics"],
    },
    "security_audit": {
        "any_of": ["security audit", "security-audit", "vulnerability", "owasp", "penetration test",
                   "penetration testing", "threat model", "secret scanning", "dependency audit",
                   "安全审计", "漏洞"],
    },
    "supabase_db": {
        # v2.3：裸 RLS 不足 —— Power BI / 其他数据库也有 row-level security，
        # 必须**明确出现 supabase** 才算 Supabase 能力（旧版把裸 rls 当证据，属误报）。
        "all_groups": [["supabase"]],
        "context_terms": ["rls", "row level security", "postgres", "postgresql",
                          "migration", "database"],
    },
    "postgres_db": {
        "all_groups": [["postgres", "postgresql", "psql", "pgvector", "alloydb", "cloud sql"]],
        "none_of": ["supabase"],
        "context_terms": ["database", "sql", "query", "index", "migration"],
    },
    # v2.4 §七/§八：从「出现 test/qa 就命中」改为「主能力证据」复合判定
    "testing_qa": {"custom": _rule_testing_qa},
    # v2.5 §七：只认 Word / Excel / 表格；PPTX/Powerpoint 单列，不得冒充 docx_xlsx 缺口
    "docx_xlsx": {"custom": _rule_docx_xlsx},
    "pptx_processing": {"all_groups": [_PPTX_TERMS],
                        "context_terms": ["pdf", "html", "slides"]},
    # v2.5 §六：必须是「核心 MCP 开发能力」，单纯提及不算
    "mcp_dev": {"custom": _rule_mcp_dev},
    "windows": {
        "any_of": ["windows", "powershell", "win32", "wpf", "winui", "windows 11"],
    },
    "macos": {
        "any_of": ["macos", "darwin", "applescript", "appkit", "cocoa", "mac os"],
    },
    "frontend_design": {
        "any_of": ["frontend", "front-end", "front end", "web design", "web-design",
                   "ui design", "ui-design", "ui/ux", "ux", "css", "tailwind", "shadcn",
                   "design system", "design-system", "responsive design", "visual design",
                   "界面设计", "前端设计"],
    },
    "browser_automation": {
        "any_of": ["browser automation", "browser-automation", "playwright", "puppeteer",
                   "selenium", "chrome devtools", "cdp", "headless browser", "web scraping",
                   "浏览器自动化"],
    },
    "course_pipeline": {
        "any_of": ["transcript", "transcription", "course notes", "course-notes",
                   "markdown organize", "lecture notes"],
    },
    "deployment_vercel": {
        "all_groups": [["vercel"]],
        "context_terms": ["deploy", "deployment", "hosting", "preview"],
    },
    "deployment_netlify": {
        "all_groups": [["netlify"]],
        "context_terms": ["deploy", "deployment", "hosting"],
    },
    "github_ops": {
        "any_of": ["github", "pull request", "pull-request", "repository management",
                   "code review", "issue management"],
    },
}

# ==========================================================================
# 二、项目需求规则 NEED_RULE（需求侧真相源，读 SKILL_CONTEXT.md 的 needs 权重）
# ==========================================================================
# 与 CAP_RULE 分开的理由：CAP_RULE 决定「已装侧能力压制」，NEED_RULE 决定「是否命中
# 用户真实需求」。两侧混用会让「平台词」同时在两个方向放大误差。

# v2.4 §六：部署动词 + 部署对象。`hosting` / `hosted` 单独出现不算部署能力，
# 必须与「部署对象」（app / site / service / build / pages…）或 publish 同现。
# 事故：azure-microsoft-playwright-testing-ts 的 "cloud-hosted browsers" 被判 deploy。
_DEPLOY_OBJECTS = ["app", "application", "site", "website", "web app", "service", "pages",
                   "static", "build", "artifact", "deploy", "deployment", "publish",
                   "production", "environment"]
_DEPLOY_HOST_VERBS = ["hosting", "hosted", "publish", "publishing"]
_DEPLOY_ANY_GROUPS = [[v, o] for v in _DEPLOY_HOST_VERBS for o in _DEPLOY_OBJECTS]

# v2.4 §五：管理面 / 资源编排语境。这类 Skill 管理的是**测试基础设施**，
# 不是「执行浏览器测试」的能力 —— 不得据此判 browser-qa。
# （通用守卫，不是给 Playwright 打补丁：对任何管理面 SDK 都成立。）
_MGMT_PLANE_TERMS = ["management plane", "control plane", "resource manager",
                     "name availability", "workspace quota", "workspace quotas",
                     "provisioning api", "service quota", "management-plane"]

# v2.4 §十：排除性语境登记表。命中这些 none_of 词 = 「语义上被排除的假相关」，
# 计入 negated_evidence_rejected（与否定窗口同一口径），让审查者看得见门在工作。
_EXCLUSION_CONTEXT_TERMS = {t.lower() for t in _MGMT_PLANE_TERMS}

# ---------- v2.5 §一：android 需求 = 真正的「Android 真机 QA / 构建签名」 ----------
# §一 明令：禁止使用裸 device / build / install / launch 作 Android QA 正向证据
# （事故：google-mobile-ads-get-started 只是「接入广告 SDK」，install/integrate 就命中）。
_ANDROID_PLATFORM = ["android", "kotlin", "jetpack", "gradle", "安卓"]
_ANDROID_QA_DEVICE = [   # A. 测试 / 真机
    "qa", "test", "testing", "e2e", "adb", "emulator", "real device", "device farm",
    "appium", "detox", "maestro", "espresso", "xctest", "instrumentation test",
    "真机", "自动化测试"]
_ANDROID_BUILD_SIGN = [  # B. 构建 / 签名 / 安装验收
    "signing", "code signing", "keystore", "signed apk", "apk", "aab", "app bundle",
    "build verification", "build signing", "release build verification", "install apk",
    "app install verification", "app launch verification", "签名", "构建验收"]
# 只允许用来把等级降为 mention 的裸词（不作正向证据）
_ANDROID_BARE_TERMS = ["device", "devices", "build", "building", "install", "installation",
                       "launch", "verification", "release"]
# 广告语境的 "test ads"（拉取广告测试位）≠ QA 能力
_AD_TEST_RE = re.compile(r"\btest(?:ing|s)?\s+(?:the\s+|your\s+)?(?:live\s+)?ads?\b", re.I)


def _cls_android(ctx):
    """v2.5 §一 + §九：返回 (等级, 证据)。primary = 平台证据 AND（A 类 ∪ B 类）证据。"""
    plat = [k for k in _ANDROID_PLATFORM if hit_pos(ctx, k)]
    ev = sorted({k for k in _ANDROID_QA_DEVICE + _ANDROID_BUILD_SIGN if hit_pos(ctx, k)})
    if ev and set(ev) <= {"test", "testing"} and _AD_TEST_RE.search(ctx["ptext"]):
        ev = []     # 证据只剩「test ads」→ 广告语境，不是 QA
    if plat and ev:
        return "primary", sorted(set(plat + ev))
    if plat and (any(hit_pos(ctx, k) for k in _ANDROID_BARE_TERMS) or ev):
        return "mention", []    # 只有平台词 + 裸 install/build/launch 类词
    return None, []


def _rule_android(ctx):
    """NEED 命中 ⟺ primary（§九：mention 级 Android 内容不得命中 android QA 需求）。"""
    lvl, ev = _cls_android(ctx)
    return (lvl == "primary", ev)


# ---------- v2.5 §八：github-auto 必须「GitHub + 操作/自动化语义」 ----------
# 事故：breakdown-test 核心是 Test Planning，只因 `for GitHub projects` 命中 github-auto。
_GITHUB_PLATFORM = ["github", "github.com", "gh cli"]
_GITHUB_OPS = [
    "github actions", "workflow dispatch", "repository automation", "repo automation",
    "repo creation", "repository creation", "issue creation", "issue management",
    "issues", "issue", "pull request", "pull requests", "pr review", "pr automation",
    "code review", "release automation", "labels", "milestones", "repository sync",
    "commit automation", "github api", "自动建 issue", "自动创建 issue", "自动 pr", "仓库同步"]
GITHUB_AUTO_RULE = {"all_groups": [_GITHUB_PLATFORM, _GITHUB_OPS]}


def _cls_github_auto(ctx):
    ok, ev = match_rule(ctx, GITHUB_AUTO_RULE)
    if ok:
        return "primary", ev
    if hit_pos_any(ctx, _GITHUB_PLATFORM):
        return "mention", []   # §八：裸 GitHub / GitHub projects 不足以成立
    if hit_any(ctx["words"], ctx["text"], ctx["norm"], _GITHUB_PLATFORM) \
            and not hit_pos_any(ctx, _GITHUB_PLATFORM):
        return "negated", []
    return None, []


# ---------- deploy 规则常量化（v2.5 §九 需要单独给它定级） ----------
_DEPLOY_PUBLISH_VERBS = ["publish", "publishing"]
DEPLOY_RULE = {
    "any_of": ["deploy", "deployment", "deploying", "release pipeline",
               "deployment pipeline", "deploy pipeline", "publish pipeline",
               "static hosting", "site deployment", "部署上线", "上线部署", "部署流水线"],
    "any_groups": _DEPLOY_ANY_GROUPS,
    "context_terms": ["vercel", "netlify", "cloudflare pages", "ci", "cd", "ci-cd",
                      "ci cd", "continuous deployment", "continuous delivery",
                      "github actions", "pipeline", "hosting", "hosted"],
    "none_of": ["deployment manager", "oracle"],
}


def _cls_deploy(ctx):
    """v2.5 §九：deploy 动作词/publish+对象 = primary；仅「托管动词+对象」= supporting。"""
    ok, ev = match_rule(ctx, DEPLOY_RULE)
    prim = [k for k in DEPLOY_RULE["any_of"] if hit_pos(ctx, k)]
    if ok and prim:
        return "primary", sorted(set(prim))
    if ok:
        pub = any(hit_pos(ctx, v) and hit_pos(ctx, o)
                  for v in _DEPLOY_PUBLISH_VERBS for o in _DEPLOY_OBJECTS)
        return ("primary" if pub else "supporting"), ev
    dep_kw = ["deploy", "deployment", "deploying"]
    if hit_any(ctx["words"], ctx["text"], ctx["norm"], dep_kw) \
            and not hit_pos_any(ctx, dep_kw):
        return "negated", []
    return None, []

NEED_RULE = {
    # w=51（最高权重）：Agent / 多智能体治理与提示词工程
    "agent-governance": {"any_of": ["agent governance", "agent orchestration", "multi agent",
                                    "multi-agent", "orchestrator", "agent team", "agent teams",
                                    "skill manager", "guardrail", "guardrails", "prompt engineering",
                                    "prompt-engineering", "subagent", "sub-agent", "agent protocol",
                                    "智能体治理", "多智能体"]},
    # v2.2 收紧：真实需求是「Android 真机 QA / 构建签名」，不是「任何 Android 内容」
    # v2.5 §一 再收紧：必须是测试/真机（A 类）或构建/签名（B 类）证据；
    #   裸 device / build / install / launch 一律不作正向证据（Google Mobile Ads 接入事故）
    "android": {"custom": _rule_android,
                "context_terms": ["android", "kotlin"]},
    # v2.4 §五：管理面 SDK（如 Azure Resource Manager for Playwright Testing）只是
    # 「管理测试工作区」，不是浏览器测试能力 → 排除。
    "browser-qa": {"any_of": ["browser testing", "browser-testing", "playwright", "e2e",
                              "end to end testing", "acceptance test", "visual testing",
                              "visual regression", "cdp", "webapp testing", "web app testing",
                              "浏览器测试", "端到端测试"],
                   "none_of": _MGMT_PLANE_TERMS},
    "dashboard-viz": {"any_of": ["dashboard", "chart generation", "chart-generation",
                                 "data visualization", "data-visualization", "grafana",
                                 "plotting", "charts", "看板", "报表"]},
    "data-pipeline": {"any_of": ["etl", "data pipeline", "data-pipeline", "ingest",
                                 "data warehouse", "warehouse", "data ingestion"]},
    # v2.2 收紧：不再用裸 `release` 命中所有「发布」语境
    # v2.3 再收紧：Vercel / Netlify / CI-CD 只能作**语境**（context_terms），
    #   必须真的出现 deploy/hosting/release-pipeline 动作词才算「部署能力」。
    #   事故：react-best-practices 只因来自 Vercel、bats-testing-patterns 只因 CI/CD
    #   就被判成 deploy 能力。
    # v2.4 §六：再删裸 `hosted`；`hosting`/`hosted` 必须与部署对象同现（any_groups）。
    #   事故：azure-microsoft-playwright-testing-ts 的 "cloud-hosted browsers" + CI/CD。
    # v2.5 §二：`Don't use for ..., model deployment to endpoints` 里的 deployment
    #   现在被否定枚举整段压掉（agent-platform-prompt-management 假 deploy 事故）。
    "deploy": DEPLOY_RULE,
    # v2.2 收紧：不能因描述里写 "desktop application" 就命中，重点在打包/签名/发布
    "desktop-app": {"any_of": ["tauri", "electron", "menubar", "menu bar app", "native desktop",
                               "desktop packaging", "app packaging", "packaging", "code signing",
                               "notarization", "dmg", "nsis", "msix", "app bundle", "pkg installer",
                               "跨平台打包", "桌面应用打包"],
                    "context_terms": ["desktop", "native", "installer"]},
    "docker-infra": {"any_of": ["docker", "dockerfile", "docker compose", "containerize",
                                "containerization", "compose file", "容器化"]},
    "expo-rn": {"any_of": ["expo", "react native", "react-native", "expo router", "expo sdk",
                           "expo modules", "nativewind"]},
    "finance-calc": {"any_of": ["finance", "financial", "portfolio", "stock", "stocks", "etf",
                                "investment", "investing", "dividend", "valuation", "backtest",
                                "quantitative trading", "估值", "股息", "投资", "回撤"]},
    "frontend-design": {"any_of": ["frontend", "front-end", "front end", "web design",
                                   "web-design", "ui design", "ui-design", "ui/ux", "ux",
                                   "css", "tailwind", "shadcn", "design system", "responsive design",
                                   "visual design", "前端设计", "界面设计", "设计审查"]},
    # v2.5 §八：裸 GitHub / "for GitHub projects" 不足以命中，
    #   必须 GitHub + 操作/自动化语义（Actions / issue / PR / release automation…）
    "github-auto": GITHUB_AUTO_RULE,
    # v2.2 收紧：不再用裸 `prompt`；重点在 API/SDK/streaming/structured output/tool calling
    # v2.3 再收紧：必须 **LLM/model/provider 语境** AND **API/SDK/动作词**。
    #   单独的 "API" / "SDK integration" / "Gemini" 不足以证明这是 LLM 接入能力。
    #   事故：google-ads-api-mcp-setup（Google Ads API + Gemini）、
    #        google-mobile-ads-validate（Mobile Ads SDK）都被误判成 LLM API 集成。
    "llm-api": {"all_groups": [["llm", "large language model", "language model", "openai",
                                "anthropic", "claude api", "dashscope", "qwen", "deepseek",
                                "gemini", "model api", "chat completion", "chat completions",
                                "text generation model", "大模型", "模型接入"]],
                "any_of": ["api", "sdk", "api integration", "sdk integration", "tool calling",
                           "function calling", "structured output", "streaming response",
                           "streaming", "model inference", "inference endpoint", "endpoint",
                           "provider integration", "接入", "调用"],
                # 广告 / 投放语境即使出现 Gemini 也不是 LLM 接入能力
                "none_of": ["google ads", "mobile ads", "admob", "advertising", "ad manager",
                            "ads api", "search ads", "ad network", "prompt injection"],
                "context_terms": ["api", "sdk", "model", "llm"]},
    "media-transcribe": {"any_of": ["transcript", "transcription", "whisper", "asr", "subtitle",
                                    "subtitles", "speech to text", "speech-to-text", "voice to text",
                                    "视频转文字", "字幕"]},
    # v2.2 收紧：不要裸 photo/image，重点在 EXIF / gallery / album / library / metadata
    "photo-mgmt": {"any_of": ["exif", "gallery", "albums", "album management", "photo library",
                              "photo-library", "image library", "photo management",
                              "photo-management", "image management", "asset management",
                              "asset library", "metadata extraction", "lightroom",
                              "media library", "相册", "照片管理", "素材管理"],
                   "context_terms": ["photo", "image", "metadata"]},
    "privacy-local": {"any_of": ["local first", "local-first", "privacy", "privacy preserving",
                                 "encryption", "encrypt", "end to end encrypted", "self hosted",
                                 "self-hosted", "data sovereignty", "本地优先", "隐私"]},
    "pwa-offline": {"any_of": ["pwa", "progressive web app", "offline first", "offline-first",
                               "offline support", "service worker", "service-worker",
                               "web app manifest", "installable web app", "离线", "本地存储"]},
    # v2.2 新增组合条件：Python 平台词 + 自动化/脚本/数据处理动作词
    "python-auto": {"all_groups": [["python", "python3"]],
                    "any_of": ["automation", "automate", "scripting", "script", "scripts",
                               "data processing", "data-processing", "local workflow",
                               "batch processing", "cli tool", "cli", "pandas", "csv",
                               "file processing", "自动化", "数据处理"],
                    "context_terms": ["python"]},
    "responsive": {"any_of": ["responsive", "responsiveness", "mobile first", "mobile-first",
                              "breakpoint", "media query", "responsive layout", "响应式"]},
    "secret-safety": {"any_of": ["secret", "secrets", "credential", "credentials", "api key",
                                 "api-key", "apikey", "env var", "env-var", "environment variable",
                                 "keychain", "dotenv", "secret management", "密钥管理"]},
    "spec-driven": {"any_of": ["spec driven", "spec-driven", "specification", "specifications",
                               "prd", "requirements document", "design doc", "rfc"]},
    # v2.2 收紧：必须真 Supabase 语境或 RLS；普通 PostgreSQL 不算
    # v2.3 再收紧：裸 RLS 不算（Power BI 等也有 row-level security）→ 必须明确 supabase
    "supabase-db": {"all_groups": [["supabase"]],
                    "context_terms": ["rls", "row level security", "postgres", "postgresql",
                                      "migration", "database"]},
    "task-integration": {"any_of": ["ticktick", "dida", "dida365", "task management",
                                    "task-management", "todo", "to-do", "calendar", "reminder",
                                    "task automation", "任务管理", "日历"]},
    # v2.2 收紧：不再把纯 TTS 当语音输入
    # v2.3 再收紧：**「可以接受 voice dictation 作为输入材料」≠「提供语音输入能力」**。
    #   事故：github-issue-creator（"create issues from voice dictation or text"）被误判。
    "voice-input": {"all_groups": [["voice", "speech", "audio", "microphone", "麦克风",
                                    "语音", "听写"]],
                    "any_of": ["voice input", "voice-input", "speech recognition",
                               "speech-to-text", "speech to text", "stt", "dictation engine",
                               "dictation mode", "dictation support", "audio input",
                               "voice control", "voice command", "transcribe audio",
                               "语音输入", "语音识别", "语音转文字", "声音输入"],
                    "none_of": ["voice dictation as input", "accepts voice dictation",
                                "as input material", "as raw material", "text to speech only",
                                "tts only"],
                    "context_terms": ["voice", "speech", "audio"]},
}

# 平台错配：用户技术栈（SKILL_CONTEXT.md tech）里不存在的云/企业平台与语言。
# 命中即降权（不直接否决——仍可能含通用方法），但必须显式记录，便于人工复核。
MISMATCH_KW = ["azure", "google cloud", "gcp", "bigquery", "aws", "amazon web services",
               "salesforce", "airflow", "kubernetes", "k8s", "terraform", "oracle", "sap",
               "dynamics 365", "sharepoint", "databricks", "snowflake", "java", "c#", ".net",
               "dotnet", "asp.net", "csharp", "spring boot", "blazor"]

# v2.4 §九：把上表的词归入「平台域」，用于判断 penalty 能否被**真实项目**解除。
MISMATCH_DOMAIN = {
    "azure": "azure",
    "google cloud": "gcp", "gcp": "gcp", "bigquery": "gcp",
    "aws": "aws", "amazon web services": "aws",
    "salesforce": "salesforce", "airflow": "airflow",
    "kubernetes": "kubernetes", "k8s": "kubernetes", "terraform": "terraform",
    "oracle": "oracle", "sap": "sap",
    "dynamics 365": "microsoft-business", "sharepoint": "microsoft-business",
    "databricks": "databricks", "snowflake": "snowflake",
    "java": "java", "spring boot": "java",
    "c#": "dotnet", ".net": "dotnet", "dotnet": "dotnet", "asp.net": "dotnet",
    "csharp": "dotnet", "blazor": "dotnet",
}


def domain_mismatch(cand):
    """返回命中的错配平台列表（空 = 没错配）。"""
    words, text, norm = bag(cand.get("skill_name"), cand.get("description"))
    return [kw for kw in MISMATCH_KW if hit(words, text, norm, kw)]


def mismatch_domains(cand):
    """返回命中的错配**平台域**集合（§九 用域判断能否解除 penalty）。"""
    return sorted({MISMATCH_DOMAIN.get(t, t) for t in domain_mismatch(cand)})


def project_domains(project):
    """某个项目档案里明确使用的「错配平台域」（name / desc / tech 三处取并集）。

    §九 的解除条件 = 用户真实项目里明确出现该平台；没有证据使用该技术栈 →
    就不该占个人 Top。
    """
    blob = " ".join([project.get("name") or "", project.get("desc") or ""]
                    + list(project.get("tech") or [])).lower()
    words = set(_WORD_RE.findall(blob))
    norm = re.sub(r"\s+", " ", re.sub(r"[\-_/]+", " ", blob))
    doms = set()
    for kw in MISMATCH_KW:
        if hit(words, blob, norm, kw):
            doms.add(MISMATCH_DOMAIN.get(kw, kw))
    return doms


# ==========================================================================
# 三、能力标签 / 需求匹配的高层接口
# ==========================================================================
def capability_tags(cand):
    """把候选映射到已装侧的能力命名空间（用于能力缺口匹配）。"""
    return [cap for cap, _ in rule_hits(cand, CAP_RULE)]


# ---------- v2.5 §九：候选级「核心能力 vs 提及」统一登记 ----------
# 对易被「顺带提及」污染的能力/需求做四态分类：primary / supporting / mention / negated。
# 只有 primary 可拿完整 capability gap 分；supporting 上限 8；mention/negated 上限 2。
# 目的：以后不再靠手写黑名单修误报 —— 所有规则共用同一个「证据语境」概念。
EVIDENCE_CLASSIFIERS = {
    "android": _cls_android,
    "github-auto": _cls_github_auto,
    "deploy": _cls_deploy,
    "mcp_dev": _cls_mcp,
    "docx_xlsx": _cls_docx,
}
EVIDENCE_LEVELS = ("primary", "supporting", "mention", "negated")


def evidence_context(cand, ctx=None):
    """返回 {能力或需求键: 证据语境等级}，只记录本轮真实出现过的键。"""
    if ctx is None:
        ctx = _ctx(cand.get("skill_name"), cand.get("description"))
    out = {}
    for key, fn in EVIDENCE_CLASSIFIERS.items():
        lvl, _ev = fn(ctx)
        if lvl:
            out[key] = lvl
    return out


def matched_needs(cand, needs_meta):
    """返回命中的项目需求列表，按权重降序。

    needs_meta 来自 SKILL_CONTEXT.md 的 needs（{need: {"w": 权重, ...}}）；
    未在 NEED_RULE 里定义规则的需求会被跳过（保持证据驱动，不猜）。
    v2.5 §九：登记表里的需求附带 `evidence_level`（primary/supporting…），
    供评分层降权（supporting 只拿一半权重）。
    """
    ctx = _ctx(cand.get("skill_name"), cand.get("description"))
    out = []
    for need, ev in rule_hits(cand, NEED_RULE, ctx=ctx):
        meta = needs_meta.get(need)
        if not meta:
            continue
        entry = {"need": need, "weight": meta.get("w"), "evidence": ev[:6]}
        cls = EVIDENCE_CLASSIFIERS.get(need)
        if cls:
            lvl, _e = cls(ctx)
            entry["evidence_level"] = lvl or "primary"
        out.append(entry)
    out.sort(key=lambda n: -(n["weight"] or 0))
    return out


# ==========================================================================
# 四、项目级匹配：把「对我哪个项目有用」真正答成项目名
# ==========================================================================
# 数据源：SKILL_CONTEXT.md §2「当前活跃项目」，行格式：
#   - `repo-name` — 定位描述 — 技术栈1 / 技术栈2 — YYYY-MM-DD
# 设计原则：只做本地日报用途，不联网、不外传。
_PROJ_LINE_RE = re.compile(
    r"^-\s+`([^`]+)`\s+—\s+(.*?)\s+—\s+(.*?)\s+—\s+(\d{4}-\d{2}-\d{2})\s*$")

# 技术栈标签 → 候选侧关键词（含同义词/常见写法）
# v2.4 §一/§二：每条带 `tier`：
#   strong    —— 候选的**核心能力明确针对该技术栈**，可独立形成项目匹配
#   secondary —— 泛用技术（语言/通用框架/容器/脚本），**只能加分，不得单独成立**
TECH_MATCH = {
    "TypeScript": {"kw": ["typescript", "ts"], "label": "TypeScript", "w": 6,
                   "tier": "secondary"},
    "React": {"kw": ["react", "jsx", "tsx", "react hooks"], "label": "React", "w": 9,
              "tier": "secondary"},
    # v2.4 §二 不变式：strong tier 必须能**独立**成立 —— 归一化分 = w × 2，而
    # min_score 默认 20，故每个 strong 技术栈的 w 都必须 ≥ STRONG_TIER_MIN_W(=10)。
    # 事故：Next.js 原为 9（归一化 18）→ 「Next.js 专项 Skill ↔ Next.js 项目」这条
    # §一 明确写下的强证据永远无法独立成立，tier 只剩装饰性。
    "Next.js": {"kw": ["next.js", "nextjs", "next js", "app router"], "label": "Next.js",
                "w": 12, "tier": "strong"},
    "PWA": {"kw": ["pwa", "progressive web app", "web app manifest", "installable web app",
                   "service worker", "service-worker"], "label": "PWA", "w": 14,
            "tier": "strong"},
    "离线与本地存储": {"kw": ["offline", "localstorage", "local storage", "indexeddb",
                              "service worker", "cache api"], "label": "离线/本地存储", "w": 13,
                       "tier": "strong"},
    "Supabase": {"kw": ["supabase"], "label": "Supabase", "w": 16, "tier": "strong"},
    "Postgres": {"kw": ["postgres", "postgresql", "psql", "pgvector"], "label": "Postgres",
                 "w": 12, "tier": "strong"},
    "Python": {"kw": ["python", "python3"], "label": "Python", "w": 8, "tier": "secondary"},
    # v2.4 §三：删掉裸 `container`（`container queries` 被误当 Docker）。
    # Docker 只认容器化语境词。
    "Docker": {"kw": ["docker", "dockerfile", "docker compose", "containerization",
                      "container image", "container runtime", "docker container", "容器化"],
               "label": "Docker", "w": 12, "tier": "secondary"},
    "自托管": {"kw": ["self hosted", "self-hosted", "selfhost", "homelab"], "label": "自托管",
               "w": 10, "tier": "secondary"},
    "Expo": {"kw": ["expo", "expo router", "expo sdk"], "label": "Expo", "w": 16,
             "tier": "strong"},
    "React Native": {"kw": ["react native", "react-native", "nativewind"], "label": "React Native",
                     "w": 16, "tier": "strong"},
    "Android": {"kw": ["android", "adb", "emulator", "apk", "aab", "gradle"], "label": "Android",
                "w": 15, "tier": "strong"},
    "Kotlin": {"kw": ["kotlin", "jetpack compose"], "label": "Kotlin", "w": 12, "tier": "strong"},
    # v2.3 §六：去掉裸 "macos" —— 「支持在 macOS 上运行」不等于「提供 macOS 桌面开发能力」。
    "macOS 桌面": {"kw": ["appkit", "cocoa", "swiftui", "menubar", "menu bar app", "swift",
                          "菜单栏应用", "macos app", "macos application"],
                   "label": "macOS 桌面", "w": 13, "tier": "strong"},
    "原生": {"kw": ["native app", "native desktop", "swift", "objective-c"], "label": "原生",
             "w": 10, "tier": "strong"},
    # v2.4：去掉泛用的 "api integration"，只认真正的模型/供应商词（否则「任何 API」都算 LLM 接入）
    "LLM API": {"kw": ["llm", "openai", "anthropic", "dashscope", "qwen", "deepseek", "gemini",
                       "chat completion", "model api", "dashscope api", "inference endpoint"],
                "label": "LLM API 接入", "w": 14, "tier": "strong"},
    "Tailwind": {"kw": ["tailwind", "shadcn"], "label": "Tailwind", "w": 8, "tier": "secondary"},
    "shadcn": {"kw": ["shadcn", "radix ui"], "label": "shadcn", "w": 7, "tier": "secondary"},
    "单文件 HTML 工具": {"kw": ["single html", "single-file html", "standalone html",
                                "single page html", "vanilla html"],
                         "label": "单文件 HTML", "w": 10, "tier": "secondary"},
    "Playwright": {"kw": ["playwright", "cypress", "puppeteer", "selenium"],
                   "label": "Playwright", "w": 12, "tier": "strong"},
    "Shell": {"kw": ["shell", "bash", "zsh", "command line", "cli script"], "label": "Shell",
              "w": 8, "tier": "secondary"},
    "Cloudflare": {"kw": ["cloudflare", "workers", "cloudflare pages"], "label": "Cloudflare",
                   "w": 10, "tier": "strong"},
    "Vercel": {"kw": ["vercel"], "label": "Vercel", "w": 11, "tier": "strong"},
    "Netlify": {"kw": ["netlify"], "label": "Netlify", "w": 11, "tier": "strong"},
    "CF Pages": {"kw": ["cloudflare pages", "pages functions"], "label": "CF Pages", "w": 10,
                 "tier": "strong"},
    ".NET": {"kw": ["dotnet", ".net", "csharp", "c#", "wpf", "winui"], "label": ".NET", "w": 10,
             "tier": "strong"},
    "C#": {"kw": ["csharp", "c#"], "label": "C#", "w": 10, "tier": "strong"},
}

# v2.4 §二 不变式守卫：strong = 「候选核心能力明确针对该技术栈，可独立形成项目匹配」。
# 归一化分 = 原始分 × 2，需 ≥ min_score（默认 20）→ strong 技术的 w 必须 ≥ 10。
# 这里做一次兜底抬升：新增 strong 技术栈时即使忘记配权重，也不会出现「名义 strong、
# 实际永远无法独立成立」的假分级。
STRONG_TIER_MIN_W = 10
for _tname, _trule in TECH_MATCH.items():
    if _trule.get("tier") == "strong" and _trule["w"] < STRONG_TIER_MIN_W:
        _trule["w"] = STRONG_TIER_MIN_W

# 描述文本里的「事实关键词」→ 加权（用于描述层面重叠，弥补技术栈标签不全）
DESC_SIGNALS = {
    "打卡": {"kw": ["check in", "checkin", "打卡", "visit log"], "label": "打卡记录", "w": 6},
    "看板": {"kw": ["dashboard", "看板"], "label": "看板", "w": 9},
    "报告": {"kw": ["report", "报告"], "label": "报告生成", "w": 8},
    "离线": {"kw": ["offline", "离线"], "label": "离线可用", "w": 10},
    "测试": {"kw": ["test", "testing", "测试"], "label": "测试验证", "w": 8},
    "部署": {"kw": ["deploy", "deployment", "部署"], "label": "部署上线", "w": 9},
}


# 技术栈标签 → 项目类型（对应 SKILL_CONTEXT.md §1「当前主要开发类型」）
TECH_TYPE = {
    "PWA": "Web/PWA", "React": "Web/PWA", "Next.js": "Web/PWA", "TypeScript": "Web/PWA",
    "Tailwind": "Web/PWA", "shadcn": "Web/PWA", "单文件 HTML 工具": "Web/PWA",
    "离线与本地存储": "Web/PWA",
    "Expo": "Expo/RN", "React Native": "Expo/RN",
    "Android": "Android", "Kotlin": "Android",
    "macOS 桌面": "macOS 桌面", "原生": "macOS 桌面",
    ".NET": ".NET/Windows 桌面", "C#": ".NET/Windows 桌面",
    "Python": "Python 自动化", "Shell": "Shell/脚本",
    "LLM API": "AI/Agent 工具",
    "Supabase": "数据库/Supabase", "Postgres": "数据库/Supabase",
    "Docker": "部署/基础设施", "自托管": "部署/基础设施", "Vercel": "部署/基础设施",
    "Netlify": "部署/基础设施", "Cloudflare": "部署/基础设施", "CF Pages": "部署/基础设施",
}

# 候选能力 → 它真正能服务的项目类型
CAP_TYPE = {
    "browser_automation": ["Web/PWA"],
    "testing_qa": ["Web/PWA"],
    "frontend_design": ["Web/PWA"],
    "image_creative": ["Web/PWA"],
    "data_analytics": ["Python 自动化", "AI/Agent 工具"],
    "security_audit": ["Web/PWA", "部署/基础设施"],
    "mobile_qa": ["Expo/RN", "Android"],
    "mobile_dev": ["Expo/RN", "Android"],
    "expo_rn_dev": ["Expo/RN"],
    "supabase_db": ["数据库/Supabase"],
    "postgres_db": ["数据库/Supabase"],
    "deployment_vercel": ["部署/基础设施"],
    "deployment_netlify": ["部署/基础设施"],
    "mcp_dev": ["AI/Agent 工具"],
    "github_ops": ["AI/Agent 工具", "部署/基础设施"],
    "macos": ["macOS 桌面"],
    "windows": [".NET/Windows 桌面"],
    "docx_xlsx": ["Python 自动化"],
    "course_pipeline": ["Python 自动化"],
}
TYPE_W = 10            # 类型适用降为 **secondary boost**，不单独产生 matched_project
TYPE_BOOST = TYPE_W
SECONDARY_BOOST = 3.0  # v2.4 §二：secondary 技术栈只加这点分，绝不单独让项目入选
DIRECT_EVIDENCE_KINDS = ("strong_tech", "positioning", "shared_need", "lexical")
DIRECT_EVIDENCE_LABEL = {
    "strong_tech": "项目技术栈直接命中（专用技术栈）",
    "positioning": "项目定位/功能语义直接命中",
    "shared_need": "项目自身需求与候选能力直接命中",
    "lexical": "项目定位与候选描述词面直接重叠",
}

# v2.4 §四：词面重叠时忽略的「无区分度词」。
# 事故：Azure Resource Manager Skill 与 `prompt-manager` 只因共有 `manager` 就成立。
_LEXICAL_STOP = {
    # 平台 / 设备泛词（v2.3 加入）
    "macos", "windows", "linux", "android", "ios", "unix", "darwin",
    "platform", "platforms", "device", "devices", "phone", "phones",
    "support", "supports", "using", "based", "guide", "guides",
    "skill", "skills", "tool", "tools", "workflow", "workflows",
    "project", "projects", "local", "remote", "files", "python",
    # v2.4 §四 明确点名的泛词
    "manager", "management", "resource", "service", "services",
    "application", "applications", "system", "systems",
    "development", "developer", "testing", "test", "tests",
    "data", "model", "models", "client", "server", "api", "apis",
    "code", "library", "framework", "integration", "automation",
    "content", "output", "input", "value", "values", "level", "process",
    # v2.5 §三/§五：裸 prompt 是「触发说明」里的偶然词（"the prompt names Claude…"），
    #   不是项目域证据；prompt 类语义必须走 _PROJECT_DOMAIN_PHRASES 的明确短语
    "prompt", "prompts",
}
# v2.4 §四：明确的项目域高信号词。
# v2.5 §四 收缩：**技术栈词不得再出现在这一层**（它们由 STRONG/SECONDARY_TECH 负责，
#   在 lexical 重复计一遍就是双重加分）；`prompt`/`prompts` 也被移除（§三 事故）。
#   本集合的词现在只作为「词级加分」的组成部分，**不再单独成立**（§五）。
_LEXICAL_HIGH_SIGNAL = {
    "insurance", "rss", "transcription", "transcribe", "whisper",
    "podcast", "subtitle", "subtitles", "obsidian", "valuation", "dividend", "portfolio",
    "backtest", "tauri", "electron", "journal",
    "photography", "invoice", "ledger", "checkin", "exif",
}

# v2.5 §四：技术泛词禁令表 —— lexical 层一律不得使用。
# 前一部分是 §四 点名的清单；后一部分自动并入 TECH_MATCH 的全部词
# （react native / supabase / playwright / expo… 归 strong/secondary tech 管）。
_LEXICAL_TECH_BAN = {
    "react", "native", "javascript", "typescript", "python", "css", "html",
    "tailwind", "next", "nextjs", "android", "kotlin", "expo", "mobile",
    "web", "api", "sdk", "model", "cloud",
}
for _trule in TECH_MATCH.values():
    for _kw in _trule["kw"]:
        _LEXICAL_TECH_BAN.update(w for w in re.split(r"[\s\-_/]+", _kw.lower()) if w)
_LEXICAL_TECH_BAN.discard("container")   # 不是技术栈词，留给区分度判定


# v2.5 §四/§五：唯一允许「单独成立」的词面证据 = 明确登记过的**项目域短语**。
# 单个泛词/裸 prompt/技术栈词一律不再直接产生 matched_project；
# 词级重叠（≥2 个高区分度词）只能在已有 strong_tech/positioning/shared_need 时作加分。
# 维护方式：新增项目领域时在此登记（本层只服务本机个性化，不外传）。
_PROJECT_DOMAIN_PHRASES = {
    "prompt-manager": ["prompt management", "prompt manager", "managed prompts",
                       "prompt library", "prompt versioning", "prompt repository",
                       "prompt engineering workflow", "prompt template management",
                       "提示词管理", "提示词版本", "提示词库", "提示词模板"],
    "personal-rss": ["rss feed", "rss feeds", "rss aggregation", "rsshub", "freshrss",
                     "rss订阅", "rss 订阅", "rss聚合"],
    "place-journal": ["place checkin", "check-in log", "地点打卡", "打卡记录"],
    "family-insurance-dashboard": ["insurance", "insurance policy", "insurance claim", "保单"],
    "photo-library": ["photo library", "photography portfolio", "摄影作品", "照片管理"],
    "photo-spot-app": ["photo scouting", "shot list", "约拍", "机位"],
    "Video2Obsidian-Mac": ["obsidian", "video transcription", "视频转文字", "whisper"],
    "Video2Obsidian-Windows": ["obsidian", "video transcription", "视频转文字", "whisper"],
    "a-share-index-valuation-report": ["valuation", "index valuation", "估值", "市盈率"],
    "hongli-dixin-calc": ["dividend", "股息", "红利", "a-share", "a股"],
    "pepe-doge-breakout-radar-deepseek-v4-pro": ["backtest", "quantitative trading",
                                                 "breakout", "量化", "回撤"],
    "roll-position-calculator": ["position sizing", "滚仓", "盈亏台账", "杠杆"],
    "landedazi-android": ["voice translation", "语音整理", "口语", "方言"],
    "alw-db-governance": ["database governance", "数据库治理", "接入规范"],
    "github-projects-profile": ["github profile", "repository portfolio", "项目档案",
                                "仓库档案"],
}

# 命中的**项目需求** → 它能服务的项目类型。
NEED_TYPE = {
    "agent-governance": ["AI/Agent 工具"],
    "android": ["Android"],
    "browser-qa": ["Web/PWA"],
    "dashboard-viz": ["Web/PWA", "Python 自动化"],
    "data-pipeline": ["Python 自动化", "部署/基础设施"],
    "deploy": ["部署/基础设施"],
    "desktop-app": ["macOS 桌面", ".NET/Windows 桌面"],
    "docker-infra": ["部署/基础设施"],
    "expo-rn": ["Expo/RN"],
    "finance-calc": ["Web/PWA", "Python 自动化"],
    "frontend-design": ["Web/PWA"],
    "github-auto": ["AI/Agent 工具", "部署/基础设施"],
    "llm-api": ["AI/Agent 工具", "Web/PWA"],
    "media-transcribe": ["Python 自动化"],
    "photo-mgmt": ["Web/PWA", "Expo/RN"],
    "privacy-local": ["Web/PWA"],
    "pwa-offline": ["Web/PWA"],
    "python-auto": ["Python 自动化"],
    "responsive": ["Web/PWA"],
    "secret-safety": ["部署/基础设施"],
    "spec-driven": ["AI/Agent 工具"],
    "supabase-db": ["数据库/Supabase"],
    "task-integration": ["AI/Agent 工具"],
    "voice-input": ["Expo/RN", "Android"],
}


def load_projects(context_text):
    """从 SKILL_CONTEXT.md 文本解析「当前活跃项目」。返回 [{name, desc, tech[], date}]。"""
    projects = []
    in_section = False
    for line in (context_text or "").split("\n"):
        if line.startswith("## 2."):
            in_section = True
            continue
        if in_section and line.startswith("## 3."):
            break
        if not in_section:
            continue
        m = _PROJ_LINE_RE.match(line)
        if not m:
            continue
        name, desc, tech, date = m.groups()
        techs = [t.strip() for t in re.split(r"[/／、,，]", tech) if t.strip()]
        projects.append({"name": name.strip(), "desc": desc.strip(),
                         "tech": techs, "date": date.strip(),
                         "is_placeholder": desc.strip() in ("(无描述)", "")})
    return projects


def match_projects(cand, projects, limit=5, min_score=20):
    """为候选匹配最相关的项目，返回 [{project, evidence, direct_evidence, match_score}]。

    v2.3（§一 / §六）：**禁止「项目类型适用」单独制造项目匹配** —— 必须有直接证据。

    v2.4（§一/§二/§三/§四/§十）：把「直接证据」本身再分级。
      ① strong_tech   候选核心能力明确针对该技术栈（Expo / RN / Android / Supabase /
                      Next.js / PWA / Vercel / .NET…），可独立成立
      ② positioning   候选任务与项目定位/功能语义直接命中
      ③ shared_need   项目自身需求与候选能力直接命中
      ④ lexical（v2.5 §三/§四/§五 重构）
                      —— 只有两类形态：登记过的「项目域短语」可单独成立；
                         词级重叠（≥2 个高区分度词）必须有 ①②③ 任一类共同存在、只作加分。
                      技术泛词与裸 prompt 一律不得参与词面证据（react/native/python/… 归
                      STRONG/SECONDARY_TECH 负责，不在 lexical 层重复计分）。
                      事故：react-view-transitions 凭 `native-feeling`+React 匹配了
                      React Native 项目；claude-api / breakdown-test 凭触发说明里的裸
                      `prompt` 匹配了 prompt-manager。
      · secondary 技术栈（TypeScript / React / Python / Docker / Shell / HTML / CSS…）
        **只加 SECONDARY_BOOST 分，绝不单独让项目进 matched_projects**
      事故：azure-microsoft-playwright-testing-ts 仅因描述里有 TypeScript 就匹配了 5 个
      普通 TS 项目；responsive-design 因 `container queries` 被当成 Docker 匹配 3 个 Docker 项目。
    四者皆无 → **不产生 matched_project**（宁可空，也不给「类型像」的假匹配）。
    「同属 Web/PWA / Android / macOS」只作 secondary boost。
    """
    ctx = _ctx(cand.get("skill_name"), cand.get("description"))
    cand_types = set()
    for cap in capability_tags(cand):
        cand_types |= set(CAP_TYPE.get(cap, []))
    cand_needs = {need for need, _ev in rule_hits(cand, NEED_RULE)}
    for need in cand_needs:
        cand_types |= set(NEED_TYPE.get(need, []))
    kept = []
    secondary_only_hit = False
    for p in projects:
        hits, score, direct = [], 0.0, []
        secondary_labels = []
        pwords, ptext, pnorm = bag(p["name"], p["desc"])
        # ① 直接证据：候选能力 ↔ 项目明确技术栈（v2.4：分 strong / secondary）
        for t in p["tech"]:
            rule = TECH_MATCH.get(t)
            if not rule:
                continue
            if not hit_any(ctx["words"], ctx["text"], ctx["norm"], rule["kw"]):
                continue
            if rule.get("tier") == "strong":
                hits.append(rule["label"])
                score += rule["w"]
                direct.append(("strong_tech", rule["label"]))
            else:
                secondary_labels.append(rule["label"])
                score += SECONDARY_BOOST
        # ② 直接证据：候选任务 ↔ 项目定位/功能语义
        for _, sig in DESC_SIGNALS.items():
            if hit_any(pwords, ptext, pnorm, sig["kw"]) and \
                    hit_any(ctx["words"], ctx["text"], ctx["norm"], sig["kw"]):
                hits.append(sig["label"])
                score += sig["w"]
                direct.append(("positioning", sig["label"]))
        # ③ 直接证据：项目自身需求 ↔ 候选能力
        p_needs = {need for need, _e in rule_hits(
            {"skill_name": p["name"], "description": p["desc"]}, NEED_RULE)}
        shared_needs = cand_needs & p_needs
        if shared_needs:
            score += min(12, 6 * len(shared_needs))
            direct.append(("shared_need", "/".join(sorted(shared_needs)[:3])))
        # ④ 词面证据（v2.5 §三/§四/§五 重构）：
        #   (a) 明确登记过的「项目域短语」命中 → 可单独成立（phrase 级）
        #   (b) 词级重叠（≥2 个高区分度词）→ **只作加分**，必须与 ①②③ 至少一类共同存在；
        #       技术泛词（react/native/python…，归 TECH_MATCH 管）与 stop 词一律不参与
        #   单独的高信号词 / 裸 prompt / 单个泛词 → 不再产生 matched_project。
        phrases = _PROJECT_DOMAIN_PHRASES.get(p["name"]) or []
        ph_hit = [ph for ph in phrases if hit_pos(ctx, ph)]
        if ph_hit:
            for _ph in ph_hit:
                _ws = set(re.split(r"[\s\-_/]+", _ph))
                if _ws <= {"prompt", "prompts"}:
                    QUALITY["bare_prompt_direct_evidence"] += 1     # 防御性哨兵，必须恒 0
                if _ws & _LEXICAL_TECH_BAN:
                    QUALITY["tech_words_used_as_lexical_direct_evidence"] += 1
            score += min(14, 12 + 2 * (len(ph_hit) - 1))
            direct.append(("lexical", "领域短语：" + "/".join(ph_hit[:2])))
            QUALITY["lexical_phrase_direct_evidence"] += 1
        else:
            overlap = ctx["pwords"] & pwords
            boost = sorted(
                w for w in overlap
                if len(w) >= 5 and w not in _LEXICAL_STOP and w not in _LEXICAL_TECH_BAN)
            if len(boost) >= 2:
                if direct:      # 已有主证据 → 词级重叠只加分（§五）
                    score += min(10, 4 + 2 * len(boost))
                    direct.append(("lexical", "词面重叠（次要加分）：" + "/".join(boost[:3])))
                else:           # 词级重叠想单独成立 → 拒绝（v2.5 §五：准确率优先）
                    QUALITY["lexical_alone_rejected"] += 1
                    QUALITY["lexical_single_rejected"] += 1
            elif boost or overlap:
                # 单个普通词重叠（或只靠 manager/service/resource 这类无区分度词）→ 不足以成立
                QUALITY["lexical_single_rejected"] += 1
        if not direct:
            if secondary_labels:
                secondary_only_hit = True
            continue      # ← v2.3/v2.4 核心：无直接证据 → 不产生匹配
        if secondary_labels:
            hits.append("类型/泛用技术（次要）：" + "/".join(sorted(set(secondary_labels))))
        # secondary boost：类型适用只加分，不能单独让项目进 matched_projects
        ptypes = {TECH_TYPE.get(t) for t in p["tech"]} - {None}
        shared = cand_types & ptypes
        if shared:
            score += TYPE_BOOST
            hits.append("类型适用（次要）：" + "/".join(sorted(shared)))
        norm_score = min(96, int(round(score * 2.0)))   # 归一化到 0~96
        if norm_score < min_score:
            continue
        kinds = sorted({k for k, _ in direct})
        kept.append(({"project": p["name"],
                      "positioning": p["desc"][:90],
                      "evidence": hits[:6] or ["技术栈词面重叠"],
                      "direct_evidence": [f"{DIRECT_EVIDENCE_LABEL[k]}：{v}"
                                          for k, v in direct][:4],
                      "direct_evidence_kinds": kinds,
                      "project_domains": sorted(project_domains(p)),
                      "match_score": norm_score}, kinds))
    # 同分时保持 projects 的原序（SKILL_CONTEXT.md §2 已按活跃日期降序）→ 活跃项目优先
    kept.sort(key=lambda x: -x[0]["match_score"])
    kept = kept[:limit]
    if not kept and secondary_only_hit:
        # 本可靠泛用技术栈（TypeScript / Docker…）硬凑进来，现已拒绝（v2.4 §二）
        QUALITY["secondary_tech_only_rejected"] += 1
    for entry, kinds in kept:
        for k in kinds:
            QUALITY[_KIND_TO_COUNT[k]] += 1
    if kept:
        QUALITY["matched_candidates"] += 1
    return [e for e, _ in kept]
