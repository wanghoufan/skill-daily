# -*- coding: utf-8 -*-
"""候选标准化 → 合法性 Gate → canonical 去重 → 安装关系 → 能力缺口匹配
   → Security Gate v2（两阶段）→ 个性化评分 → SKILL_CANDIDATES.json

v2.2 相对 v2.1 的改动（见 HANDOFF / 整改提示词）：
  1. 合法性 Gate：ClawHub 之类聚合源的前端构建产物（.css/.js/.map/图片/字体、
     assets|static|build|dist 路径）不得进入正式候选池；错误条目只留在 raw discovery。
  2. bottom-up 搜索只是 discovery_channel，**不再等于 TIER 2**；必须过
     「存在真实 SKILL.md + 可定位 skill directory + frontmatter 可解析」硬门，
     且未在注册表验证过的来源一律 source_tier=null(unverified)、信任取最低档。
  3. 语义匹配升级为 MATCH_RULE（见 match_rules.py）：组间 AND / 组内 OR，
     杜绝「出现平台词 = 满足能力需求」的误判。
  4. matched_projects：真正回答「对我哪个项目有用」。
  5. Security Gate v2：区分「提到危险行为」与「真要求执行」。
  6. 两阶段审查：install 候选必须完成 PASS 2 深度静态审查。

v2.4（本轮）只修「项目相关性 / testing_qa 误标 / domain mismatch」：
  7. 项目匹配的直接证据分级（strong_tech / positioning / shared_need / lexical），
     泛用技术栈（TypeScript / React / Python / Docker / Shell / HTML / CSS）只能作
     secondary boost，不得单独产生 matched_project。见 match_rules.TECH_MATCH 的 tier。
  8. 平台错配（§九）真正参与排序：未解除的错配 → 总分 × DOMAIN_MISMATCH_PENALTY、
     不得 install_candidate、不得进 Personalized Top；真实项目使用该平台时自动解除。
  9. 输出 PROJECT_MATCH_QUALITY（按证据类型分列 + 被拒绝的假相关计数），
     取代旧的「351/351 字段非空率」式指标。

v2.5（本轮，冻结前最后整改）只修「剩余语义误判」，不重做 v2.4 架构：
  10. android 需求 = 平台证据 AND **真实 QA 证据**（A 表：qa/e2e/adb/emulator/真机…；
      B 表：signing/keystore/apk/aab/构建验收…），裸 device/build/install/launch 不算。
  11. 否定窗口升级为**两段式**：先按句点/分号/换行切大句，逗号仅在段内传播否定状态，
      遇到 but/however/但/可用于… 才恢复正向 —— 修掉 v2.4 逗号把 B、C 洗回正向的事故。
  12. 词面证据（lexical）不再凭泛用技术词或裸 prompt 成立：技术词全禁，
      单词面只做 boost，独立成立仅限**人工整理的领域短语**。
  13. mcp_dev / docx_xlsx / github-auto / deploy / android 统一走
      `capability_evidence_context` 四态（primary/supporting/mention/negated）：
      只有 primary 拿满缺口分，supporting 上限 8、mention/negated 上限 2；
      需求侧 supporting 权重 ×0.5。PPTX 归独立标签 pptx_processing，不冒充 docx_xlsx。
"""
import json, re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (load_json, save_json, load_installed, canonical_key, fingerprint,
                    fetch_text, fetch_cached, load_config, RAW, CANDIDATES_PATH,
                    REGISTRY_PATH, SKILL_CONTEXT_PATH, TODAY)
import match_rules as MR
from match_rules import bag, hit_any, load_projects, match_projects
from security_gate import security_scan, deep_scan, deep_scan_summary, repo_tree
from data_gate import is_artifact_entry, is_valid_skill_name, has_min_fm

MAX_SECURITY_FETCH = 600  # PASS 1 静态审查 SKILL.md 的抓取上限（raw.githubusercontent，不计 API 配额）

# ==========================================================================
# 一、合法性 Gate（规则实现见 data_gate.py —— discover 与 analyze 共用同一套判断）
# ==========================================================================
_verify_cache = {}


def verify_bottom_up(owner, repo, branch="main"):
    """bottom-up 仓库硬门校验（§一.2）。

    返回 dict：
      ok=True  → 定位到真实 SKILL.md（含目录与文本）
      ok=False → 确认不是 Skill（无 SKILL.md），不得进正式候选池
      ok=None  → 无法校验（文件树/网络不可用），隔离处理
    """
    k = f"{owner}/{repo}"
    if k in _verify_cache:
        return _verify_cache[k]
    paths = repo_tree(owner, repo, branch)
    if paths is None and branch == "main":
        paths = repo_tree(owner, repo, "master")
        if paths is not None:
            branch = "master"
    if paths is None:
        res = {"ok": None, "reason": "file_tree_unavailable", "branch": branch}
        _verify_cache[k] = res
        return res
    skill_mds = [p for p in paths if p.endswith("SKILL.md")]
    if not skill_mds:
        res = {"ok": False, "reason": "no_skill_md", "branch": branch}
        _verify_cache[k] = res
        return res
    # 优先取根 SKILL.md，否则取路径最短的
    skill_mds.sort(key=lambda p: (p.count("/"), len(p)))
    p = skill_mds[0]
    txt = fetch_cached(f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{p}", timeout=12)
    res = {"ok": True, "skill_md": p, "dir": os.path.dirname(p), "branch": branch,
           "fm_ok": has_min_fm(txt),
           "skill_name": os.path.basename(os.path.dirname(p)) or repo}
    _verify_cache[k] = res
    return res


# ---------- 安装关系 ----------
STRONG_TOKENS = {"claude", "skill", "agent"}


def _tokens(s):
    return {t for t in re.split(r"[\s_\-/]+", (s or "").lower())
            if len(t) > 2 and t not in STRONG_TOKENS}


def installed_relationship(cand, installed):
    cname = cand["skill_name"].lower().replace("-", " ")
    ctokens = _tokens(cand["skill_name"] + " " + cand.get("description", ""))
    best, best_j = None, 0.0
    for n, e in installed.items():
        nlow = n.lower().replace("-", " ")
        if cname == nlow:
            return "already_installed", n, 1.0
        j = len(ctokens & _tokens(n + " " + (e.get("description") or "")))
        union = len(ctokens | _tokens(n + " " + (e.get("description") or ""))) or 1
        score = j / union
        if score > best_j:
            best, best_j = n, score
    if best_j >= 0.55:
        return "near_duplicate", best, best_j
    if best_j >= 0.30:
        return "overlap", best, best_j
    if best_j >= 0.15:
        return "complement", best, best_j
    return "new_capability", None, best_j


# ---------- 能力缺口匹配 ----------
def capability_tags(cand):
    """候选 → 已装侧能力命名空间（CAP_RULE，见 match_rules.py）。"""
    return MR.capability_tags(cand)


def domain_mismatch(cand):
    return MR.domain_mismatch(cand)


# v2.4 §九：平台错配的「解除」判定。
#   命中错配平台 且 没有任何 matched_project 明确使用该平台 → penalty（不得进安装候选、
#   不得进 Personalized Top、总分显著降权）。
#   一旦用户真实项目里出现该平台（或候选匹配到的项目就是该平台的项目）→ 自动解除。
#   不做永久 blacklist：只是「当前没有证据使用该技术栈 → 不该占个人 Top」。
DOMAIN_MISMATCH_PENALTY = 0.7    # 未解除错配时的总分成乘数（显著 penalty）


def unresolved_mismatch(gm):
    """取「未解除的平台错配」；老数据没有该字段时退回 domain_mismatch（向后兼容）。"""
    if gm is None:
        return []
    if "domain_mismatch_unresolved" in gm:
        return gm.get("domain_mismatch_unresolved") or []
    return gm.get("domain_mismatch") or []


def gap_match(cand, inst, config):
    """能力缺口 + 真实需求匹配（需求侧走 NEED_RULE）。"""
    tags = cand["capability_tags"]
    gaps = inst["suppression"]
    avail = inst["availability"]
    rank = {"none": 4, "weak": 3, "medium": 2, "strong": 1}
    best_eff, best_cap, best_r = None, None, 0
    for cap in tags:
        lv = gaps.get(cap)
        if lv is None:
            continue
        av = avail.get(cap, {}).get("availability", "ok")
        if lv == "strong" and av == "degraded":
            # coverage=strong 但 availability=degraded → 不按正常 strong 压制，按恢复需求计 medium
            eff, r = "medium", 2
        else:
            eff, r = lv, rank[lv]
        if r > best_r:
            best_r, best_eff, best_cap = r, eff, cap
    if best_cap is None:
        best_eff, best_cap = "strong", None   # 未命中任何已登记能力 → 无缺口证据
    matched = MR.matched_needs(cand, config.get("_project_needs", {}))
    return {"capability_tags": tags, "gap_level": best_eff, "matched_gap": best_cap,
            "matched_needs": matched,
            # v2.5 §九：统一「证据语境」四态字段（primary/supporting/mention/negated）
            "capability_evidence_context": MR.evidence_context(cand),
            "domain_mismatch": domain_mismatch(cand),
            "need_evidence": bool(matched)}


# ---------- 评分 ----------
SCORE_KEYS = ["PROJECT_MATCH", "CAPABILITY_GAP", "SOURCE_TRUST", "SECURITY",
              "MAINTENANCE", "ADOPTION_TREND", "DETOUR_REDUCTION", "NOVELTY_VS_INSTALLED"]


def score_candidate(c, W, tiers_trust):
    """Security Gate 优先于分数：block 级 → 0 分（后续 reject）。"""
    sec = c["security"]
    if sec.get("verdict") == "block" or sec.get("risk_level") == "high":
        c["gates_failed"] = True
        c["scores"] = {k.lower(): 0 for k in SCORE_KEYS}
        c["scores"]["total"] = 0
        return 0
    gm = c["capability_gap_match"]
    ne = gm.get("need_evidence", bool(gm.get("matched_needs")))
    pts = {}
    # PROJECT_MATCH 25：命中 SKILL_CONTEXT.md 的真实需求权重后归一化（wsum/2.6）。
    # 无需求证据 → 0 分（不给「有标签就送分」的噪音奖励）。
    # v2.5 §九：supporting 级证据只拿一半权重（如「可与 MCP 使用」≠ MCP 开发能力）。
    wsum = sum((n["weight"] or 0) * (0.5 if n.get("evidence_level") == "supporting" else 1)
               for n in gm["matched_needs"])
    pts["PROJECT_MATCH"] = min(W["PROJECT_MATCH"], round(wsum / 2.6, 1)) if wsum else 0
    # 项目级加成：命中具体项目（matched_projects）说明不是「能力像」而是「真用得上」
    mps = (c.get("project_match") or {}).get("matched_projects") or []
    if mps:
        pts["PROJECT_MATCH"] = min(W["PROJECT_MATCH"],
                                   pts["PROJECT_MATCH"] + min(3.0, len(mps) * 1.0))
    # 平台错配降权：用户技术栈里没有该平台，仍可能含通用方法，故只降权不否决
    if gm.get("domain_mismatch"):
        pts["PROJECT_MATCH"] = round(pts["PROJECT_MATCH"] * 0.35, 1)

    # CAPABILITY_GAP 20
    gl = gm["gap_level"]
    pts["CAPABILITY_GAP"] = {"none": 20, "weak": 15, "medium": 8, "strong": 2}.get(gl, 2)
    # v2.5 §九：只有证据语境为 primary 的能力才可拿满缺口分；
    # supporting 上限 8，mention/negated 上限 2（老数据无此字段时不受影响）
    ec = gm.get("capability_evidence_context") or {}
    ec_lvl = ec.get(gm.get("matched_gap"))
    if ec_lvl == "supporting":
        pts["CAPABILITY_GAP"] = min(pts["CAPABILITY_GAP"], 8)
    elif ec_lvl in ("mention", "negated"):
        pts["CAPABILITY_GAP"] = min(pts["CAPABILITY_GAP"], 2)
    if c["installed_relationship"] in ("overlap", "near_duplicate"):
        pts["CAPABILITY_GAP"] = min(pts["CAPABILITY_GAP"], 5)
    if not ne:
        pts["CAPABILITY_GAP"] = min(pts["CAPABILITY_GAP"], 5)
    # SOURCE_TRUST 15（tier 为 None=unverified 时取最低档）
    tier = c.get("source_tier")
    trust = {"official": 15, "vendor": 13, "community": 8, "unknown": 4}.get(c.get("origin_type"), 4)
    cap_by_tier = tiers_trust.get(str(tier), tiers_trust.get("unverified", 3))
    pts["SOURCE_TRUST"] = min(trust, cap_by_tier)
    # SECURITY 15：按 verdict（pass/review_required/block/unscanned）
    v = c["security"].get("verdict")
    pts["SECURITY"] = {"pass": 15, "review_required": 7, "block": 0,
                       "unscanned": 4}.get(v, 4)
    # MAINTENANCE 10
    lp = c.get("latest_commit", "")
    if lp:
        import datetime
        try:
            days = (datetime.date.today() - datetime.date.fromisoformat(lp[:10])).days
            pts["MAINTENANCE"] = 10 if days <= 30 else 7 if days <= 90 else 3 if days <= 365 else 1
        except Exception:
            pts["MAINTENANCE"] = 4
    else:
        pts["MAINTENANCE"] = 4
    # ADOPTION_TREND 5
    wi = (c.get("adoption_signal") or {}).get("install_count") or 0
    pts["ADOPTION_TREND"] = min(5, 5 * wi / 2000) if wi else (
        2 if (c.get("adoption_signal") or {}).get("stars") else 0)
    # DETOUR_REDUCTION 5
    detour_kws = ["qa", "test", "tests", "testing", "security", "deploy", "deployment",
                  "migration", "responsive", "transcript", "photo", "offline", "playwright"]
    w, t, n = bag(c.get("skill_name"), c.get("description"))
    pts["DETOUR_REDUCTION"] = 5 if hit_any(w, t, n, detour_kws) else 1
    # NOVELTY_VS_INSTALLED 5
    rel = c["installed_relationship"]
    pts["NOVELTY_VS_INSTALLED"] = {"new_capability": 5, "complement": 4,
                                   "replacement_candidate": 3, "overlap": 1,
                                   "near_duplicate": 0, "already_installed": 0}.get(rel, 2)
    capped = {k: round(min(pts[k], W[k]), 1) for k in SCORE_KEYS}
    total = round(sum(capped.values()), 1)
    # v2.4 §九：未解除的平台错配 → 总分再乘一次显著 penalty。
    # 说明：total 因此**不等于**各分项之和，这是刻意的（显式降权，可审计：
    # 系数记在 c["domain_mismatch_penalty"]）。域一旦被真实项目解除，惩罚自动消失。
    unres = unresolved_mismatch(gm)
    if unres:
        total = round(total * DOMAIN_MISMATCH_PENALTY, 1)
        c["domain_mismatch_penalty"] = DOMAIN_MISMATCH_PENALTY
    else:
        c["domain_mismatch_penalty"] = None
    c["scores"] = {k.lower(): v for k, v in capped.items()}
    c["scores"]["total"] = total
    return total


def recommend_of(c, cfg):
    """取值域：install_candidate / watch / ignore / reject（永不自动安装）。

    顺序原则：Security Gate 先于一切（含「已安装」判定）。
    v2.2：只有 block 级才 reject；review_required 不再等于 reject，
          但真在指令/可执行语境里的高敏感项会挡在安装候选之外。
    """
    sec = c["security"]
    # ① Security Gate 优先
    if sec.get("verdict") == "block" or sec.get("risk_level") == "high":
        blocks = sec.get("blocking_rules") or [f["rule"] for f in sec.get("findings", [])
                                               if f.get("level") == "block"]
        reason = "安全 Gate 阻断（block 级）：" + ", ".join(blocks or ["high risk"])
        if c["installed_relationship"] == "already_installed":
            reason += "；该 Skill 本机已安装（安装决策不适用），此条仅作安全提示"
        return "reject", reason
    if c.get("gates_failed"):
        return "reject", "硬门未过（来源/结构不可确认）"
    # ② 已安装
    if c["installed_relationship"] == "already_installed":
        return "ignore", ("已安装（canonical 在册），仅作版本更新观察，不再推荐"
                          + ("；另有版本更新可用（见 UPDATE_CANDIDATES）"
                             if c.get("update_available") else ""))
    s = c["score"]
    gm = c["capability_gap_match"]
    th = cfg.get("thresholds", {"install_candidate": 62, "watch": 45})
    # ③ 平台错配（v2.4 §九）：错配且**没有任何 matched_project 使用该平台** → 最高 watch，
    #    且默认进 watchlist（不进 Personalized Top）。用户真实项目用了该平台时自动解除。
    unres = unresolved_mismatch(gm)
    if unres:
        # 保持「平台错配」这一措辞：既有测试与对照件都按这个口径解释
        why = f"平台错配：{'/'.join(unres)}（项目档案里没有任何项目使用该平台，penalty 未解除）"
        if s >= th.get("watch", 45):
            return "watch", (f"分数 {s} 但{why} → 相关性否决，不得进安装候选，"
                             f"也不进 Personalized Top（§九）")
        return "ignore", f"低分 {s} 且{why} → 与当前项目无相关性"
    # ③b 相关性否决
    if s >= th.get("install_candidate", 62) and not gm.get("need_evidence"):
        return "watch", (f"分数 {s} 但未命中任何项目需求（SKILL_CONTEXT.md needs）"
                         f" → 相关性否决，不得进安装候选")
    # ④ 未验证来源（bottom-up 直出的普通仓库）不得升级为安装候选
    if c.get("source_tier") is None or c.get("tier2_verified") is False:
        if s >= th.get("watch", 45):
            return "watch", (f"分数 {s}，但来源未经验证（source_tier=unverified，"
                             f"{c.get('unverified_reason') or 'bottom-up 搜索结果'}）"
                             f"→ 只能作观察，需人工确认是否为真实 Skill")
        return "ignore", f"低分 {s}：未验证来源且与当前需求关联弱"
    # ⑤ 深度审查硬门（§五）：有脚本却未完成 PASS 2 → 最高 watch
    ds = sec.get("deep_scan_status")
    if ds in ("pending", "failed"):
        return "watch", (f"分数 {s}，但深度静态审查未完成（deep_scan_status={ds}）"
                         f"→ 不得成为安装候选，需先完成脚本静态审查")
    # ⑥ 安全上被挡（高敏感项出现在指令/可执行语境）
    if sec.get("install_blocked"):
        items = "; ".join(f"{f['rule']}({f['behavior_context']})"
                          for f in sec.get("findings", [])
                          if f.get("severity") in ("high", "medium")
                          and f.get("behavior_context") != "mention")[:120]
        return "watch", (f"分数 {s}，但安全项需人工复核：{items}"
                         f"（静态审查判定为『真要求执行』而非『文档提及』）")
    if s >= th.get("install_candidate", 62) and gm["gap_level"] in ("none", "weak") \
            and sec.get("verdict") in ("pass", "review_required") and sec.get("status") == "scanned":
        review_note = ""
        mentions = [f["rule"] for f in sec.get("findings", [])
                    if f.get("behavior_context") == "mention" and f.get("level") == "review"]
        if mentions:
            review_note = f"，另有人工复核项（语境性提及）：{', '.join(mentions[:3])}"
        return "install_candidate", (
            f"高分 {s}：命中需求 {', '.join(n['need'] for n in gm['matched_needs'][:3]) or '—'}"
            f"（能力缺口 {gm.get('matched_gap') or '—'}）"
            f"，安全 verdict={sec.get('verdict')}"
            f"，深度审查 {deep_scan_summary(sec)}{review_note}")
    if s >= th.get("watch", 45):
        extra = ""
        if not gm.get("need_evidence"):
            extra = "（未命中项目需求；仅作观察）"
        if gm.get("domain_mismatch") and not unres:
            # 错配已被真实项目解除：记一下，便于审查者核对「解除」确实发生
            extra += f"（平台错配 {('/'.join(gm['domain_mismatch']))} 已由项目 {gm.get('domain_mismatch_resolved_by') or '档案'} 解除）"
        return "watch", f"中分 {s}：值得关注，需人工判断" + extra + (
            "（安全 review_required，人工复核）" if sec.get("verdict") == "review_required" else
            "（安全未扫描，不得升级为安装候选）" if sec.get("status") != "scanned" else "")
    return "ignore", f"低分 {s}：与当前需求关联弱或与既有能力重复"


# ==========================================================================
# 主流程
# ==========================================================================
def evaluate(cands, inst, cfg, W, tiers_trust, projects):
    """匹配 + 评分 + 推荐（PASS 1 与 PASS 2 之后各跑一次）。"""
    for c in cands:
        c["capability_tags"] = capability_tags(c)
        rel, match, j = installed_relationship(c, inst["installed"])
        c["installed_relationship"] = rel
        c["overlap_with_installed"] = match
        c["token_jaccard"] = round(j, 2)
        c["capability_gap_match"] = gap_match(c, inst, cfg)
        gm = c["capability_gap_match"]
        mps = match_projects(c, projects) if projects else []
        # ---- v2.4 §九：平台错配的解除判定 ----
        # 解除条件（§九 / §十一.18）：「用户真实项目明确使用 Azure / AWS / .NET / 对应平台」。
        # 因此看的是**整个项目档案**的技术面，不是「该候选恰好匹配到的项目」——
        # 否则一个 Azure 候选只要没别的直接证据匹配不上项目，就永远无法解除，
        # 变成事实上的永久 blacklist，而 §九 明确要求「不要永久 blacklist」。
        # 没有该平台的任何证据 → 记为 unresolved：不得 install_candidate、
        # 不得进 Personalized Top、总分乘 DOMAIN_MISMATCH_PENALTY。
        mism_doms = sorted({MR.MISMATCH_DOMAIN.get(t, t)
                            for t in (gm.get("domain_mismatch") or [])})
        proj_doms, resolvers = set(), []
        for _p in (projects or []):
            _d = MR.project_domains(_p)
            if _d:
                proj_doms |= _d
                if _d & set(mism_doms):
                    resolvers.append(_p["name"])
        gm["domain_mismatch_domains"] = mism_doms
        gm["domain_mismatch_resolved"] = sorted(set(mism_doms) & proj_doms)
        gm["domain_mismatch_unresolved"] = sorted(set(mism_doms) - proj_doms)
        gm["domain_mismatch_resolved_by"] = sorted(set(resolvers))
        c["project_match"] = {
            "matched_needs": [n["need"] for n in gm["matched_needs"]],
            "matched_need_weights": {n["need"]: n["weight"] for n in gm["matched_needs"]},
            "matched_need_evidence": {n["need"]: n.get("evidence", []) for n in gm["matched_needs"]},
            # v2.5 §九：需求侧证据语境四态（primary/supporting…），供审查者核对降权
            "matched_need_evidence_levels": {n["need"]: n.get("evidence_level", "primary")
                                             for n in gm["matched_needs"]},
            "need_evidence": gm.get("need_evidence", False),
            "domain_mismatch": gm.get("domain_mismatch", []),
            "domain_mismatch_domains": mism_doms,
            "domain_mismatch_unresolved": gm["domain_mismatch_unresolved"],
            "matched_projects": mps,
            "priority": (mps[0]["match_score"] if mps else None),
        }
        meta = meta_by_repo.get(f"{c['owner']}/{c['repo']}".lower(), {})
        lp = meta.get("pushed_at")
        c["latest_commit"] = lp
        c["latest_commit_source"] = "repo_pushed_at" if lp else None
        if c.get("latest_version") is None:
            c["latest_version"] = None
        c["adoption_signal"] = {
            "install_count": c.get("install_count"),
            "weekly_installs": c.get("install_count"),
            "stars": c.get("stars"),
            "signal_source": ("aggregator_install_telemetry"
                              if c.get("source_tier") == 3 and c.get("install_count")
                              else "repo_stars" if c.get("stars") else "none"),
            "note": "仅作 adoption signal；安装量/star 绝不等于质量或推荐依据",
        }
        if lp:
            import datetime as _dt
            try:
                days = (_dt.date.today() - _dt.date.fromisoformat(lp[:10])).days
                c["upstream_activity"] = "active" if days <= 90 else (
                    "stale" if days <= 365 else "deprecated")
            except Exception:
                c["upstream_activity"] = "unknown"
        else:
            c["upstream_activity"] = "unknown"
        # ---- replacement_candidate ----
        known_by_norm = {k.lower().replace("-", " "): k for k in inst["all_known"]}
        kn = known_by_norm.get(c["skill_name"].lower().replace("-", " "))
        if kn and c["installed_relationship"] != "already_installed":
            ke = inst["all_known"][kn]
            if not ke.get("canonical", {}).get("installed_canonical"):
                c["installed_relationship"] = "replacement_candidate"
                c["overlap_with_installed"] = kn
                c["replacement_candidate_reason"] = (
                    f"对应 canonical `{kn}` 当前不在本机安装集（known_missing）"
                    f"（来源档案在案：{ke.get('upstream') or '见 SKILL_SOURCE_MAP'}）→ 该候选可用于恢复")
        elif c["installed_relationship"] in ("overlap", "near_duplicate") \
                and c["upstream_activity"] == "active" and match:
            ie = inst["installed"].get(match) or inst["all_known"].get(match) or {}
            vs, ia = ie.get("version_status"), ie.get("upstream_activity")
            if vs in ("outdated_version", "historical_official_version") or (ia and ia != "active"):
                c["installed_relationship"] = "replacement_candidate"
                c["replacement_candidate_reason"] = (
                    f"与已装 {match} 重叠（jaccard={round(j,2)}），"
                    f"已装侧 version_status={vs or '未比对'} / upstream_activity={ia or 'unknown'}，"
                    f"候选上游 active → 具备替换/升级价值（仍需人工确认）")
        c["update_available"] = False
        c["update_note"] = None
        if c["installed_relationship"] == "already_installed" and kn:
            ie = inst["all_known"].get(kn) or {}
            vs, ia = ie.get("version_status"), ie.get("upstream_activity")
            if vs in ("outdated_version", "historical_official_version") and ia == "active":
                c["update_available"] = True
                c["update_note"] = (f"已装但 version_status={vs}（上游 active）→ 属更新候选，"
                                    f"不重复推荐安装，仅在 UPDATE_CANDIDATES 提示")
        c["trend_signal"] = ("high_installs" if (c.get("install_count") or 0) >= 1000
                             else "rising" if (c.get("install_count") or 0) >= 100
                             else "active_repo" if c["upstream_activity"] == "active" else "unknown")
        c["score"] = score_candidate(c, W, tiers_trust)
        c["scores"]["total"] = c["score"]
        rec, reason = recommend_of(c, cfg)
        c["recommendation"] = rec
        c["recommendation_reason"] = reason
        c["latest_release"] = None


def main():
    raw = load_json(os.path.join(RAW, "discovery_latest.json"))
    if not raw:
        print("no discovery data — run discover.py")
        return 1
    inst = load_installed()
    cfg = load_config()
    needs_meta = raw.get("project_needs", {})
    cfg["_project_needs"] = needs_meta
    W = cfg.get("weights", {"PROJECT_MATCH": 25, "CAPABILITY_GAP": 20, "SOURCE_TRUST": 15,
                            "SECURITY": 15, "MAINTENANCE": 10, "ADOPTION_TREND": 5,
                            "DETOUR_REDUCTION": 5, "NOVELTY_VS_INSTALLED": 5})
    tiers_trust = cfg.get("tier_trust_ceiling", {"0": 0, "1": 15, "2": 10, "3": 9})
    tiers_trust.setdefault("unverified", 3)

    # ---- 本地项目档案（matched_projects 数据源；仅本地使用，不外传） ----
    projects = []
    if os.path.exists(SKILL_CONTEXT_PATH):
        try:
            projects = load_projects(open(SKILL_CONTEXT_PATH, encoding="utf-8").read())
        except Exception:
            projects = []

    global meta_by_repo
    reg_all = load_json(REGISTRY_PATH, {"tiers": {}})
    meta_by_repo = {}
    for t in ("0", "1", "2", "3"):
        for e in reg_all.get("tiers", {}).get(t, []):
            if e.get("owner") and e.get("repo"):
                meta_by_repo[f"{e['owner']}/{e['repo']}".lower()] = e

    pool = {}
    quarantine = {"invalid_artifacts": [], "unverified_bottom_up": [],
                  "invalid_bottom_up": [], "invalid_names": []}
    stats = {"raw": 0, "artifact_filtered": 0, "invalid_name_filtered": 0,
             "bottom_up_total": 0, "bottom_up_verified": 0, "bottom_up_quarantined": 0}

    def add(owner, repo, skill_name, tier, source_url, origin_type, description="",
            install_count=None, stars=None, path=None, source_id=None,
            tier2_verified=None, unverified_reason=None, scripts=None):
        ck = canonical_key(owner, repo, skill_name)
        e = pool.get(ck)
        if not e:
            e = {"canonical_key": ck, "skill_name": skill_name, "owner": owner, "repo": repo,
                 "source": source_id or f"tier{tier}:{owner}/{repo}",
                 "source_url": source_url, "sources": [], "source_tier": tier,
                 "origin_type": origin_type, "description": description,
                 "install_count": install_count, "stars": stars, "path": path,
                 "scripts": list(scripts) if scripts else [],
                 "tier2_verified": tier2_verified, "unverified_reason": unverified_reason,
                 "discovered_at": TODAY, "last_seen_at": TODAY}
            pool[ck] = e
        src = f"tier{tier}:" + (source_url or f"{owner}/{repo}")
        if src not in e["sources"]:
            e["sources"].append(src)
        if tier is not None and (e["source_tier"] is None or tier < e["source_tier"]):
            e["source_tier"] = tier
            if tier2_verified:
                e["tier2_verified"] = True
                e["unverified_reason"] = None
        if description and not e["description"]:
            e["description"] = description
        if install_count and (e["install_count"] or 0) < install_count:
            e["install_count"] = install_count
        if stars and (e["stars"] or 0) < stars:
            e["stars"] = stars
        if path and not e.get("path"):
            e["path"] = path
        if scripts and not e.get("scripts"):
            e["scripts"] = list(scripts)
        e["last_seen_at"] = TODAY
        return e

    # ---- 合法性 Gate：名称必须像 Skill（§一.1） ----
    def accept_name(owner, repo, name, origin_label):
        stats["raw"] += 1
        if is_artifact_entry(name):
            stats["artifact_filtered"] += 1
            quarantine["invalid_artifacts"].append(
                {"name": name, "owner": owner, "repo": repo, "reason": "构建产物/静态资源",
                 "source": origin_label})
            return False
        if not is_valid_skill_name(name):
            stats["invalid_name_filtered"] += 1
            quarantine["invalid_names"].append(
                {"name": name, "owner": owner, "repo": repo, "reason": "不是合法 skill slug",
                 "source": origin_label})
            return False
        return True

    # ---- TIER 1（官方）+ TIER 2（已验证社区） ----
    for tier in (1, 2):
        for blk in raw.get(f"tier{tier}", []):
            owner, repo = blk.get("owner"), blk.get("repo")
            if not owner:
                continue
            meta = meta_by_repo.get(f"{owner}/{repo}".lower(), {})
            origin = blk.get("origin_type") or ("official" if tier == 1 else "community")
            for sk in blk.get("skills", []):
                if not accept_name(owner, repo, sk["skill_name"], f"tier{tier}:{owner}/{repo}"):
                    continue
                add(owner, repo, sk["skill_name"], tier, sk["html_url"], origin,
                    path=sk.get("path"), stars=meta.get("stars"),
                    source_id=f"{owner}/{repo}",
                    tier2_verified=(tier == 2) or None,
                    scripts=sk.get("scripts"))
    # ---- TIER 3 聚合榜（只作发现） ----
    for src_key in ("skills_sh", "clawhub", "skillsmp"):
        blk = raw.get("tier3", {}).get(src_key, {})
        for e in blk.get("entries", []):
            name = e.get("skill_name") or e.get("repo")
            if not accept_name(e.get("owner"), e.get("repo"), name, blk.get("source", src_key)):
                continue
            add(e.get("owner"), e.get("repo"), name, 3, e.get("source_url"), "unknown",
                install_count=e.get("weekly_installs"), source_id=blk.get("source", src_key))
    # ---- Bottom-up 搜索结果（§一.2：只是 discovery_channel，不等于 TIER 2） ----
    bu_budget = cfg.get("bottom_up_verify_budget", 40)
    bu_seen = []
    for q in raw.get("bottom_up", []):
        for r in q.get("results", []):
            bu_seen.append((q.get("capability_gap"), r))
    # 按 stars 降序取前 N 个做硬门校验，控制 GitHub API 用量
    bu_seen.sort(key=lambda x: -(x[1].get("stars") or 0))
    for cap, r in bu_seen:
        stats["bottom_up_total"] += 1
        stats["raw"] += 1
        if not is_valid_skill_name(r["repo"]):
            stats["invalid_name_filtered"] += 1
            quarantine["invalid_names"].append(
                {"name": r["repo"], "owner": r["owner"], "repo": r["repo"],
                 "reason": "不是合法 skill slug", "source": "bottom_up_search"})
            continue
        if bu_budget <= 0:
            break
        bu_budget -= 1
        v = verify_bottom_up(r["owner"], r["repo"])
        if v.get("ok") is False:
            stats["bottom_up_quarantined"] += 1
            quarantine["invalid_bottom_up"].append(
                {"owner": r["owner"], "repo": r["repo"], "reason": v.get("reason"),
                 "capability_gap": cap, "url": r.get("url")})
            continue
        if v.get("ok") is None:
            stats["bottom_up_quarantined"] += 1
            quarantine["unverified_bottom_up"].append(
                {"owner": r["owner"], "repo": r["repo"], "reason": v.get("reason"),
                 "capability_gap": cap, "url": r.get("url")})
            continue
        stats["bottom_up_verified"] += 1
        # 验证通过：定位到真实 SKILL.md → 进池，但**仍是 unverified 来源**（绝不自动升 T2）
        add(r["owner"], r["repo"], v.get("skill_name") or r["repo"], None, r.get("url"),
            "community", description=r.get("description", ""), stars=r.get("stars"),
            path=v.get("dir"), source_id="bottom_up_search",
            tier2_verified=False,
            unverified_reason="bottom-up 搜索结果，非注册表已验证 T2")

    updates = raw.get("tier1_updates", [])
    cands = list(pool.values())

    # ---- PASS 1：预排序 + 并发抓取 SKILL.md ----
    focus_caps = {f["capability"] for f in
                  load_json(os.path.join(RAW, "gap_focus.json"), {}).get("focus_capabilities", [])}
    for c in cands:
        c["capability_tags"] = capability_tags(c)

    def prelim(c):
        tags = set(c["capability_tags"])
        need_hit = 1 if MR.matched_needs(c, needs_meta) else 0
        hit = 0 if ((tags & focus_caps) or need_hit) else 1
        return (hit, c["source_tier"] if c["source_tier"] is not None else 9,
                -(c.get("install_count") or 0), -(c.get("stars") or 0))

    cands.sort(key=prelim)
    branch_of = {}
    for tier in (1, 2):
        for blk in raw.get(f"tier{tier}", []):
            if blk.get("owner"):
                branch_of[f"{blk['owner']}/{blk['repo']}"] = blk.get("branch", "main")
    tasks, fetched = [], 0
    budget = cfg.get("scan_budget", MAX_SECURITY_FETCH)
    for c in cands:
        if len(tasks) >= budget:
            break
        if c["owner"] and c["repo"] and c.get("path"):
            branch = branch_of.get(f"{c['owner']}/{c['repo']}", c.get("branch") or "main")
            tasks.append((c, f"https://raw.githubusercontent.com/{c['owner']}/{c['repo']}"
                             f"/{branch}/{c['path']}/SKILL.md"))
    if tasks:
        from concurrent.futures import ThreadPoolExecutor
        workers = cfg.get("scan_workers", 10)

        def _probe(job):
            c, url = job
            return c, url, fetch_cached(url, timeout=10)

        with ThreadPoolExecutor(max_workers=workers) as ex:
            for c, url, txt in ex.map(_probe, tasks):
                fetched += 1
                if txt:
                    if not c["description"]:
                        d = fm_description(txt)
                        if d:
                            c["description"] = d
                    mv = re.search(r"^\s*version\s*:\s*['\"]?([0-9][\w.\-]*)", txt, re.M)
                    if mv:
                        c["latest_version"] = mv.group(1)
                    c["security"] = security_scan(txt, has_scripts="scripts/" in txt)
                    c["content_fingerprint"] = fingerprint(txt)
                    c["skillmd_url"] = url
                else:
                    c["security"] = security_scan(None, has_scripts=False)
    for c in cands:
        if "security" not in c:
            c["security"] = security_scan(None, has_scripts=False)
        c["security"]["deep_scan_status"] = None

    # ---- 阶段 B：首次评估（决定谁有资格进 install 候选） ----
    evaluate(cands, inst, cfg, W, tiers_trust, projects)

    # ---- PASS 2：对 install 候选做深度静态审查（§五） ----
    ds_budget = cfg.get("deep_scan_budget", 80)
    phase_b_install = {c["canonical_key"] for c in cands
                       if c["recommendation"] == "install_candidate"}
    deep_targets = [c for c in cands if c["recommendation"] == "install_candidate"]
    deep_targets.sort(key=lambda c: -c["score"])
    deep_targets = deep_targets[:ds_budget]
    ds_done = 0
    for c in deep_targets:
        branch = branch_of.get(f"{c['owner']}/{c['repo']}", "main")
        # v2.2：优先用 discover 阶段已采集的脚本清单 → 零额外 API 调用，避免配额耗尽
        ds = deep_scan(c["owner"], c["repo"], c.get("path"), branch,
                       max_files=cfg.get("deep_scan_max_files", 8),
                       known_scripts=c.get("scripts"))
        c["deep_scan"] = ds
        c["security"]["deep_scan_status"] = ds["deep_scan_status"]
        c["security"]["deep_scan_files"] = ds.get("script_files", [])
        c["security"]["deep_scan_scripts"] = ds.get("scripts_scanned", 0)
        c["security"]["deep_scan_hooks"] = ds.get("package_hooks", [])
        if ds.get("blocking_rules"):
            # 深度扫描发现 block 级 → 并入安全结论
            c["security"]["findings"] = (c["security"].get("findings") or []) + ds["findings"]
            c["security"]["blocking_rules"] = sorted(
                set(c["security"].get("blocking_rules") or []) | set(ds["blocking_rules"]))
            c["security"]["verdict"] = "block"
            c["security"]["risk_level"] = "high"
            c["security"]["install_blocked"] = True
            c["security"]["note"] += "；PASS 2 深度审查发现 block 级行为"
        elif ds.get("deep_install_blocked"):
            c["security"]["findings"] = (c["security"].get("findings") or []) + ds["findings"]
            c["security"]["install_blocked"] = True
            c["security"]["note"] += "；PASS 2 深度审查发现需人工复核的高敏感项"
        elif ds.get("findings"):
            c["security"]["findings"] = (c["security"].get("findings") or []) + ds["findings"]
        ds_done += 1
    # 未进深度扫描的候选：**显式标注真实状态**，不得含糊成「已扫描」
    for c in cands:
        if c.get("deep_scan"):
            continue
        if c["canonical_key"] in phase_b_install:
            # 本该深扫却因预算没扫到 → fail-closed，final evaluate 会把它降为 watch
            c["security"]["deep_scan_status"] = "pending"
            c["deep_scan"] = {"deep_scan_status": "pending", "scripts_scanned": 0,
                              "script_files": [], "package_hooks": [], "findings": [],
                              "blocking_rules": [], "deep_install_blocked": False,
                              "note": "超出本轮深度审查预算，未扫描（fail-closed，不得作安装候选）"}
        elif c.get("path") and c["security"].get("status") == "scanned":
            # 未进入安装候选 → 无需深扫；单独取值，不冒充 complete
            c["security"]["deep_scan_status"] = "not_required"
            c["deep_scan"] = {"deep_scan_status": "not_required", "scripts_scanned": 0,
                              "script_files": [], "package_hooks": [], "findings": [],
                              "blocking_rules": [], "deep_install_blocked": False,
                              "note": "该候选未进入 install 候选，未触发深度审查"}
        else:
            c["security"]["deep_scan_status"] = "skipped"
            c["deep_scan"] = {"deep_scan_status": "skipped", "scripts_scanned": 0,
                              "script_files": [], "package_hooks": [], "findings": [],
                              "blocking_rules": [], "deep_install_blocked": False,
                              "note": "无 SKILL.md 目录信息或未扫描，未做深度审查"}

    # ---- 阶段 D：带上深度审查结果重新评估 ----
    # v2.4 §十：先把质量计数清零，让 PROJECT_MATCH_QUALITY 统计的是**最终一轮**的候选级结果
    MR.reset_quality()
    evaluate(cands, inst, cfg, W, tiers_trust, projects)
    # v2.4 §十：PROJECT_MATCH_QUALITY —— 不再只报「字段非空率」，而是按证据类型分列，
    # 并显式记录「被拒绝的假相关」（secondary 技术栈硬凑 / 否定窗口压制 / 单词词面重叠）。
    quality = dict(MR.QUALITY)
    quality["matched_project_entries"] = sum(
        len((c.get("project_match") or {}).get("matched_projects") or []) for c in cands)
    quality["unresolved_mismatch_candidates"] = sum(
        1 for c in cands
        if (c.get("capability_gap_match") or {}).get("domain_mismatch_unresolved"))

    for c in cands:
        c.pop("gap_match", None)
        c.pop("score_breakdown", None)

    # 聚合源解析层已挡掉的构建产物（发生在 discover 阶段，见 parse_clawhub / parse_skillsmp）
    agg_filtered = sum(int((blk or {}).get("filtered_artifacts", 0) or 0)
                       for blk in (raw.get("tier3") or {}).values())
    out = {"version": 5, "generated": TODAY,
           "model": ("canonical_key=owner/repo/skill（去重只认 canonical source，不按名称）；"
                     "安装/能力判定读取已装侧 CANONICAL_SKILL 真相源（v4，只读）；"
                     "recommendation 取值 install_candidate/watch/ignore/reject；"
                     "Security Gate 优先于分数（v2：区分『提到风险』与『执行风险』）；"
                     "install 候选须完成 PASS 2 深度静态审查；本层只发现不安装；"
                     "v2.4：项目匹配必须带**分级直接证据**（strong_tech / positioning / "
                     "shared_need / lexical），泛用技术栈只能作 secondary boost；"
                     "词面重叠需 ≥2 个高区分度词或 1 个项目域高信号词；"
                     "NEED_RULE 支持否定窗口；未解除的平台错配不得进安装候选与 Personalized Top；"
                     "v2.5：android 需求需真实 QA/构建验收证据；否定窗口按大句切分、"
                     "逗号只在段内传播否定；词面证据禁泛用技术词与裸 prompt，"
                     "独立成立仅限整理过的领域短语；mcp_dev/docx_xlsx/github-auto/"
                     "deploy/android 统一走 capability_evidence_context 四态，"
                     "非 primary 不得拿满缺口分；PPTX 单列 pptx_processing"),
           "counts": {"raw_candidates": stats["raw"],
                      "after_canonical_dedup": len(cands),
                      "invalid_artifacts_removed": stats["artifact_filtered"] + agg_filtered,
                      "invalid_artifacts_removed_aggregator": agg_filtered,
                      "invalid_artifacts_removed_pool": stats["artifact_filtered"],
                      "invalid_names_removed": stats["invalid_name_filtered"],
                      "bottom_up_total": stats["bottom_up_total"],
                      "bottom_up_verified": stats["bottom_up_verified"],
                      "bottom_up_quarantined": stats["bottom_up_quarantined"]},
           "quarantine": quarantine,
           "weights": W,
           "focus_capabilities": [f for f in
                                  load_json(os.path.join(RAW, "gap_focus.json"), {})
                                  .get("focus_capabilities", [])],
           "local_projects": [{"name": p["name"], "tech": p["tech"], "date": p["date"]}
                              for p in projects],
           "project_match_quality": quality,
           "tier1_updates": updates,
           "candidates": cands}
    save_json(out, CANDIDATES_PATH)
    rec_n = sum(1 for c in cands if c["recommendation"] == "install_candidate")
    print(f"raw {stats['raw']} → pool {len(cands)} | 过滤构建产物 "
          f"{stats['artifact_filtered'] + agg_filtered}（聚合源解析层 {agg_filtered} + 入池前 "
          f"{stats['artifact_filtered']}） / 非法名 {stats['invalid_name_filtered']} | "
          f"install_candidate {rec_n} | watch "
          f"{sum(1 for c in cands if c['recommendation']=='watch')} | reject "
          f"{sum(1 for c in cands if c['recommendation']=='reject')} | fetched {fetched} | "
          f"deep_scan {ds_done} | projects {len(projects)}")
    print("PROJECT_MATCH_QUALITY | " + " ".join(f"{k}={v}" for k, v in quality.items()))
    return 0


def fm_description(txt):
    """从 SKILL.md 文本取 description；正确处理 YAML 块标量（> / >- / | / |-）。"""
    if not txt:
        return ""
    m = re.search(r"^description:\s*(.*)$", txt, re.M)
    if not m:
        return ""
    head, rest = m.group(1).strip(), txt[m.end():]
    if head in ("", ">", ">-", ">+", "|", "|-", "|+"):
        lines = []
        for line in rest.split("\n"):
            if not line.strip():
                if lines:
                    lines.append("")
                continue
            if re.match(r"^\S", line):
                break
            lines.append(line.strip())
        val = " ".join(x for x in lines if x).strip()
    else:
        val = head.strip("'\"")
    return re.sub(r"\s+", " ", val)[:300]


meta_by_repo = {}

if __name__ == "__main__":
    sys.exit(main())
