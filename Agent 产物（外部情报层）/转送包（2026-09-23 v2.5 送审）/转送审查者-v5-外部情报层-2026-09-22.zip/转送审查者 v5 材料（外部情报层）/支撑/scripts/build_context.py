# -*- coding: utf-8 -*-
"""生成 EXTERNAL_SKILLS_CONTEXT.md（日报读取的轻量文件）。

机器可读区固定 11 节：
SOURCE_HEALTH / CANDIDATE_POOL_SUMMARY / NEW_DISCOVERIES / HIGH_MATCH_CANDIDATES /
CAPABILITY_GAP_CANDIDATES / TRENDING_RELEVANT / UPDATE_CANDIDATES / SECURITY_REJECTED /
WATCHLIST / PERSONALIZED_TOP30 / DAILY_DELTA
正文只突出 5-10 个「今天真正有变化或值得看」的候选，避免每天重复同样 30 个。
"""
import json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (load_json, save_json, load_config, CANDIDATES_PATH, CONTEXT_OUT,
                    SNAPSHOT_PATH, REGISTRY_PATH, TODAY)
from security_gate import deep_scan_summary

DELTA_CATS = ["NEW", "RISING", "FALLING", "UPDATED", "SECURITY_CHANGED",
              "SOURCE_CHANGED", "MATCH_CHANGED", "ALREADY_INSTALLED", "NO_LONGER_RELEVANT"]

def snap_key(c):
    return {"score": c["score"], "recommendation": c["recommendation"],
            "risk": c["security"]["risk_level"], "source_tier": c["source_tier"],
            "verdict": c["security"].get("verdict"),
            "deep_scan": c["security"].get("deep_scan_status"),
            "gap": c["capability_gap_match"]["gap_level"],
            "install_count": c.get("install_count") or 0,
            "latest_version": c.get("latest_version"),
            "latest_commit": c.get("latest_commit"),
            "relationship": c["installed_relationship"],
            "activity": c.get("upstream_activity")}

def classify_delta(old, new):
    """返回变化类别集合（9 类）。"""
    cats = set()
    if old is None:
        cats.add("NEW")
        if new.get("relationship") == "already_installed": cats.add("ALREADY_INSTALLED")
        return cats
    if new["score"] > old["score"] + 3: cats.add("RISING")
    if new["score"] < old["score"] - 3: cats.add("FALLING")
    if new["recommendation"] != old["recommendation"]: cats.add("MATCH_CHANGED")
    if new["risk"] != old["risk"] or new.get("verdict") != old.get("verdict"):
        cats.add("SECURITY_CHANGED")
    if new.get("deep_scan") != old.get("deep_scan"): cats.add("SECURITY_CHANGED")
    if new["source_tier"] != old["source_tier"]: cats.add("SOURCE_CHANGED")
    if new["gap"] != old["gap"]: cats.add("MATCH_CHANGED")
    if new.get("latest_version") != old.get("latest_version") or \
       new.get("latest_commit") != old.get("latest_commit"): cats.add("UPDATED")
    if new.get("activity") != old.get("activity"): cats.add("UPDATED")
    if (new["install_count"] or 0) > (old["install_count"] or 0) * 1.5: cats.add("RISING")
    if new.get("relationship") == "already_installed" and old.get("relationship") != "already_installed":
        cats.add("ALREADY_INSTALLED")
    return cats

# ---------- Top30 选取（个性化底线 + 多样性） ----------
def rank_candidate(c):
    """排序键（字典序，越靠前越优先），严格对应 §八 规定的执行顺序：

      ① hard gates  —— 在调用方已做（已安装 / 硬门未过 / ignore / reject 已剔出池）
      ② 真实需求匹配 —— need_evidence 优先，其次命中具体项目（matched_projects）
      ③ recommendation >= watch —— 池内已是 install_candidate 或 watch，install 优先
      ④ score
      ⑤ diversity —— 由 select_top30 在最后执行（同仓库 ≤3 + 同族折叠）

    原则：多样性可以保留，但**不得压过质量**——不为「凑够不同能力」把 ignore 填进来。
    """
    pm = c.get("project_match") or {}
    mps = pm.get("matched_projects") or []
    return (-(1 if pm.get("need_evidence") else 0),
            -(1 if mps else 0),
            -(0 if pm.get("domain_mismatch") else 1),
            -(1 if c["recommendation"] == "install_candidate" else 0),
            -c["score"])

def same_family(a, b):
    """同族判定（词元序列）：最长公共前缀 ≥3，或短者是长者的完整前缀（且短者 ≥2 词）。
    例：google-mobile-ads-get-started / -interstitial（公共前缀 3）→ 同族
        orca-emulator vs orca-emulator-android（前者是后者前缀）→ 同族"""
    n = min(len(a), len(b))
    lcp = 0
    while lcp < n and a[lcp] == b[lcp]:
        lcp += 1
    if lcp >= 3: return True
    return (a[:n] == b[:n] or b[:n] == a[:n]) and n >= 2

# ---------- v2.3：质量门 + 跨仓功能族折叠（§三 / §五 / §八） ----------
def norm_skill_name(name):
    """规范化 Skill 名：小写、连接符统一，用于跨仓同名/近名判定。"""
    return re.sub(r"[-_\s]+", "-", (name or "").lower()).strip("-")

def _desc_token_set(c):
    import match_rules as MR
    words, _t, _n = MR.bag(c.get("skill_name"), c.get("description"))
    return {w for w in words if len(w) >= 3}

def _jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)

def functional_family(a, b, sim_threshold=0.62):
    """判断两个候选是否属**同一功能族**（§三：跨 repo 折叠依据）。

    综合三类信号（至少一类成立）：
      ① normalized skill name 完全相同且够长（github/…/webapp-testing 与
         anthropics/skills/webapp-testing）
      ② description 高度相似 **且** 名称同前缀
      ③ content_fingerprint 完全相同（逐字节同一份 SKILL.md）
    返回 (是否同族, 依据文字)。
    """
    na, nb = norm_skill_name(a.get("skill_name")), norm_skill_name(b.get("skill_name"))
    if na and na == nb and len(na) >= 5:
        return True, "同名同功能"
    fa, fb = a.get("content_fingerprint"), b.get("content_fingerprint")
    if fa and fb and fa == fb:
        return True, "内容指纹相同"
    sim = _jaccard(_desc_token_set(a), _desc_token_set(b))
    if sim >= sim_threshold and na[:4] and na[:4] == nb[:4]:
        return True, f"描述相似 {sim:.2f} + 名称同前缀"
    return False, ""

def unresolved_mismatch(c):
    """§九：取「未解除的平台错配」（老数据无该字段时退回 domain_mismatch）。"""
    gm = c.get("capability_gap_match") or {}
    if "domain_mismatch_unresolved" in gm:
        return gm.get("domain_mismatch_unresolved") or []
    return gm.get("domain_mismatch") or []

def has_personalized_evidence(c):
    """§五 质量门①：必须有真实个性化证据。

    matched need / capability gap / update / replacement 至少一个成立。
    只靠「来源看起来不错」不得进 Personalized Top。
    """
    pm = c.get("project_match") or {}
    gap = c.get("capability_gap_match") or {}
    return bool(pm.get("need_evidence")
                or pm.get("matched_projects")
                or gap.get("gap_level") in ("none", "weak")
                or c.get("update_available")
                or c.get("installed_relationship") == "replacement_candidate")

def is_t3_uncorroborated(c, corroborated_repos):
    """§五 质量门③：T3 / discovery_only 来源若无 T1·T2·官方交叉佐证 → 不进 Top，只留 WATCHLIST。"""
    if c.get("source_tier") != 3 and c.get("origin_type") != "discovery_only":
        return False
    key = f"{c.get('owner','')}/{c.get('repo','')}".lower()
    return key not in (corroborated_repos or set())


def build_corroborated_repos(reg, cands):
    """§五 质量门③的佐证集合：T0/T1/T2 注册源 + 本轮 official/vendor 候选的 owner/repo。

    单独抽成函数，让 build_context（日报）与 make_digest（对照件）用同一份口径，
    避免两处 Top 对「谁有交叉佐证」判断不一致。
    """
    repos = set()
    for t in ("0", "1", "2"):
        for e in (reg.get("tiers", {}) or {}).get(t, []) or []:
            sid = (e.get("source_id") or "").lower()
            if sid:
                repos.add(sid)
    for c in cands:
        if c.get("origin_type") in ("official", "vendor"):
            repos.add(f"{c.get('owner','')}/{c.get('repo','')}".lower())
    return repos

def select_top(ranked, limit=30, *, min_score=None, require_evidence=True,
               corroborated_repos=None, fold_cross_repo=True, require_no_mismatch=True):
    """选出 Personalized Top，返回 (selected, alternatives_map)。`alts[primary_key] = [dup...]`。

    v2.3 三道质量门（§五）+ 跨仓功能族折叠（§三）：
      · score ≥ min_score（配置化最低阈值）
      · 有真实个性化证据（has_personalized_evidence）
      · T3/discovery_only 无 T1·T2·官方交叉佐证不得入 Top
      · 跨 repo 同功能族只展示 PRIMARY，其余进 alternatives
      · 同仓库 ≤3 条 + 同仓库内同族折叠（v2.2 保留）
    不足 limit 时如实返回实际条数 —— **不凑数**。

    v2.4 第四道门（§九）：**存在未解除的平台错配 → 不进 Personalized Top**。
    错配只是「当前没有证据使用该技术栈」，不是永久黑名单：用户真实项目一旦用上
    该平台，analyze 会把该域标为 resolved，这道门自动放行。
    """
    def _blocked(c):
        return require_no_mismatch and bool(unresolved_mismatch(c))

    out, alts, repo_cnt, fam_tokens = [], {}, {}, {}
    for c in ranked:
        if len(out) >= limit:
            break
        if min_score is not None and c.get("score", 0) < min_score:
            continue
        if require_evidence and not has_personalized_evidence(c):
            continue
        if is_t3_uncorroborated(c, corroborated_repos):
            continue
        if _blocked(c):
            continue
        if fold_cross_repo:
            dup = next((o for o in out if functional_family(o, c)[0]), None)
            if dup is not None:
                alts.setdefault(dup["canonical_key"], []).append({
                    "canonical_key": c["canonical_key"],
                    "skill_name": c.get("skill_name"),
                    "source": f"{c.get('owner','')}/{c.get('repo','')}",
                    "score": c.get("score"),
                    "reason": functional_family(dup, c)[1]})
                continue
        rk = f"{c.get('owner','')}/{c.get('repo','')}".lower()
        if repo_cnt.get(rk, 0) >= 3:
            continue
        toks = tuple(t for t in re.split(r"[-_\s]+", (c.get("skill_name") or "").lower()) if t)
        seen = fam_tokens.setdefault(rk, [])
        if toks and any(same_family(toks, s) for s in seen):
            continue
        seen.append(toks)
        repo_cnt[rk] = repo_cnt.get(rk, 0) + 1
        out.append(c)
    # §三/§八 补漏：同功能族的兄弟条目若在**主循环里就落选**（例如先被同仓库上限
    # 拦下、或它排在 PRIMARY 之前但当时还没有同族入选），也必须登记进 ALTERNATIVES，
    # 不能无声消失 —— §三 要求「其余放进 alternatives」。
    if fold_cross_repo and out:
        selected_keys = {c.get("canonical_key") for c in out}
        known = {d["canonical_key"] for v in alts.values() for d in v}
        for c in ranked:
            ck = c.get("canonical_key")
            if ck in selected_keys or ck in known:
                continue
            if min_score is not None and c.get("score", 0) < min_score:
                continue
            if require_evidence and not has_personalized_evidence(c):
                continue
            if is_t3_uncorroborated(c, corroborated_repos):
                continue
            if _blocked(c):
                continue
            fam = next((o for o in out if functional_family(o, c)[0]), None)
            if fam is None:
                continue
            alts.setdefault(fam["canonical_key"], []).append({
                "canonical_key": ck,
                "skill_name": c.get("skill_name"),
                "source": f"{c.get('owner','')}/{c.get('repo','')}",
                "score": c.get("score"),
                "reason": functional_family(fam, c)[1]})
            known.add(ck)
    return out, alts

def select_top30(ranked, limit=30):
    """向后兼容入口：只返回选中的候选列表（不含 alternatives）。"""
    return select_top(ranked, limit)[0]

def main():
    data = load_json(CANDIDATES_PATH)
    reg = load_json(REGISTRY_PATH, {"counts": {}})
    if not data: print("no candidates"); return 1
    cands = data["candidates"]
    prev = load_json(SNAPSHOT_PATH, {})
    first_run = not prev

    counts = data.get("counts", {})
    rel = {}
    for c in cands: rel[c["installed_relationship"]] = rel.get(c["installed_relationship"], 0) + 1
    gap = {}
    for c in cands: gap[c["capability_gap_match"]["gap_level"]] = gap.get(c["capability_gap_match"]["gap_level"], 0) + 1
    rec = {}
    for c in cands: rec[c["recommendation"]] = rec.get(c["recommendation"], 0) + 1
    sec = {}
    for c in cands: sec[c["security"]["risk_level"]] = sec.get(c["security"]["risk_level"], 0) + 1
    # v2.2：安全结论按 verdict（pass / review_required / block / unscanned）与深度审查状态统计
    vd = {}
    for c in cands:
        k = c["security"].get("verdict")
        vd[k] = vd.get(k, 0) + 1
    dss = {}
    for c in cands:
        k = c["security"].get("deep_scan_status")
        dss[k] = dss.get(k, 0) + 1
    # matched_projects 覆盖度（§三/§十六：**高匹配候选**必须答出具体项目名）
    # 分母只取「真有需求证据」的候选 —— 把全部 watch 都算进来会把无关候选稀释进分母，
    # 使覆盖率这个指标失去意义（v2.2 修正）。
    hm_all = [c for c in cands if c["recommendation"] in ("install_candidate", "watch")
              and (c.get("project_match") or {}).get("need_evidence")]
    hm_with_proj = [c for c in hm_all
                    if (c.get("project_match") or {}).get("matched_projects")]

    # ---- delta ----
    deltas = {}
    for c in cands:
        cats = classify_delta(prev.get(c["canonical_key"]), snap_key(c))
        if cats: deltas[c["canonical_key"]] = sorted(cats)
    for ck in prev:
        if ck not in {c["canonical_key"] for c in cands}:
            deltas[ck] = ["NO_LONGER_RELEVANT"]
    delta_by_cat = {k: 0 for k in DELTA_CATS}
    for cats in deltas.values():
        for k in cats:
            if k in delta_by_cat: delta_by_cat[k] += 1

    # ---- Top30 / 每日重点（§七：不得塞 ignore / reject 补数量） ----
    # Top30 的定义 = 「值得用户看的 Personalized Top candidates」：
    #   允许 install_candidate / watch，**禁止 ignore / reject**。
    #   如果本轮符合标准的只有 23 个，就输出 Top23 —— 不为凑 30 个数字塞垃圾。
    # 池内排序见 rank_candidate；多样性（同仓库 ≤3 / 同族折叠）在 select_top30 里最后执行。
    cfg = load_config()
    top_cfg = cfg.get("top_candidates", {})
    target_limit = top_cfg.get("target_limit", 30)
    min_top_score = top_cfg.get("min_score")
    allowed_rec = tuple(top_cfg.get("allowed_recommendations",
                                    ["install_candidate", "watch"]))
    # §五 质量门③：T3 / discovery_only 必须有 T1·T2·官方来源交叉佐证才可进 Top
    corroborated_repos = build_corroborated_repos(reg, cands)
    pool = [c for c in cands if c["installed_relationship"] != "already_installed"
            and c["recommendation"] in allowed_rec]
    ranked = sorted(pool, key=rank_candidate)
    top30, top_alts = select_top(ranked, limit=target_limit, min_score=min_top_score,
                                 corroborated_repos=corroborated_repos)
    t3_unc = [c for c in ranked if is_t3_uncorroborated(c, corroborated_repos)]
    functional_dupes = sum(len(v) for v in top_alts.values())
    # v2.4 §九/§十四：未解除的平台错配必须在 Top 里为 0（被挡在 Top 外的要如实计数）
    top_mismatch = [c for c in top30 if unresolved_mismatch(c)]
    mismatch_blocked = [c for c in ranked if unresolved_mismatch(c)]
    # v2.4 §十：PROJECT_MATCH_QUALITY（按证据类型分列 + 被拒绝的假相关），
    # 取代旧的「direct_evidence 字段非空率」——非空不等于语义有效。
    pmq = dict(data.get("project_match_quality") or {})
    mp_entries = [m for c in cands
                  for m in ((c.get("project_match") or {}).get("matched_projects") or [])]
    pmq.setdefault("matched_project_entries", len(mp_entries))
    pmq.setdefault("unresolved_mismatch_candidates",
                   sum(1 for c in cands if unresolved_mismatch(c)))
    direct_rate = (sum(1 for m in mp_entries if m.get("direct_evidence")) / len(mp_entries)
                   if mp_entries else 1.0)

    # 每日正文只放「今天真的变了」的候选：Top30 无变化时不重复输出同样内容。
    # 首次运行（无基线）例外：展示 install_candidate 作为初始观察面。
    meaningful = {k: v for k, v in deltas.items() if "NO_LONGER_RELEVANT" not in v}
    if first_run:
        ic_ranked = [c for c in ranked if c["recommendation"] == "install_candidate"]
        # 正文同样走质量门与多样性规则：不出现同一 SDK 的多个变体占版面
        body = select_top(ic_ranked, limit=10, min_score=min_top_score,
                          corroborated_repos=corroborated_repos)[0]
        if not body: body = top30[:5]
    else:
        changed_keys = [k for k in meaningful]
        by_key = {c["canonical_key"]: c for c in cands}
        body = select_top(sorted([by_key[k] for k in changed_keys
                                  if k in by_key
                                  and by_key[k]["recommendation"] in allowed_rec
                                  and by_key[k]["installed_relationship"] != "already_installed"],
                                 key=lambda c: (-len(meaningful[c["canonical_key"]]), -c["score"])),
                          limit=10, min_score=min_top_score,
                          corroborated_repos=corroborated_repos)[0]

    high_match = [c for c in cands if c["recommendation"] == "install_candidate"]
    rejected = [c for c in cands if c["recommendation"] == "reject"]
    watchlist = [c for c in cands if c["recommendation"] == "watch"]
    gap_cands = [c for c in cands if c["capability_gap_match"]["gap_level"] in ("none", "weak")]
    trending = [c for c in cands if c.get("trend_signal") in ("high_installs", "rising")
                and c["installed_relationship"] in ("new_capability", "complement")]
    update_flags = [c for c in cands if c.get("update_available")]
    updated = [c for c in cands if c["canonical_key"] in deltas
               and {"UPDATED", "MATCH_CHANGED"} & set(deltas[c["canonical_key"]])]
    update_all = sorted({c["canonical_key"]: c for c in (updated + update_flags)}.values(),
                        key=lambda c: -c["score"])
    t3 = load_json(os.path.join(os.path.dirname(CANDIDATES_PATH), "raw", "discovery_latest.json"), {}).get("tier3", {})

    L = []
    L.append("# External Skills Context（外部 Skill 情报 · 日报底座）")
    L.append("")
    L.append(f"> 生成日期：{TODAY}｜来源注册表 v{reg.get('version')}："
             f"T0 {reg.get('counts',{}).get('0',0)} / T1 {reg.get('counts',{}).get('1',0)} / "
             f"T2 {reg.get('counts',{}).get('2',0)} / T3 {reg.get('counts',{}).get('3',0)}")
    L.append("> 本层只做「发现 → 标准化 → 去重 → 匹配 → 安全审查 → 个性化排序」。"
             "**不安装、不删除、不升级任何 Skill**；安装一律在 Skill Manager 人工执行。")
    L.append("> 排名/安装量只是 adoption signal，绝不等于质量或推荐依据。完整数据：`data/SKILL_CANDIDATES.json`")
    L.append("")

    # ================= 机器可读区（11 节） =================
    L.append("```")
    L.append("SOURCE_HEALTH:")
    for t in ("0", "1", "2", "3"):
        for e in reg.get("tiers", {}).get(t, []):
            L.append(f"  - T{t} {e['source_id']}: {e.get('status','?')}"
                     + (f" (trust={e.get('trust_level')})" if e.get('trust_level') else ""))
    L.append(f"  - skills.sh entries_today: {len(t3.get('skills_sh', {}).get('entries', []))}"
             f" (healthy={t3.get('skills_sh', {}).get('healthy')})")
    L.append(f"  - clawhub entries_today: {len(t3.get('clawhub', {}).get('entries', []))}"
             f" (healthy={t3.get('clawhub', {}).get('healthy')})")
    L.append("")
    L.append("CANDIDATE_POOL_SUMMARY:")
    L.append(f"  raw: {counts.get('raw_candidates')}")
    L.append(f"  canonical: {counts.get('after_canonical_dedup')}")
    L.append(f"  invalid_artifacts_removed: {counts.get('invalid_artifacts_removed', 0)}   # 构建产物/静态资源（§一.1）")
    L.append(f"  invalid_names_removed: {counts.get('invalid_names_removed', 0)}   # 非法 skill slug")
    L.append(f"  bottom_up_total: {counts.get('bottom_up_total', 0)}")
    L.append(f"  bottom_up_verified: {counts.get('bottom_up_verified', 0)}   # 过 SKILL.md 硬门")
    L.append(f"  bottom_up_quarantined: {counts.get('bottom_up_quarantined', 0)}   # 已隔离，不入正式池")
    for k in ("already_installed", "near_duplicate", "overlap", "complement",
              "new_capability", "replacement_candidate"):
        L.append(f"  {k}: {rel.get(k, 0)}")
    L.append(f"  gap_none: {gap.get('none',0)}")
    L.append(f"  gap_weak: {gap.get('weak',0)}")
    L.append(f"  gap_medium: {gap.get('medium',0)}")
    L.append(f"  gap_strong: {gap.get('strong',0)}")
    L.append("")
    L.append(f"NEW_DISCOVERIES: {delta_by_cat['NEW']}")
    L.append(f"HIGH_MATCH_CANDIDATES: {len(high_match)}")
    L.append(f"CAPABILITY_GAP_CANDIDATES: {len(gap_cands)}   # gap_level ∈ {{none, weak}}")
    L.append(f"TRENDING_RELEVANT: {len(trending)}")
    L.append(f"UPDATE_CANDIDATES: {len(update_all)}   # delta 变化 + 已装但版本落后（update_available）")
    L.append(f"SECURITY_REJECTED: {len(rejected)}")
    L.append(f"WATCHLIST: {len(watchlist)}")
    L.append("")
    # v2.4 §十：PROJECT_MATCH_QUALITY —— 取代「direct_evidence 字段非空率」。
    # 非空 ≠ 语义有效；这里按**证据类型**分列，并把「被拒掉的假相关」显式记出来。
    L.append("PROJECT_MATCH_QUALITY:")
    L.append(f"  matched_candidates: {pmq.get('matched_candidates', 0)}   # 至少有一个 matched_project 的候选数")
    L.append(f"  matched_project_entries: {pmq.get('matched_project_entries', 0)}   # matched_project 总条数（候选×项目）")
    L.append(f"  strong_tech_evidence: {pmq.get('strong_tech_evidence', 0)}   # 专用技术栈直接命中（Expo/RN/Android/Supabase/Next.js/PWA/Vercel/.NET…）")
    L.append(f"  positioning_evidence: {pmq.get('positioning_evidence', 0)}   # 项目定位/功能语义命中")
    L.append(f"  shared_need_evidence: {pmq.get('shared_need_evidence', 0)}   # 项目自身需求与候选能力命中")
    L.append(f"  lexical_evidence: {pmq.get('lexical_evidence', 0)}   # 词面证据（v2.5：独立成立仅限领域短语；词级重叠只作次要加分）")
    L.append(f"  secondary_tech_only_rejected: {pmq.get('secondary_tech_only_rejected', 0)}   # 只靠泛用技术栈（TS/React/Python/Docker…）硬凑、已被拒的候选数")
    L.append(f"  negated_evidence_rejected: {pmq.get('negated_evidence_rejected', 0)}   # 被否定窗口/排除语境压制掉的命中次数")
    L.append(f"  lexical_single_rejected: {pmq.get('lexical_single_rejected', 0)}   # 词面重叠只因单个低区分度词（manager/service…）而不足以成立的次数")
    L.append(f"  lexical_alone_rejected: {pmq.get('lexical_alone_rejected', 0)}   # v2.5 §三：词面 boost（≥2 词）想**独立**造匹配、被拒的次数（词面只作次要加分）")
    L.append(f"  lexical_phrase_direct_evidence: {pmq.get('lexical_phrase_direct_evidence', 0)}   # v2.5 §五：靠人工整理的领域短语独立成立的词面证据条数")
    L.append(f"  bare_prompt_direct_evidence: {pmq.get('bare_prompt_direct_evidence', 0)}   # v2.5 §四：裸 prompt 被当直接证据的次数（**必须为 0**）")
    L.append(f"  tech_words_used_as_lexical_direct_evidence: {pmq.get('tech_words_used_as_lexical_direct_evidence', 0)}   # v2.5 §四：泛用技术词充当词面直接证据的次数（**必须为 0**）")
    L.append(f"  unresolved_mismatch_candidates: {pmq.get('unresolved_mismatch_candidates', 0)}   # 存在未解除平台错配的候选数（只作观察）")
    L.append("  note: 四个 *_evidence 是「候选×项目」条数，同一条可同时具备多种证据；")
    L.append("        所有 projected 条目都必须至少带 1 类直接证据（direct_evidence 非空率 "
             f"{direct_rate:.0%}，仅作完整性自检，不作 KPI）")
    L.append("")
    L.append("PERSONALIZED_TOP30:")
    L.append(f"  target_limit: {target_limit}")
    L.append(f"  actual_count: {len(top30)}   # 不足 target 时输出实际数量，不塞 ignore/reject 补数量")
    L.append(f"  min_score: {min_top_score if min_top_score is not None else 'none (未配置质量门)'}")
    L.append(f"  functional_duplicates: {functional_dupes}   # 跨仓同功能族被折叠进 alternatives 的条目数（§三）")
    L.append(f"  t3_uncorroborated: {len(t3_unc)}   # T3/discovery_only 无 T1·T2·官方交叉佐证，挡在 Top 外（只留 WATCHLIST）")
    L.append(f"  alternative_families: {len(top_alts)}")
    L.append(f"  contains_ignore: {'yes' if any(c['recommendation'] == 'ignore' for c in top30) else 'no'}")
    L.append(f"  contains_reject: {'yes' if any(c['recommendation'] == 'reject' for c in top30) else 'no'}")
    L.append(f"  generated: {'yes' if top30 else 'no'}")
    L.append(f"  high_match_count: {len(high_match)}")
    L.append(f"  matched_projects_coverage: {len(hm_with_proj)}/{len(hm_all)}   # 高匹配候选中答出具体项目名的比例（准确率优先，不再要求 90%+）")
    L.append(f"  top_candidates_with_unresolved_mismatch: {len(top_mismatch)}   # §九：必须为 0")
    L.append(f"  mismatch_blocked_from_top: {len(mismatch_blocked)}   # 因未解除平台错配被挡在 Top 外（仍留 WATCHLIST）")
    L.append(f"  security_scanned: {sec.get('low',0) + sec.get('medium',0) + sec.get('high',0)}")
    L.append(f"  security_unscanned: {sec.get('unknown',0)}")
    L.append(f"  security_verdict_pass: {vd.get('pass',0)}")
    L.append(f"  security_verdict_review_required: {vd.get('review_required',0)}")
    L.append(f"  security_verdict_block: {vd.get('block',0)}")
    L.append(f"  deep_scan_complete: {dss.get('complete',0)}   # 真正做了深度静态审查的（= install 候选）")
    L.append(f"  deep_scan_failed: {dss.get('failed',0)}")
    L.append(f"  deep_scan_pending: {dss.get('pending',0)}   # 超预算未扫，fail-closed")
    L.append(f"  deep_scan_not_required: {dss.get('not_required',0)}   # 未进安装候选，未触发")
    L.append(f"  deep_scan_skipped: {dss.get('skipped',0)}   # 无目录/未扫描")
    L.append("  top10:")
    for c in top30[:10]:
        L.append(f"    - {c['canonical_key']} | score={c['score']} | gap={c['capability_gap_match']['gap_level']}"
                 f" | rel={c['installed_relationship']} | risk={c['security']['risk_level']}"
                 f" | verdict={c['security'].get('verdict')} | rec={c['recommendation']}")
    L.append("")
    L.append(f"DAILY_DELTA:   # 与昨日快照相比；Top30 无变化时不要重复输出同样内容")
    L.append(f"  first_run: {'yes' if first_run else 'no'}")
    L.append(f"  changed_total: {len(deltas)}")
    for k in DELTA_CATS:
        L.append(f"  {k}: {delta_by_cat[k]}")
    L.append("```")
    L.append("")

    # ================= 正文 =================
    if first_run:
        L.append("## 0. Delta 说明（首次运行）")
        L.append("")
        L.append("- 今日建立基线快照：无昨日可比，明日开始输出 "
                 "NEW / RISING / FALLING / UPDATED / SECURITY_CHANGED / SOURCE_CHANGED / "
                 "MATCH_CHANGED / ALREADY_INSTALLED / NO_LONGER_RELEVANT。")
        L.append("")
    else:
        changed = {k: v for k, v in deltas.items() if "NO_LONGER_RELEVANT" not in v}
        L.append(f"## 0. 今日 Delta（{len(changed)} 项变化 · 按变化数排序）")
        L.append("")
        if not changed:
            L.append("- 今日无变化：候选池与昨日一致 —— **日报不要重复输出同样内容**。")
        for ck, cats in sorted(changed.items(), key=lambda x: -len(x[1]))[:15]:
            L.append(f"- `{ck}`：{', '.join(cats)}")
        L.append("")

    if body:
        L.append(f"## 1. 今日重点（{len(body)} 个 · 回答七问）")
        L.append("")
    else:
        L.append("## 1. 今日重点：**无**（Top30 与昨日一致，不重复输出）")
        L.append("")
        L.append("> 日报请只报告下方 `DAILY_DELTA` 的变化；候选池无变化时不要重复罗列同样的 Skill。")
        L.append("")
        L.append("> 需要完整清单时看第 2 节 Top30 表或 `data/SKILL_CANDIDATES.json`。")
        L.append("")
    for i, c in enumerate(body, 1):
        gm = c["capability_gap_match"]
        needs = [n["need"] for n in gm["matched_needs"]]
        L.append(f"### {i}. {c['skill_name']}（{c['owner']}/{c['repo']}）")
        L.append(f"1. **它是什么**：{(c.get('description') or '(无描述，需人工查看)')[:160]}")
        # §三：这一问必须真正答出「项目名」，不能只给能力标签
        mps = (c.get("project_match") or {}).get("matched_projects") or []
        if mps:
            # v2.5 §十一：依据必须展示**直接证据**（strong_tech/positioning/shared_need/
            # lexical 领域短语），不得回退到旧的泛化标签「技术栈词面重叠」
            proj_txt = "；".join(
                f"`{m['project']}`（匹配度 {m['match_score']}｜依据："
                f"{'/'.join((m.get('direct_evidence') or m['evidence'])[:2])}）"
                for m in mps[:3])
        else:
            proj_txt = ("未匹配到具体项目"
                        + (f"；能力标签命中：{', '.join(needs)}" if needs else ""))
        L.append(f"2. **对我哪个项目有用**：{proj_txt}")
        L.append(f"3. **我现在有没有类似能力**：{c['installed_relationship']}"
                 + (f"（与已装 `{c['overlap_with_installed']}` 相关，jaccard={c.get('token_jaccard')}）"
                    if c.get("overlap_with_installed") else "")
                 + (f"；已装侧 version_status={c.get('replacement_side_version_status') or '未比对'}"
                    if c.get("replacement_candidate_reason") else ""))
        L.append(f"4. **为什么今天值得看**：{', '.join(deltas.get(c['canonical_key'], ['首次入池']))}"
                 f"；能力缺口={gm['gap_level']}；上游活跃度={c.get('upstream_activity')}")
        L.append(f"5. **来源是谁**：TIER{c['source_tier']}｜{c['source']}｜{c['source_url']}"
                 f"（origin={c['origin_type']}）")
        flag_keys = ["shell_exec", "network_access", "filesystem_write", "destructive_commands",
                     "secret_access", "remote_instruction_fetch", "external_dependencies"]
        flags_on = [k for k in flag_keys if c["security"].get(k)]
        sec_line = (f"{c['security']['status']} / verdict={c['security'].get('verdict')}"
                    f" / risk={c['security']['risk_level']}")
        if flags_on:
            sec_line += "｜行为：" + ", ".join(flags_on)
        if c["security"]["findings"]:
            sec_line += ("｜规则命中：" + "; ".join(
                f"{f['rule']}[{f.get('severity')}/{f.get('behavior_context')}]"
                for f in c["security"]["findings"][:4]))
        sec_line += f"｜深度审查：{deep_scan_summary(c['security'])}"
        L.append(f"6. **安全状态**：{sec_line}")
        L.append(f"7. **推荐**：**{c['recommendation'].upper()}** — {c['recommendation_reason']}"
                 f"（score={c['score']}）")
        L.append("")

    L.append(f"## 2. Personalized Top（target_limit {target_limit} · 实际 {len(top30)}）")
    L.append("")
    L.append("> 定义 = **值得用户看的候选**：只含 `install_candidate` / `watch`，"
             "**不含 ignore / reject**；且必须同时过四道门（§五 + §九）："
             f"① score ≥ {min_top_score if min_top_score is not None else '—'}"
             "（配置化最低阈值）② 有真实个性化证据（命中需求 / 能力缺口 / 更新 / 恢复）"
             "③ T3·discovery_only 来源需有 T1·T2·官方交叉佐证"
             "④ **无未解除的平台错配**（Azure / AWS / GCP / .NET 等：项目档案里没有项目用该平台"
             " → 只留 WATCHLIST，不占个人 Top）。"
             f"符合标准的不足 {target_limit} 个时就输出实际数量，**不为凑数塞低质量 watch**。")
    L.append("")
    L.append("> 跨仓库**同功能族**只展示一条 PRIMARY（§三）："
             "如 `github/awesome-copilot/webapp-testing` 与 `anthropics/skills/webapp-testing` "
             "只出一条，其余进下方 ALTERNATIVES。")
    L.append("")
    L.append("| # | Skill | owner/repo | 分 | 缺口 | 关系 | verdict | 最匹配项目 | 推荐 |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for i, c in enumerate(top30, 1):
        mps = (c.get("project_match") or {}).get("matched_projects") or []
        proj = f"{mps[0]['project']}（{mps[0]['match_score']}）" if mps else "—"
        L.append(f"| {i} | {c['skill_name']} | {c['owner']}/{c['repo']} | {c['score']} | "
                 f"{c['capability_gap_match']['gap_level']} | {c['installed_relationship']} | "
                 f"{c['security'].get('verdict')} | {proj} | {c['recommendation']} |")
    L.append("")
    L.append("> 安装候选 ≠ 自动安装；任何 Skill 的安装都需用户在 Skill Manager 中人工执行，"
             "并另行安全复核。")
    L.append("")
    if top_alts:
        L.append("### 2.1 ALTERNATIVES（同功能族的其他上游 · 不重复推荐）")
        L.append("")
        L.append("> 候选池按 `owner/repo/skill` 各自独立记账；这里只做**展示层折叠**（§八）："
                 "同一功能族选一条 PRIMARY，其余列在此处备查。")
        L.append("")
        L.append("| PRIMARY | 同功能来源 | 折叠依据 |")
        L.append("|---|---|---|")
        for _pk, _dups in list(top_alts.items())[:15]:
            for _d in _dups[:3]:
                L.append(f"| `{_pk}` | `{_d['canonical_key']}`（{_d['source']}，"
                         f"score={_d['score']}） | {_d['reason']} |")
        L.append("")
    L.append(f"- Top 内跨仓同功能族折叠：**{functional_dupes}** 条；"
             f"T3 无交叉佐证被挡在 Top 外：**{len(t3_unc)}** 条（仍留在 WATCHLIST）。")
    L.append("")

    L.append("## 3. 安全拒绝清单（SECURITY_REJECTED，Gate 优先于分数）")
    L.append("")
    L.append("> v2.2 起只有 **block 级**（真要求执行的高危行为）才 reject；"
             "文档讨论 `.env`/`sudo`、示例引用 token 等属 `review_required`，不再误伤。")
    L.append("")
    if rejected:
        L.append("| Skill | owner/repo | verdict | 阻断规则 |")
        L.append("|---|---|---|---|")
        for c in rejected[:25]:
            blocks = "; ".join(c["security"].get("blocking_rules") or [])[:120]
            L.append(f"| {c['skill_name']} | {c['owner']}/{c['repo']} | "
                     f"{c['security'].get('verdict')} | {blocks} |")
    else:
        L.append("- 无（今日 0 个 block 级拒绝）")
    L.append("")

    L.append("## 4. 能力缺口候选（按缺口优先级）")
    L.append("")
    focus = data.get("focus_capabilities", [])
    if focus:
        L.append("当前焦点能力（读取已装侧 CAPABILITY_SUPPRESSION + CAPABILITY_AVAILABILITY 动态派生）：")
        L.append("")
        L.append("| 能力 | 覆盖 | 可用性 | 优先级 |")
        L.append("|---|---|---|---|")
        for f in focus:
            L.append(f"| {f['capability']} | {f['level']} | {f['availability']} | {f['priority']} |")
        L.append("")
    L.append(f"- 命中 none/weak 缺口的候选：**{len(gap_cands)}** 个（完整清单见 SKILL_CANDIDATES.json）")
    L.append("")

    repl = [c for c in cands if c["installed_relationship"] == "replacement_candidate"]
    L.append("## 5. 更新候选与恢复候选")
    L.append("")
    if update_flags:
        L.append("**已装但版本落后（update_available，不重复推荐安装，仅提示更新）**")
        L.append("")
        L.append("| Skill | owner/repo | 已装版本状态 | 上游 | 说明 |")
        L.append("|---|---|---|---|---|")
        for c in update_flags[:12]:
            L.append(f"| {c['skill_name']} | {c['owner']}/{c['repo']} | "
                     f"{c['overlap_with_installed']} | {c.get('upstream_activity')} | {c.get('update_note') or ''} |")
        L.append("")
    if repl:
        L.append("**恢复/替换候选（replacement_candidate）**")
        L.append("")
        L.append("| Skill | owner/repo | 对应已装/已知 | 分数 | 上游 | 依据 |")
        L.append("|---|---|---|---|---|---|")
        for c in repl[:12]:
            L.append(f"| {c['skill_name']} | {c['owner']}/{c['repo']} | {c.get('overlap_with_installed') or '—'} | "
                     f"{c['score']} | {c.get('upstream_activity')} | {(c.get('replacement_candidate_reason') or '')[:110]} |")
        L.append("")
    if not update_flags and not repl:
        L.append("- 今日无（无版本落后项、无恢复/替换候选）")
        L.append("")

    open(CONTEXT_OUT, "w", encoding="utf-8").write("\n".join(L) + "\n")
    save_json({c["canonical_key"]: snap_key(c) for c in cands}, SNAPSHOT_PATH)
    print(f"context written | top {len(top30)}/{target_limit} | daily body {len(body)} | "
          f"delta {len(deltas)} | first_run={first_run} | high_match {len(high_match)} | "
          f"projects {len(hm_with_proj)}/{len(hm_all)}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
